---
type: Organizacion
title: Salesianos Cabezo
description: null
tags: [SMX, Murcia, ZCENTRO]
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: [Cabezo de Torres]
enlacesWeb: []
personas: []
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


