---
type: Organizacion
title: 🏢 How to Use This Organization Object
description: null
tags: []
emailTlfno: null
categoria: null
imagenDePortada: null
lugares: []
enlacesWeb: []
personas: []
---

Welcome to your **Organization** object! This object is ideal for capturing information, insights, and interactions related to organizations—whether that's companies, institutions, non-profits, or teams you're engaging with or researching.

## 🔍 What Is an Organization Object type?

In Capacities, each organization is treated as its own **object**.This gives you the ability to:

- **Link** organizations to meetings, people, projects, or documents connected to them.

- Keep all notes, research, and interactions tied directly to the specific organization.

- Easily search, filter, and review your history with any organization.

---

## ✨ Suggested Ways to Use This Object:

### 1. **Record Basic Information**

- Save key details like the organization's name, industry, location, website, mission, and relevant contacts. Note why you are interested in them?

- Add tags (e.g., #potential-client, #non-profit, #partner) to keep things organized.

### 2. **Track Interactions & History**

- Log your meetings, calls, and communications with the organization. This is where a meeting object type can work nicely.

- Link to related meetings and people for a full picture of your engagement.

### 3. **Research & Insights**

- Take notes on the organization's structure, products, news, or leadership.

- Record any information you come across such as opportunities, or risks you've identified.

### 4. **Plan Next Steps**

- Outline potential proposals, or actions you want to take.

- Set reminders or link tasks and projects related to the organization.

💡 Tip: If you link to a date and write a note to your future self, this note will show up in the 'date references' section of that daily note.

---

## 💡 Top Tips:

- [ ] **@Mention** contacts from the organization to keep people and companies connected.

- [ ] Use **tags** to categorize organizations by type, region, or priority.

- [ ] Utilize **backlinks** to quickly jump between related meetings, notes, and contacts.

---

By treating each organization as its own object, you build a connected, easily navigable network of relationships, insights, and plans—all without the clutter of disconnected folders.

If you want some ideas about building a network of people connected to organizations, watch [this video](https://youtu.be/vk_Je_iWBOk?feature=shared&t=1194).

