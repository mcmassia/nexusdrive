---
type: Organizacion
title: Vera+Cruz
description: null
tags: []
emailTlfno: '[veracruz@veracruzsevilla.org](mailto:veracruz@veracruzsevilla.org)'
categoria: Hermandad
imagenDePortada: null
lugares: [Sevilla]
enlacesWeb: [Hermandad de la Vera Cruz. Sevilla]
personas: [Alberto Massia Gómez]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: [C. Jesús de la Vera-Cruz, s/n, Casco Antiguo, 41002 Sevilla](https://www.google.com/maps/place//data=!4m2!3m1!1s0xd126c0e91781697:0x76cbcaaba350ab0a?sa=X&ved=1t:8290&ictx=111)

- Teléfono: [954 90 65 12](https://www.google.com/search?q=vera%2Bcruz+sevilla&sourceid=chrome&ie=UTF-8#)



## 👥 Personal de referencia

Hermano mayor:



- **Otras personas**



## 📝 Anotaciones


