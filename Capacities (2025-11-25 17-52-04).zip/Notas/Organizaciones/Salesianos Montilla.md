---
type: Organizacion
title: Salesianos Montilla
description: null
tags: [SMX, Andalucía, ZSUR]
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: [Montilla]
enlacesWeb: [Portada - Salesianos Montilla]
personas: [Agustín de la Cruz Conde]
---



### ℹ️ Datos de la organización

- Nombre completo: Colegio San Francisco Solano

- Dirección: [C. Arcipreste Fernández Casado, 3, 14550 Montilla, Córdoba](https://www.google.com/maps/place//data=!4m2!3m1!1s0xd6d13827af80153:0x55ec61353e933fd5?sa=X&ved=1t:8290&ictx=111)

- Teléfono: [957 65 01 23](https://www.google.com/search?q=salesianos+montilla&oq=salesianos+monti&sourceid=chrome&ie=UTF-8#)



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro: [Agustín de la Cruz Conde](Personas/Agust%C3%ADn%20de%20la%20Cruz%20Conde.md)

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


