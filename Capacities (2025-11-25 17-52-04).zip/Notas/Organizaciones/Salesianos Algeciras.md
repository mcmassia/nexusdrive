---
type: Organizacion
title: Salesianos Algeciras
description: null
tags: []
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: []
enlacesWeb: []
personas: [Manuel Del Rosal Guzmán]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


