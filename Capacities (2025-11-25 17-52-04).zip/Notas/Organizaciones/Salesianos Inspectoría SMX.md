---
type: Organizacion
title: Salesianos Inspectoría SMX
description: null
tags: [SMX]
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: []
enlacesWeb: []
personas: [Antonio Javier García Parra, Alberto Massia Gómez, Isa Constantino]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


