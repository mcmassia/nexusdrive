---
type: Organizacion
title: DosaTic
description: null
tags: [DOSA]
emailTlfno: null
categoria: Empresa
imagenDePortada: null
lugares: []
enlacesWeb: []
personas: [Enrique Pradas Moreno, Jacinta Muñoz, Jesús Bueno, Martín Solís, Javi Gil, Cristian González, Alberto Massia Gómez, Mª Luisa Miñambres, Mª Jesús Cañadillas]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


