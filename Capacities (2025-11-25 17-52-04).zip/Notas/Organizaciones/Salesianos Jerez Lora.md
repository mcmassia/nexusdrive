---
type: Organizacion
title: Salesianos Jerez Lora
description: null
tags: [SMX, Andalucía, ZSUR]
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: [Jerez]
enlacesWeb: []
personas: ["Amelia\_García Jiménez."]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


