---
type: Organizacion
title: Salesianos Carmona
description: null
tags: [SMX, Andalucía, ZSUR]
emailTlfno: direccioncolegio.carmona@salesianos.edu
categoria: Centro Educativo
imagenDePortada: null
lugares: [Carmona]
enlacesWeb: [Salesianos Carmona - Salesianos Carmona]
personas: [Adelina Osuna Simán, Pedro Román Espinosa, Alberto Massia Gómez, Fernando Alés Portillo]
---





### ℹ️ Datos de la organización

- Nombre completo: Salesianos Santísimo Sacramento.

- Dirección: [Avda. Salesianos, s/n, 41410 Carmona, Sevilla](https://www.google.com/maps/place//data=!4m2!3m1!1s0xd128b78bdc0f8d1:0x2356105cd2459e18?sa=X&ved=1t:8290&ictx=111)

- Teléfono: [954 14 07 18](https://www.google.com/search?q=salesianos+carmona&sourceid=chrome&ie=UTF-8#)



## 👥 Personal de referencia

- #DirectorTitular: [Fernando Alés Portillo](Personas/Fernando%20Al%C3%A9s%20Portillo.md)

- #DirectorCentro: [Fernando Alés Portillo](Personas/Fernando%20Al%C3%A9s%20Portillo.md)

- #Administrador: [Pedro Román Espinosa](Personas/Pedro%20Rom%C3%A1n%20Espinosa.md)

- #Secretaría: [Pedro Román Espinosa](Personas/Pedro%20Rom%C3%A1n%20Espinosa.md)

- #Coord.Qe: [Alberto Massia Gómez](Personas/Alberto%20Massia%20G%C3%B3mez.md)

- #Coord.Calidad: [Adelina Osuna Simán](Personas/Adelina%20Osuna%20Sim%C3%A1n.md)

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


