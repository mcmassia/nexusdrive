---
type: Organizacion
title: Santos Mártires
description: null
tags: [FDSM]
emailTlfno: null
categoria: Institución Educativa
imagenDePortada: null
lugares: [Córdoba]
enlacesWeb: []
personas: [Cristóbal Domínguez Castro, Alfredo Molero, José Mª Olmo Gañán, Rafael Onieva Barea, Laura Seoane Rodríguez]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


