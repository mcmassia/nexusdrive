---
type: Organizacion
title: Salesianos Cádiz
description: null
tags: [SMX, Andalucía, ZSUR]
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: [Cádiz]
enlacesWeb: [Inicio - Salesianos Cádiz]
personas: [Fernando Mariscal Rubial, Félix Reyes Fernández]
---



### ℹ️ Datos de la organización

- Nombre completo: Colegio Salesiano San Ignacio

- Dirección: [Av. María Auxiliadora, 7, 11009 Cádiz](https://www.google.com/maps/place//data=!4m2!3m1!1s0xd0dd234dc8cc9b5:0xb58c24de52475f5a?sa=X&ved=1t:8290&ictx=111)

- Teléfono: [667 48 72 93](https://www.google.com/search?q=salesianos+cadiz&sca_esv=c0ca25e8fd581d08&ei=0r7CaP6MF_elkdUPrtW22A4&gs_ssp=eJzj4tVP1zc0TM4zzcuxSDM0YLRSMahIMUhJMTI2SUm2SE62TDK1MqhIMrVINjJJSTU1MjE3TTNN9BIoTsxJLc5MzMsvVkhOTMmsAgDfFBWs&oq=salesianos+cadiz&gs_lp=Egxnd3Mtd2l6LXNlcnAiEHNhbGVzaWFub3MgY2FkaXoqAggAMgsQLhiABBjHARivATIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAEMgUQABjvBTIaEC4YgAQYxwEYrwEYlwUY3AQY3gQY4ATYAQFIgiRQygNY2RhwAXgBkAEAmAGGAaABkQyqAQQwLjEzuAEByAEA-AEBmAIPoALaFsICChAAGLADGNYEGEfCAg0QABiABBiwAxhDGIoFwgIGEAAYFhgewgIKEAAYgAQYQxiKBcICCBAAGIAEGMkDwgILEAAYgAQYkgMYigXCAg4QLhiABBjHARiOBRivAZgDAIgGAZAGCboGBggBEAEYFJIHCDEuMTMuNy0xoAe7ngGyBwQwLjEzuAfxDMIHBDItMTXIB1w&sclient=gws-wiz-serp#)



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro: [Fernando Mariscal Rubial](Personas/Fernando%20Mariscal%20Rubial.md)

- #Administrador:

- #Secretaría:

- #Coord.Qe: [Félix Reyes Fernández](Personas/F%C3%A9lix%20Reyes%20Fern%C3%A1ndez.md)

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones



