---
type: Organizacion
title: Salesianos La Palma del Condado
description: null
tags: []
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: []
enlacesWeb: []
personas: [Juan Guillermo Cera López, Montse Rodríguez Martínez]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe:

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


