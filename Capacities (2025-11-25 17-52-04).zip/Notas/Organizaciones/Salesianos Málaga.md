---
type: Organizacion
title: Salesianos Málaga
description: null
tags: [SMX, Andalucía, ZSUR]
emailTlfno: null
categoria: Centro Educativo
imagenDePortada: null
lugares: [Málaga]
enlacesWeb: []
personas: [Antonio LLorente]
---



### ℹ️ Datos de la organización

- Nombre completo: 

- Dirección: 

- Teléfono:



## 👥 Personal de referencia

- #DirectorTitular:

- #DirectorCentro:

- #Administrador:

- #Secretaría:

- #Coord.Qe: [Antonio LLorente](Personas/Antonio%20LLorente.md)

- #Coord.Calidad:

- #Coord.Orientación:

- **Otras personas**



## 📝 Anotaciones


