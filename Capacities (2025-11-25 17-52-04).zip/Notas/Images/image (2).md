---
type: Image
title: image
description: null
createdAt: '2025-10-08T10:49:13.177Z'
creationDate: 2025-10-08 12:49
tags: []
fuente: upload
url: null
tipoMime: image/png
tamanoDelArchivo: 205967
ancho: 1191
altura: 1142
---


Media: ![Imagen](Images/Media/image%20(2).png)


