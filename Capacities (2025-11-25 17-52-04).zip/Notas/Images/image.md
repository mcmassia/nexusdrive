---
type: Image
title: image
description: null
createdAt: '2025-09-09T22:01:30.212Z'
creationDate: 2025-09-10 00:01
tags: []
fuente: upload
url: null
tipoMime: image/png
tamanoDelArchivo: 383268
ancho: 1116
altura: 1830
---


Media: ![Imagen](Images/Media/image.png)


