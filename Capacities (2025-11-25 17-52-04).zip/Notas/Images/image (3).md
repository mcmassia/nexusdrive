---
type: Image
title: image
description: null
createdAt: '2025-09-12T08:42:55.072Z'
creationDate: 2025-09-12 10:42
tags: []
fuente: upload
url: null
tipoMime: image/png
tamanoDelArchivo: 476450
ancho: 2134
altura: 678
---


Media: ![Imagen](Images/Media/image%20(3).png)


