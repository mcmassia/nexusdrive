---
type: Lugar
title: Carmona
tags: [Andalucía, España]
recomendadoPor: null
categoria: Ciudad
imagenDePortada: null
calificacion: ⭐⭐⭐⭐⭐⭐
ubicacion: null
---


