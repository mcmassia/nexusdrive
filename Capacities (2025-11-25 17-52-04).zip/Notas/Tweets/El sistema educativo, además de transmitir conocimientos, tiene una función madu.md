---
type: Tweet
title: 'El sistema educativo, además de transmitir conocimientos, tiene una función madurativa insoslayable: preparar a los jóvenes para la vida real, con sus conflictos, frustraciones y decepciones.'
description: null
createdAt: '2025-09-10T23:00:34.673Z'
creationDate: 2025-09-11 01:00
tags: [Educación]
url: https://twitter.com/profsecundario/status/1965889236957278624
nombreDeUsuarioDeTwitter: profsecundario
hilo: false
idioma: null
adjuntos: []
---



A una alumna de 16 años le ha dado un ataque de ansiedad porque le ha tocado en la misma clase con un chico con el que se lleva mal. Nada grave en apariencia: fueron amigos y luego dejaron de serlo por una tercera persona. 

Ella misma ha reconocido que hace tiempo que no se dirigen la palabra. Sin embargo, mientras escuchaba nuestras explicaciones —que se reducían a la simple imposibilidad material de multiplicar el número de grupos para contentar a todos—, la tensión fue en aumento. Primero comenzó a llorar, después a gritar y, finalmente, a hiperventilar. 

Creo que el punto de inflexión llegó cuando intenté transmitirle una idea básica: conforme los alumnos van creciendo, deben aprender también a enfrentar los problemas y a no contar siempre con la solución inmediata de la huida. 

A partir de ahí, nada pareció surtir efecto: ni el tono reconfortante, ni las promesas de ayuda, ni los razonamientos, ni las llamadas a la serenidad. 

Por supuesto, la niña no es culpable de lo que le sucede. Ella, más bien, es víctima de un sistema viciado que ha confundido educar con evitar cualquier forma de malestar. 

La escuela y, en gran medida, la sociedad han procurado durante décadas que los niños no experimenten el roce con la parte amarga de la existencia, como si eso pudiera aplazarse indefinidamente. 

El resultado es que ahora emergen, de forma dramática e incluso médica, los efectos de esa inhumana sobreprotección. 

El sistema educativo, además de transmitir conocimientos, tiene una función madurativa insoslayable: preparar a los jóvenes para la vida real, con sus conflictos, frustraciones y decepciones. 

Negarles ese aprendizaje supone condenarlos a una fragilidad que luego se manifiesta en forma de ansiedades, bloqueos o reacciones desmedidas ante obstáculos relativamente pequeños. 

Educar no puede ser solo sinónimo de confort y bienestar; también implica enseñar a tolerar la frustración, a convivir con personas que no nos agradan y a resolver conflictos sin dramatismos paralizantes. 

Si la escuela abdica de esa tarea, los alumnos llegan a la edad adulta sin los recursos emocionales mínimos para sostenerse. 

Recuperar la función madurativa de la educación es una urgencia que nos atañe a todos: padres, profesores y legisladores. 

Porque el mundo, tarde o temprano, exigirá a los hombres y mujeres de mañana lo que el sistema les ha escamoteado a los niños y niñas de hoy... 

Y ellos solo podrán ofrecer unas manos vacías y unos ojos anegados en lágrimas.

