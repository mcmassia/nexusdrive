---
type: Tarea
title: Formación Programaciones nuevo Centro Zaragoza
createdAt: '2025-09-11T22:33:07.351Z'
creationDate: 2025-09-12 00:33
tags: [AntonioMachado, Realizado]
asociado: '[Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md) [Formaciones Qe](Proyectos/Formaciones%20Qe.md) [Antonio Machado](Organizaciones/Antonio%20Machado.md)'
fechaInicio: null
fechaFin: null
---

2 de octubre de 2025tenemos vídeo para comenzar a trabajar en cambio pedagógico en el ámbito de programaciones.

