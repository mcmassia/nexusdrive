---
type: Tarea
title: Acometer desarrollos adaptación FP
createdAt: '2025-09-11T22:42:16.530Z'
creationDate: 2025-09-12 00:42
tags: [Activo]
asociado: '[Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md) [Adaptación FP](Proyectos/Adaptaci%C3%B3n%20FP.md)'
fechaInicio: null
fechaFin: null
---

[Desarrollos adaptación FP 2024/2025](https://docs.google.com/document/d/1sEuyrCZlZLl-Fnac5RkIQpvHKx2VMXnrBGRAVoXI-EY/edit?usp=sharing)

