---
type: Tarea
title: Evidenciar acceso a boletines EF
createdAt: '2025-09-11T22:29:40.835Z'
creationDate: 2025-09-12 00:29
tags: [Activo]
asociado: '[Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md) [EF Qe](Proyectos/EF%20Qe.md)'
fechaInicio: null
fechaFin: null
---

14 de mayo de 2025me plantea [Fernando Mariscal Rubial](Personas/Fernando%20Mariscal%20Rubial.md):

- Tras la reunión que hemos tenido con el Servicio de Inspección de la Delegación Territorial sobre garantías procedimentales en la evaluación, me asalta la duda de si podemos evidenciar de alguna manera que una familia/alumnado mayor de edad ha accedido al boletín de notas finales en Qualitas. ¿Es eso posible? Es importante de cara a hacer frente a una solicitud de revisión/reclamación puesto que hay unos plazos reglamentarios que hay que cumplir.

- [ ] Analizar posibilidades de evidenciar el acceso de usuarios a los boletines EF.

