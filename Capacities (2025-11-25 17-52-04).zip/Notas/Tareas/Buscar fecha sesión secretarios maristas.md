---
type: Tarea
title: Buscar fecha sesión secretarios maristas
createdAt: '2025-09-11T15:49:34.012Z'
creationDate: 2025-09-11 17:49
tags: [Maristas, Realizado]
asociado: '[Juan García Gallego](Personas/Juan%20Garc%C3%ADa%20Gallego.md) '
fechaInicio: null
fechaFin: null
---

- [x] Analizar formulario necesidades iniciales 

[Cargando Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1YSYoV5VlrPXYGIRJV73StUNq-ERHYxly/edit?usp=drive_link&ouid=115043862614468397993&rtpof=true&sd=true)

### Necesidades detectadas

- Estructura de Centro

- Gestión horarios

- Matriculación

- Escuela familia

- Posibilidad de impartir sesión de 4hh.

- [x] Buscar fecha para articular sesión formativa con nuevos #Coord.Qe que serán los secretarios de los Centros.

    - [x] Escribir correo con posibles fechas 12 de septiembre de 2025

    - [x] A la espera de respuesta de Juan.

    - Me propone primera quincena octubre

    - Le planteo las siguientes fechas:

        - 8 de octubre 12:00 - 14:00.


