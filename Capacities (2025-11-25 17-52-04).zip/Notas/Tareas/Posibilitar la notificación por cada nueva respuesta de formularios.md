---
type: Tarea
title: Posibilitar la notificación por cada nueva respuesta de formularios
createdAt: '2025-09-11T22:18:00.797Z'
creationDate: 2025-09-12 00:18
tags: [Activo]
asociado: '[Formularios Qe](Proyectos/Formularios%20Qe.md) [Antonio Javier García Parra](Personas/Antonio%20Javier%20Garc%C3%ADa%20Parra.md) [Jesús Bueno](Personas/Jes%C3%BAs%20Bueno.md)'
fechaInicio: null
fechaFin: null
---

[https://soporte.dosatic.com/view.php?id=48937](https://soporte.dosatic.com/view.php?id=48937)

- [ ] Revisar documento [mejoras formularios 2025/05](https://docs.google.com/document/d/1ER8TXeIhJRUueHgHCrRBnG0J4esVlVwrJVH2Iny04Zo/edit?usp=sharing)

