---
type: Tarea
title: Formación Nuevos Qe
createdAt: '2025-09-15T14:38:02.464Z'
creationDate: 2025-09-15 16:38
tags: []
asociado: '#Coord.Qe[Formaciones Qe](Proyectos/Formaciones%20Qe.md)'
fechaInicio: null
fechaFin: null
---

Este Curso tenemos nuevos coord. Qe en [Salesianos Cabezo](Organizaciones/Salesianos%20Cabezo.md) [Salesianos La Almunia](Organizaciones/Salesianos%20La%20Almunia.md)[Salesianos Jerez Lora](Organizaciones/Salesianos%20Jerez%20Lora.md) [Salesianos Villena](Organizaciones/Salesianos%20Villena.md)

- [x] Buscar fecha y proponer a los Qe y directores

- Lo desestimamos actualmente por ser pocos y porque en Jerez Lora Tamayo han solicitado una sesión propia.

