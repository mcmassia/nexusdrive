---
type: Tarea
title: Consolidación según valor escala
createdAt: '2025-09-11T21:56:43.737Z'
creationDate: 2025-09-11 23:56
tags: [Realizado]
asociado: '[CalificacionesQe](Proyectos/CalificacionesQe.md) [Jacinta Muñoz](Personas/Jacinta%20Mu%C3%B1oz.md)'
fechaInicio: '2023-02-12'
fechaFin: null
---

- [x] Analizar en el [Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md) qué elementos deben ser cerrados.

- **Documentación disponible actualizada**:

    - [Notas - Consolidación escala (versión 2023 11)](https://docs.google.com/document/d/1XJFqXIP2Sr5Xfycse_xXz-IhhHmvIFEBrFcQKQeV0Cc/edit?usp=sharing)

    - [2023/11/15 Acta pilotaje 3](https://docs.google.com/document/d/1bN7F-cfWH_c2KIDMoFbvie-bTasGcQ0d1c5PCF2T0mM/edit?usp=sharing)

        - Consolidación del valor de escala

            - Implementamos la consolidación de calificaciones según el valor de la escala definida.

            - Se redondeará y consolidará siempre según el valor del nivel de la escala correspondiente a la nota real con decimales del alumno.

            - Este valor consolidado (nota del alumno) es el que se usará para todos los procedimientos posteriores: boletines, notas medias, exportación.

            - Este valor consolidado (nota del alumno) se aplicará en los niveles/literales correspondientes de la escala configurada en los diversos ámbitos de visualización: actas, boletines, EF…

            - Como el sistema siempre guarda la nota real del alumno con decimales, permitir visualizarla mediante opción en la configuración (boletines, EF); por lo tanto habría dos opciones de visualización en la configuración:

                - visualizar valor redondeado de escala (entero).

                - visualizar valor real sin redondeo (decimal).

    - [x] Crear nuevo documento de cierre análisis:

    - [Análisis CONSOLIDACIÓN NOTAS - 2025/04](https://docs.google.com/document/d/11GDQxhjQUY-QNn3JgC5BA-5Cm-gM1dsUKHvX5m4GzDk/edit?usp=sharing)

        Esperando que Jacinta termine su análisis.

        - 9 de mayo de 2025solventamos dudas respecto del formato de las celdas de notas de la columna Rec.

        - 11 de julio de 2025Jacinta nos indica que la próxima semana lo articula en un laboratorio para poder probar el proceso y desbloquear la activación antes del inicio de Curso.

        - 5 de septiembre de 2025[Alberto Massia Gómez](Personas/Alberto%20Massia%20G%C3%B3mez.md) analiza la articulación en laboratorio; pero parece no funcionar correctamente. 

        - 8 de octubre de 2025 se define subida a producción el día 9 de octubre de 2025

            - [x] incluir esta información en [HI](https://docs.google.com/document/d/1p7Z1j23bPggPicYuzFtBC6kOF_Xv5_bVBYGx4LXF_6M/edit?usp=sharing)de 16 de octubre de 2025

        17 de octubre de 2025ya activo y funcionando correctamente en producción.

