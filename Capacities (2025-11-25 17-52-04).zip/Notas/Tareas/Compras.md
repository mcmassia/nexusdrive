---
type: Tarea
title: Compras
createdAt: '2025-09-15T20:24:48.855Z'
creationDate: 2025-09-15 22:24
tags: [Casa, Personal, Activo]
asociado: '[Alberto Massia Gómez](Personas/Alberto%20Massia%20G%C3%B3mez.md)'
fechaInicio: null
fechaFin: null
---

---


### **Frutas:**

- [ ] Arándanos

- [x] Manzanas

- [x] Plátanos

### **Verduras y Hortalizas:**

- [x] Cebolleta

- [ ] Tomate rallado

- [x] Tomates

### **Lácteos y Embutidos:**

- [x] Charcutería

- [x] Mantequilla

- [x] Queso lonchas

- [ ] Yogures

### **Conservas y Enlatados:**

- [x] Atún

- [x] Mejillones natural

### **Cereales y Panadería:**

- [x] Arroz

- [x] Pan molde

### **Carnes y Pescados:**

- [x] Carne

### **Aceites y Otros:**

- [x] Aceite girasol

### **Infantil:**

- [x] Pañales

- [x] Potitos


