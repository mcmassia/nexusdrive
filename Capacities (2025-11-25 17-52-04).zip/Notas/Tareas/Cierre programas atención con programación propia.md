---
type: Tarea
title: Cierre programas atención con programación propia
createdAt: '2025-09-11T22:11:29.716Z'
creationDate: 2025-09-12 00:11
tags: [Activo]
asociado: '[Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md) [ProyectosAtención Qe](Proyectos/ProyectosAtenci%C3%B3n%20Qe.md)'
fechaInicio: null
fechaFin: null
---

- [ ] Analizar casos de cierre de programas de atención con programación propia para que no se pierdan los referentes calificados del alumno.

- [ ] Revisar diseño inicial para prevenir estas situaciones

    - [MODULO ORIENTACIÓN HTML5](https://docs.google.com/document/d/1vPx5juU3fs--F17gSFysp1FBZB1e7pPgNLLBxdpPf58/edit?usp=sharing)

