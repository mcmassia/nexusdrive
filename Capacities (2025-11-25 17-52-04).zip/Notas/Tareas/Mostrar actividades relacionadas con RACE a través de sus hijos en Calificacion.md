---
type: Tarea
title: Mostrar actividades relacionadas con RA/CE a través de sus hijos en Calificaciones
createdAt: '2025-09-11T22:37:57.634Z'
creationDate: 2025-09-12 00:37
tags: [Activo]
asociado: '[CalificacionesQe](Proyectos/CalificacionesQe.md) [Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md) [Antonio LLorente](Personas/Antonio%20LLorente.md)'
fechaInicio: null
fechaFin: null
---

- Antonio Llorente nos indica en reunión pilotos que sería bueno que en Calificaciones se mostrase la información relativa a las actividades calificables que aplican a las notas cuando se calculan en un nivel que no es Referentes.

- Actualmente, esta información solo se muestra únicamente en el nivel Referentes.

