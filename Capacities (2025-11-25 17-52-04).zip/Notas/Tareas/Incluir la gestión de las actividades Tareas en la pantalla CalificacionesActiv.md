---
type: Tarea
title: Incluir la gestión de las actividades Tareas en la pantalla Calificaciones/Actividades
createdAt: '2025-09-11T22:24:41.144Z'
creationDate: 2025-09-12 00:24
tags: [Activo]
asociado: '[CalificacionesQe](Proyectos/CalificacionesQe.md) [Martín Solís](Personas/Mart%C3%ADn%20Sol%C3%ADs.md)'
fechaInicio: null
fechaFin: null
---

[https://soporte.dosatic.com/view.php?id=51135](https://soporte.dosatic.com/view.php?id=51135)


