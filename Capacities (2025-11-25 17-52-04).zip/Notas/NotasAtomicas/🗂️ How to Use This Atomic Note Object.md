---
type: NotaAtomica
title: 🗂️ How to Use This Atomic Note Object
description: null
tags: []
imagenDePortada: null
---

Welcome to your **Atomic Notes** object!This object is designed to help you organize and develop your knowledge around specific notes, subjects, or areas of interest—all in one place.

## 🔍 What Is a Atomic Notes Object?

In Capacities, each atomic note is treated as its own **object**.This allows you to:

- Centralize your research, thoughts, and references on a particular subject.

- **Link** related notes, projects, books, people, or other resources to the topic.

- Create a connected knowledge base, making it easy to revisit and expand on your understanding over time.

---

## ✨ Suggested Ways to Use This Object:

### 1. **Define the Atomic Note**

- Give a clear name and description of the atomic note.

- Outline what the note covers and why it’s important or relevant to you.

### 2. **Review Information & Notes you've already collected about it**

- Check your backlinks or tags for any related content you've already collected. What does it tell you about the note? What research gaps have you identified?

- Summarize key concepts or definitions associated with it.

### 3. **Link Related Objects**

- Reference where the atomic note appears or is applied in your work or learning.

    - Don't worry about missing a connection; Capacities will find any unlinked mentions for you, so you can come back and make connections later.

### 4. **Organize with Tags**

- Use tags to categorize notes by field, interest area, or relevance (e.g., #technology, #philosophy, #marketing).

- Filter and group notes easily for better navigation.

---

## 💡 Top Tips:

- [ ] Use **backlinks** to see all the notes, ideas, or projects connected to each note.

- [ ] Regularly update your atomic notes as your knowledge grows or as new information becomes available.

---

By treating each atomic note as its own object, you build a structured, interconnected knowledge system that evolves with your learning and interests.

Feel free to personalize this object type to fit how you research, learn, or manage information!

