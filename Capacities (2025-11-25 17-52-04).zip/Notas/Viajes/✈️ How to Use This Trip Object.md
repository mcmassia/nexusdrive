---
type: Viaje
title: ✈️ How to Use This Trip Object
tags: []
fechas: null
estado: null
ubicacion: null
personas: null
imagenDePortada: null
---

Welcome to your **Trip** object!This object is designed to help you plan, document, and reflect on your trips—whether they’re vacations, business trips, weekend getaways, or longer journeys.

## 🔍 What Is a Trip Object?

In Capacities, each trip is treated as its own **object**.This allows you to:

- Keep all travel plans, itineraries, notes, and reflections connected to a specific trip.

- **Link** related people, locations, bookings, or notes.

- Build a personal archive of past trips and future travel plans, fully connected to your broader knowledge base.

---

## ✨ Suggested Ways to Use This Object:

### 1. **Plan Your Trip**

- Record key trip details: destination, travel dates, transportation, accommodation, and bookings.

- Upload reservation confirmations, or travel documents - they will be available offline later too.

### 2. **Organize Itinerary & Activities**

- Outline your daily itinerary, key events, meetings, or activities. Link to your daily note to get a centralised view each day of your trip.

- Note places you want to visit—restaurants, museums, landmarks, etc.

### 3. **Link Related Objects**

- Connect the trip to people you're traveling with, meetings scheduled, or projects related to the trip.

    - Don't worry about missing a connection; Capacities will find any unlinked mentions for you, so you can come back and make connections later.

- Reference locations, organizations, or media connected to your destination.

### 4. **Capture Notes & Reflections**

- Write journal entries, reflections, or highlights during and after the trip.

- Save important learnings, experiences, or memorable moments.

### 5. **Organize with Tags**

- Use tags to categorize trips (e.g., #vacation, #business-trip, #conference).

- Filter trips by destination, purpose, or timeframe.

---

## 💡 Top Tips:

- [ ] Use **backlinks** to tie your trip to meetings, people, or projects connected to it.

- [ ] Keep a checklist of essential items, documents, or preparation steps within each trip note.

---

If you want some ideas on how to plan trips with Capacities, read [this tutorial](https://capacities.io/tutorials/travel-planning).

Feel free to personalize this object type to match how you travel and document your experiences!

