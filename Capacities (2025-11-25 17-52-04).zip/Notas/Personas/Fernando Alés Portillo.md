---
type: Persona
title: Fernando Alés Portillo
description: null
tags: []
contacto: null
categoria: Docente
foto: null
organizaciones: [Salesianos Carmona]
cumpleanos: null
equipos: []
---


