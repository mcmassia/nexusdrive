---
type: Persona
title: Juan Guillermo Cera López
description: null
tags: []
contacto: '[juanguillermo.cera@salesianos.edu](mailto:juanguillermo.cera@salesianos.edu)'
categoria: Docente
foto: null
organizaciones: [Salesianos La Palma del Condado]
cumpleanos: null
equipos: [Coordinadores Qe SMX Sur]
---


