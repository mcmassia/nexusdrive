---
type: Persona
title: Jacinta Muñoz
description: null
tags: [Qe]
contacto: '[jacinta@dosatic.com​](mailto:jacinta@dosatic.com)[jacinta.munoz@salesianos.edu](mailto:jacinta.munoz@salesianos.edu)'
categoria: Informático
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: [Programadores Qe]
---


