---
type: Persona
title: Rafael Onieva Barea
description: null
tags: []
contacto: null
categoria: null
foto: null
organizaciones: [Santos Mártires]
cumpleanos: null
equipos: []
---


