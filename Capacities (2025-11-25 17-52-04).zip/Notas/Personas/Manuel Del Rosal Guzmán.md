---
type: Persona
title: Manuel Del Rosal Guzmán
description: null
tags: []
contacto: null
categoria: SDB
foto: null
organizaciones: [Salesianos Algeciras]
cumpleanos: null
equipos: []
---


