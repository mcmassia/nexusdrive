---
type: Persona
title: Cristian González
description: null
tags: []
contacto: '[cristian.gonzalez@dosatic.com](mailto:cristian.gonzalez@dosatic.com)'
categoria: Informático
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: [Programadores Qe]
---


