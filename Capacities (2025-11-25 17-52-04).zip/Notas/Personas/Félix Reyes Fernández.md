---
type: Persona
title: Félix Reyes Fernández
description: null
tags: []
contacto: '[felixreyes@cadiz.salesianos.edu](mailto:felixreyes@cadiz.salesianos.edu)'
categoria: Docente
foto: null
organizaciones: [Salesianos Cádiz]
cumpleanos: null
equipos: []
---


