---
type: Persona
title: Javi Gil
description: null
tags: []
contacto: null
categoria: Informático
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: [Programadores Qe]
---


