---
type: Persona
title: Jesús Bueno
description: null
tags: []
contacto: '[jesus.bueno@dosatic.com](mailto:jesus.bueno@dosatic.com)'
categoria: Informático
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: [Programadores Qe]
---


