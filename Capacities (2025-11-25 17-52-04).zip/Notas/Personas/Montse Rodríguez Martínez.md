---
type: Persona
title: Montse Rodríguez Martínez
description: null
tags: []
contacto: '[montse.rodriguez@lapalmacondado.salesianos.edu](mailto:montse.rodriguez@lapalmacondado.salesianos.edu)'
categoria: Docente
foto: null
organizaciones: [Salesianos La Palma del Condado]
cumpleanos: null
equipos: [Coordinadores Qe SMX Sur]
---


