---
type: Persona
title: Sebastián Bajo Castro
description: null
tags: []
contacto: 677481116​
categoria: Docente
foto: null
organizaciones: [Salesianos Pozoblanco]
cumpleanos: null
equipos: [Directores SMX SUR]
---


