---
type: Persona
title: Adelina Osuna Simán
description: null
tags: []
contacto: '[adelina.osuna@salesianos.edu](mailto:adelina.osuna@salesianos.edu)'
categoria: Docente
foto: null
organizaciones: [Salesianos Carmona]
cumpleanos: null
equipos: []
---

> Para poder determinar datos específicos filtrables y dinánimicos, incluir esta información a modo de tags

# Datos básicos

# Datos oficiales

### Seguridad Social

### Servicio Salud

### Agencia tributaria

### Datos bancarios

# Datos laborales

## Contratos y modificaciones horas

- 2016/04/11 - Interinidad - Tiempo completo 25h.

- 2016/09/01 - Relevo - Tiempo parcial 18h.

- 2019/04/17 - Ampliación/Disminución - 25h/18h.

- 2020/04/04 - x - Tiempo parcial 15h.

- 2020/08/31 - Ampliación/Disminución - 22h/15h.

- 2021/08/31 - Ampliación/Disminución - 22h/15h.

- 2021/09/09 - Ampliación/Disminución - 23h/15h.

- 2024/08/31 - Ampliación/Disminución - 19h/19h.

- 2025/ - Ampliación/Disminución - 21h/19h.

# Documentos y recursos

Documentos y enlaces a recursos importantes de la persona

# Datos médicos

> Datos médicos relevantes o importantes

