---
type: Persona
title: Eduardo Marco Ruiz
description: null
tags: []
contacto: '[eduardo.marco@salesianos.edu](mailto:eduardo.marco@salesianos.edu)'
categoria: Docente
foto: null
organizaciones: [Salesianos Zaragoza]
cumpleanos: null
equipos: []
---


