---
type: Persona
title: Paco Jaldo
description: null
tags: []
contacto: null
categoria: SDB
foto: null
organizaciones: [Salesianos La Cuesta, Salesianos La Orotava]
cumpleanos: null
equipos: []
---


