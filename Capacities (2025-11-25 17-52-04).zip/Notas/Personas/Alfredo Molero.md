---
type: Persona
title: Alfredo Molero
description: null
tags: []
contacto: null
categoria: null
foto: null
organizaciones: [Santos Mártires]
cumpleanos: null
equipos: []
---


