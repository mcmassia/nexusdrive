---
type: Persona
title: Antonio LLorente
description: null
tags: []
contacto: '[antonio.llorente@malaga.salesianos.edu](mailto:antonio.llorente@malaga.salesianos.edu)'
categoria: Docente
foto: null
organizaciones: [Salesianos Málaga]
cumpleanos: null
equipos: [Coordinadores Qe SMX Sur, Equipo Pilotos]
---


