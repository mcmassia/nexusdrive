---
type: Persona
title: José Antonio Jordá
description: null
tags: []
contacto: null
categoria: null
foto: null
organizaciones: []
cumpleanos: null
equipos: [Equipo Pilotos]
---


