---
type: Persona
title: Cristóbal Domínguez Castro
description: null
tags: [FDSM]
contacto: '[informatica@fdemartires.es](mailto:informatica@fdemartires.es)'
categoria: Docente, Informático
foto: null
organizaciones: [Santos Mártires]
cumpleanos: null
equipos: []
---


