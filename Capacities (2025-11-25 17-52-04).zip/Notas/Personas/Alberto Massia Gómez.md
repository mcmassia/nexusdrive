---
type: Persona
title: Alberto Massia Gómez
description: null
tags: [SMX, Qe]
contacto: null
categoria: Docente, Artista, Autor
foto: null
organizaciones: [Salesianos Carmona, Salesianos Inspectoría SMX, Vera+Cruz, DosaTic]
cumpleanos: 23 de enero de 1977
equipos: [Equipo Técnico Qe, Equipo Pilotos, Equipo Directivo Qe]
---


