---
type: Persona
title: San Alberto Magno
description: null
tags: []
contacto: null
categoria: null
foto: null
organizaciones: []
cumpleanos: null
equipos: []
---

San Alberto Magno (cuyo nombre significa Alberto el Grande) fue un fraile dominico, científico, filósofo y teólogo alemán nacido alrededor del año 1200 en Lauingen, Baviera, y fallecido en Colonia el 15 de noviembre de 1280. Es conocido como uno de los más grandes genios medievales y es patrono de los científicos. Fue maestro y mentor de santo Tomás de Aquino, y se le reconoce como iniciador del sistema escolástico que su discípulo perfeccionó.

San Alberto destacó por su capacidad analítica y observadora, abarcando tanto las ciencias naturales como la teología. Fue rector de la Universidad de Colonia, provincial de los dominicos en Alemania y obispo de Ratisbona. También desempeñó cargos importantes en Roma, fue maestro del Papa y participó activamente en el Concilio de Lyon. Se le apoda Magno debido a su triunfo en el campo del conocimiento y su gran contribución a la filosofía y la ciencia medieval.

Fue canonizado en 1931 por el Papa Pío XI y declarado Doctor de la Iglesia. Posteriormente, el Papa Pío XII lo nombró patrono de los estudiantes de las ciencias naturales, químicas y exactas. Su vida se caracteriza por la combinación de sabiduría teológica, humanística y científica, y por su dedicación a la enseñanza y la paz en contextos conflictivos. Entre sus legados destaca la integración entre fe y razón y el fundamento para el sistema escolástico cristiano.

