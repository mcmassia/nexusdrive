---
type: Persona
title: "Amelia\_García Jiménez."
description: null
tags: []
contacto: null
categoria: Docente
foto: null
organizaciones: [Salesianos Jerez Lora]
cumpleanos: null
equipos: [Coordinadores Qe SMX Sur]
---


