---
type: Persona
title: Fernando Mariscal Rubial
description: null
tags: []
contacto: null
categoria: Docente
foto: null
organizaciones: [Salesianos Cádiz]
cumpleanos: null
equipos: []
---


