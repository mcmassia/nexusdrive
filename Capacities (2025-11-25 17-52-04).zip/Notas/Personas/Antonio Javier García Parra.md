---
type: Persona
title: Antonio Javier García Parra
description: null
tags: [Qe, SMX]
contacto: null
categoria: Informático
foto: null
organizaciones: [Salesianos Inspectoría SMX]
cumpleanos: null
equipos: [Equipo Técnico Qe, Equipo Pilotos, Equipo Directivo Qe]
---


