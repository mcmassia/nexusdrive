---
type: Persona
title: Mª Jesús Cañadillas
description: null
tags: []
contacto: '[mjesus@dosatic.com](mailto:mjesus@dosatic.com)'
categoria: null
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: []
---


