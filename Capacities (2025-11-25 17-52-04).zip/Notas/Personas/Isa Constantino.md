---
type: Persona
title: Isa Constantino
description: null
tags: [SMX]
contacto: null
categoria: Abogado
foto: null
organizaciones: [Salesianos Inspectoría SMX]
cumpleanos: null
equipos: [SMX Asesoría jurídica]
---


