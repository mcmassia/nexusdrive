---
type: Persona
title: Luismi Notario
description: null
tags: [SMX]
contacto: null
categoria: Docente
foto: null
organizaciones: []
cumpleanos: null
equipos: [Escuelas, Equipo Directivo Qe]
---


