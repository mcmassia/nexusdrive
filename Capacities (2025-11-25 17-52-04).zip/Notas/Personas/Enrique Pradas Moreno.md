---
type: Persona
title: Enrique Pradas Moreno
description: null
tags: [Qe, SMX]
contacto: null
categoria: Informático
foto: null
organizaciones: [DosaTic]
cumpleanos: 11/11/1973
equipos: [Equipo Técnico Qe, Equipo Directivo Qe]
---


