---
type: Persona
title: Martín Solís
description: null
tags: []
contacto: null
categoria: Informático
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: [Programadores Qe]
---


