---
type: Persona
title: Mª Luisa Miñambres
description: null
tags: []
contacto: '[mluisam@dosatic.com](mailto:mluisam@dosatic.com)'
categoria: null
foto: null
organizaciones: [DosaTic]
cumpleanos: null
equipos: [Soporte Qe]
---


