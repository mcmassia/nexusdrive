---
type: Persona
title: Laura Seoane Rodríguez
description: null
tags: []
contacto: null
categoria: null
foto: null
organizaciones: [Santos Mártires]
cumpleanos: null
equipos: []
---


