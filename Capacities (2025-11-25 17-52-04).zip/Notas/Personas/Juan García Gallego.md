---
type: Persona
title: Juan García Gallego
description: null
tags: [Maristas]
contacto: '[educacion@maristasmediterranea.com](mailto:educacion@maristasmediterranea.com)'
categoria: Docente
foto: null
organizaciones: [Maristas Badajoz]
cumpleanos: null
equipos: [Coordinadores Ágora]
---


