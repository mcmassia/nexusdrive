---
type: Persona
title: Pedro Román Espinosa
description: null
tags: []
contacto: null
categoria: Personal Servicio
foto: null
organizaciones: [Salesianos Carmona]
cumpleanos: null
equipos: []
---


