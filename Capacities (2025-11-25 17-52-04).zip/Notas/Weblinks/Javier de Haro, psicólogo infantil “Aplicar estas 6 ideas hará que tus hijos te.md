---
type: Weblink
title: 'Javier de Haro, psicólogo infantil: “Aplicar estas 6 ideas hará que tus hijos te hagan caso a la primera”'
description: En la crianza diaria, uno de los desafíos más comunes para los padres es aprender a aceptar un “no” de sus hijos, especialmente después de repetirles ...
createdAt: '2025-09-10T21:13:37.385Z'
creationDate: 2025-09-10 23:13
tags: [Crianza]
imagenDeVistaPrevia: null
url: https://www.lavanguardia.com/cribeo/viral/20250905/11031425/javier-haro-psicologo-infantil-aplicar-6-ideas-tus-hijos-hagan-caso-primera-mmn.html
urlDelIframe: null
dominio: www.lavanguardia.com
---

1. Habla desde el sí.

2. Refresca las consecuencias.

3. Déjales decidir.

4. Resta incertidumbre.

5. Hazlo ya.

6. Prioriza sin malgastar el no.

Aplica la **regla CAFE**:

- CONSTANCIA.

- ASERTIVIDAD.

- FIRMEZA.

- EJEMPLO.

