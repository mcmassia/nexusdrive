---
type: Weblink
title: 'Gallo-Brittonic vs. Insular Celtic: The Inter-rela¬tion¬ships of the Celtic Languages Recon¬sidered'
description: of the development of early Celtic word order patterns out of Indo-European has progressed in an exciting and promising way on the Irish side ; two of...
createdAt: '2025-09-11T06:08:51.885Z'
creationDate: 2025-09-11 08:08
tags: [Lenguas, Celta]
imagenDeVistaPrevia: null
url: https://www.academia.edu/6990656/Gallo_Brittonic_vs_Insular_Celtic_The_Inter_rela_tion_ships_of_the_Celtic_Languages_Recon_sidered?email_work_card=view-paper
urlDelIframe: null
dominio: www.academia.edu
---

The known archaeological and proto-historical inter-relationships of the iron-age Celts do not imply a genetic GaUo-Brittonic as a distinct proto-language isolated from other emerging Celtic dialects at a specific horizon within a geographical homeland. Rather, Britain was rendered 'Gallo-Brittonic' by being irradiated by successive waves of Gallicising influences from the central La Tene and HaUstatt wnes through the course of the last millennium BC (a process congruent with the archaeological framework of 'Cumulative Celticity'6). In Ireland and the Iberian Peninsula, these influences were, especiaUy in the later centuries BC, weaker and less continuous. Therefore, a model of dialects in degrees of contact is more suitable than the traditional family-tree model, which im plies an early mutual isolation.

