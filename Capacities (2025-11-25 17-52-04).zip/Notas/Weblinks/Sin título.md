---
type: Weblink
title: Sin título
description: null
createdAt: '2025-09-11T12:06:51.431Z'
creationDate: 2025-09-11 14:06
tags: []
imagenDeVistaPrevia: null
url: https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d8960.448883087874!2d-6.281103223278762!3d36.51257978385821!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd0dd234dc8cc9b5%3A0xb58c24de52475f5a!2sSalesianos%20C%C3%A1diz%20%7C%20Colegio%20San%20Ignacio!5e1!3m2!1ses!2ses!4v1728302823223!5m2!1ses!2ses
urlDelIframe: null
dominio: www.google.com
---


