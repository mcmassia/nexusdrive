---
type: Weblink
title: "Resolución de 26 de junio de 2024, de la Dirección General de Formación Profesional, por la que se\ndictan Instrucciones para regular aspectos relativos a la organización y al funcionamiento del\ncurso 2024/2025 en la Comunidad Autónoma de Andalucía"
description: null
createdAt: '2025-09-11T08:20:55.082Z'
creationDate: 2025-09-11 10:20
tags: [FormaciónProfesional, Legislación, Educación, Andalucía]
imagenDeVistaPrevia: null
url: https://www.juntadeandalucia.es/educacion/portals/delegate/content/6f11c33a-cf6d-4a7c-b7d7-f43a1dd18d8e/Resoluci%C3%B3n%20de%2026%20de%20junio%20de%202024%20por%20la%20que%20se%20dictan%20Instrucciones%20para%20regular%20aspectos%20relativos%20a%20la%20organizaci%C3%B3n%20y%20al%20funcionamiento%20del%20curso%202024/2025%20en%20Andaluc%C3%ADa
urlDelIframe: null
dominio: www.juntadeandalucia.es
---



Quinta. Proyecto Intermodular.

1. El Proyecto Intermodular de aprendizaje colaborativo se impartirá en los ciclos formativos de
grado básico, tendrá un aprendizaje colaborativo vinculado a sus tres ámbitos (ámbito de
Comunicación y Ciencias Sociales, ámbito de Ciencias Aplicadas y ámbito profesional) con una
carga lectiva de 2 horas semanales y se desarrollará durante el segundo curso del ciclo
formativo.

2. El Proyecto Intermodular de aprendizaje colaborativo de grado básico se llevará a cabo
mediante una metodología basada en retos, aprendizaje colaborativo. Cada equipo docente
diseñará uno o varios retos que impliquen la activación de varios resultados de aprendizaje
contenidos en más de un módulo profesional del ciclo. Se trabajarán transversalmente los
resultados de aprendizaje y criterios de evaluación que figuran en el Anexo I punto 9 de estas
Instrucciones.

3. El Proyecto Intermodular en los ciclos formativos de grado medio, tendrá un seguimiento y
tutorización individual y colectiva del proyecto, con una carga lectiva de 2 horas semanales y se
desarrollará durante el segundo curso del ciclo formativo. Se trabajarán transversalmente los
resultados de aprendizaje y criterios de evaluación que figuran en Anexo I punto 10 de estas
Instrucciones.

    4. El Proyecto Intermodular en los ciclos formativos de grado superior, con la denominación específica que corresponda, según regula el Real Decreto 500/2024, de 21 de mayo, por el que se modifican determinados reales decretos por los que se establecen títulos de Formación Profesional de grado superior y se fijan sus enseñanzas mínimas, tendrá carácter integrador de los conocimientos incorporados en los módulos profesionales que configuran el ciclo formativo, con especial atención a los elementos de búsqueda de información, innovación, investigación aplicada y emprendimiento, vinculados a los resultados de aprendizaje en función de las características de su entorno productivo. Existirá un seguimiento y tutorización individual y colectivo del proyecto para lo cual tendrá una carga lectiva de 2 horas semanales en segundo curso. 

    5. El Proyecto Intermodular en ciclo formativo de grado medio y superior tendrá carácter integrador y complementario con el resto de módulos profesionales del ciclo formativo. 

    6. Los departamentos de las correspondientes familias profesionales, determinarán en el marco de la programación didáctica de cada módulo profesional, las especificaciones relativas a este Proyecto Intermodular.

