---
type: Weblink
title: Customising your Daily Note Template
description: This video shows you an idea for creating a daily note template, using tables, headings and to-do blocks to create a functional space to support you t...
createdAt: '2025-09-10T06:43:32.689Z'
creationDate: 2025-09-10 08:43
tags: [Capacities]
imagenDeVistaPrevia: null
url: https://www.youtube.com/watch?v=rzjT4iWDzhU
urlDelIframe: https://www.youtube.com/embed/rzjT4iWDzhU
dominio: www.youtube.com
---


