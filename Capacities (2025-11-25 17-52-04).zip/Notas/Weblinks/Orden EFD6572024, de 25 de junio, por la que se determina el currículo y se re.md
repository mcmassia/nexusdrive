---
type: Weblink
title: Orden EFD/657/2024, de 25 de junio, por la que se determina el currículo y se regulan determinados aspectos organizativos para los ciclos formativos de grado medio en el ámbito de gestión del Ministerio de Educación, Formación Profesional y Deportes.
description: null
createdAt: '2025-09-11T07:43:10.475Z'
creationDate: 2025-09-11 09:43
tags: [FormaciónProfesional, Legislación, Educación]
imagenDeVistaPrevia: null
url: https://www.boe.es/diario_boe/txt.php?id=BOE-A-2024-13179
urlDelIframe: null
dominio: www.boe.es
---

Artículo 9. Proyecto intermodular.
1. El proyecto intermodular tendrá carácter integrador de los resultados de aprendizaje de los módulos profesionales que configuran el ciclo formativo, con especial atención a los elementos de búsqueda de información, innovación, investigación aplicada, resolución de retos o proyectos y emprendimiento, vinculados a los resultados de aprendizaje de los correspondientes a cada uno de los ciclos formativos a que hace referencia el artículo 1.2.

2. Con carácter general el proyecto intermodular será asumido por el profesorado que imparta docencia en segundo curso de entre los que tengan atribución docente según el anexo III de cada uno de los reales decretos que establecen los ciclos formativos a que hace referencia el artículo 1.2, en los módulos profesionales vinculados a unidades de competencia. El resto del equipo docente que pueda resultar implicado en el proyecto contará con un reconocimiento de una hora no lectiva en su horario personal, en los términos que se establezca en las instrucciones de principio de curso.

3. El proyecto intermodular se desarrollará durante el segundo curso, sin perjuicio de que los centros puedan contemplar periodos preparatorios a partir del segundo trimestre del primer curso.

4. El horario asignado al proyecto intermodular contará obligatoriamente con una hora lectiva semanal.

5. El proyecto intermodular tendrá, por definición, carácter grupal, salvo excepciones justificadas que deberán ser debidamente autorizadas por la administración educativa.

6. Existirá un seguimiento y tutorización individual y colectiva del proyecto, que se desarrollará de forma simultánea al resto de los módulos profesionales de segundo curso.

7. El equipo docente establecerá, al comienzo de cada curso académico, uno o varios retos para el proyecto intermodular. Estos retos tendrán una temática relacionada con la especialidad del ciclo y supondrán una simulación de situaciones reales que puedan darse en el sector productivo. Este proyecto activará resultados de aprendizaje de un conjunto de módulos profesionales.

8. El currículo del proyecto intermodular expresado en forma de resultados de aprendizaje y criterios de evaluación es el contenido en el anexo I de esta orden.

9. La evaluación del proyecto será continua y formativa a lo largo de su duración temporal. Con independencia del carácter colectivo de la forma de agrupación, la evaluación y calificación será individual para cada uno de los alumnos y alumnas y deberá presentarse de manera oral ante el equipo docente, al que, en su caso, podrá incorporarse el tutor o tutora de empresa.



## #Currículo Proyecto intermodular de grado medio
Módulo Profesional: Proyecto intermodular.

Duración: 50 horas.

Código: 1713.

### Resultados de aprendizaje y criterios de evaluación.

1. Caracteriza las empresas del sector atendiendo a su organización y al tipo de producto o servicio que ofrecen.

a) Se han identificado las empresas tipo más representativas del sector.

b) Se ha descrito la estructura organizativa de las empresas.

c) Se han caracterizado los principales departamentos.

d) Se han determinado las funciones de cada departamento.

e) Se ha evaluado el volumen de negocio de acuerdo a las necesidades de los clientes.

f) Se ha definido la estrategia para dar respuesta a las demandas.

g) Se han valorado los recursos humanos y materiales necesarios.

h) Se ha realizado el seguimiento de los resultados de acuerdo a la estrategia aplicada.

i) Se han relacionado los productos o servicios con su posible contribución a los ODS (Objetivos de Desarrollo Sostenible).

2. Plantea soluciones a las necesidades del sector teniendo en cuenta la viabilidad de las mismas, los costes asociados y elaborando un pequeño proyecto.

a) Se han identificado las necesidades.

b) Se han planteado en grupo posibles soluciones.

c) Se ha obtenido la información relativa a las soluciones planteadas.

d) Se han identificado aspectos innovadores que puedan ser de aplicación.

e) Se ha realizado el estudio de viabilidad técnica.

f) Se han identificado las partes que componen el proyecto.

g) Se han previsto los recursos materiales y humanos para realizarlo.

h) Se ha realizado el presupuesto económico correspondiente.

i) Se ha definido y elaborado la documentación para su diseño.

j) Se han identificado los aspectos relacionados con la calidad del proyecto.

k) Se han presentado en público las ideas más relevantes de los proyectos propuestos.

3. Planifica la ejecución de las actividades propuestas a la solución planteada, determinando el plan de intervención y elaborando la documentación correspondiente.

a) Se han temporizado las secuencias de las actividades.

b) Se han determinado los recursos y la logística de cada actividad.

c) Se han identificado permisos y autorizaciones en caso de ser necesarios.

d) Se han identificado las actividades que implican riesgos en su ejecución.

e) Se ha tenido en cuenta el plan de prevención de riesgos y los medios y equipos necesarios.

f) Se han asignado recursos materiales y humanos a cada actividad.

g) Se han tenido en cuenta posibles imprevistos.

h) Se han propuesto soluciones a los posibles imprevistos.

i) Se ha elaborado la documentación necesaria.

4. Realiza el seguimiento de la ejecución de las actividades planteadas, verificando que se cumple con la planificación.

a) Se ha definido el procedimiento de seguimiento de las actividades.

b) Se ha verificado la calidad de los resultados de las actividades.

c) Se han identificado posibles desviaciones de la planificación y/o los resultados esperados.

d) Se ha informado de las desviaciones en caso de ser necesario.

e) Se han solucionado las desviaciones y se han documentado las intervenciones.

f) Se ha definido y elaborado la documentación necesaria para la evaluación de las actividades y del proyecto en su conjunto.

5. Transmite información con claridad, de manera ordenada y estructurada.

a) Se ha mantenido una actitud ordenada y metódica en la transmisión de la información.

b) Se ha transmitido información verbal tanto horizontal como verticalmente.

c) Se ha transmitido información entre los miembros del grupo utilizando medios informáticos.

d) Se han conocido los términos técnicos en otras lenguas que sean estándares del sector.


