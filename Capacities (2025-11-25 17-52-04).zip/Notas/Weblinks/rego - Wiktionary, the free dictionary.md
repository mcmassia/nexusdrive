---
type: Weblink
title: rego - Wiktionary, the free dictionary
description: null
createdAt: '2025-09-10T07:50:32.260Z'
creationDate: 2025-09-10 09:50
tags: [Recurso, Lenguas]
imagenDeVistaPrevia: null
url: https://en.wiktionary.org/wiki/rego#Latin
urlDelIframe: null
dominio: en.wiktionary.org
---

**Entrada ejemplo para usar rápidamente Wiktionary**

