---
type: Weblink
title: ITALO-CELTIC ORIGINS AND PREHISTORIC DEVELOPMENT OF THE IRISH LANGUAGE
description: ITALO-CELTIC ORIGINS AND PREHISTORIC DEVELOPMENT OF THE IRISH LANGUAGE
createdAt: '2025-09-11T06:10:01.172Z'
creationDate: 2025-09-11 08:10
tags: [Lenguas, Celta]
imagenDeVistaPrevia: null
url: https://www.academia.edu/28199786/ITALO_CELTIC_ORIGINS_AND_PREHISTORIC_DEVELOPMENT_OF_THE_IRISH_LANGUAGE?email_work_card=view-paper
urlDelIframe: null
dominio: www.academia.edu
---

This article explores the Italic and Celtic connections in the development of the Irish language, emphasizing the phonological and morphological changes over time. It synthesizes previous research, particularly the contributions of Cowgill, Rix, and Greene, to address unresolved issues in the historical linguistics of Old Irish. The author's own analyses and reconstructions build upon these foundational works, highlighting the intricate interplay of language evolution and analogical processes.

