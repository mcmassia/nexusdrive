---
type: Weblink
title: Cargando Hojas de cálculo de Google
description: null
createdAt: '2025-09-11T16:34:46.884Z'
creationDate: 2025-09-11 18:34
tags: []
imagenDeVistaPrevia: null
url: https://docs.google.com/spreadsheets/d/1YSYoV5VlrPXYGIRJV73StUNq-ERHYxly/edit?usp=drive_link&ouid=115043862614468397993&rtpof=true&sd=true
urlDelIframe: null
dominio: docs.google.com
---


