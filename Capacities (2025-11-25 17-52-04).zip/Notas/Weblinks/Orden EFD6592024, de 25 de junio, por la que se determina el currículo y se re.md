---
type: Weblink
title: Orden EFD/659/2024, de 25 de junio, por la que se determina el currículo y se regulan determinados aspectos organizativos para los ciclos formativos de grado superior en el ámbito de gestión del Ministerio de Educación, Formación Profesional y Deportes.
description: null
createdAt: '2025-09-11T07:48:12.546Z'
creationDate: 2025-09-11 09:48
tags: [FormaciónProfesional, Legislación, Educación]
imagenDeVistaPrevia: null
url: https://www.boe.es/buscar/doc.php?id=BOE-A-2024-13181
urlDelIframe: null
dominio: www.boe.es
---


