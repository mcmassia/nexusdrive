---
type: Weblink
title: BOE-A-2023-16889 Real Decreto 659/2023, de 18 de julio, por el que se desarrolla la ordenación del Sistema de Formación Profesional.
description: null
createdAt: '2025-09-10T16:27:05.525Z'
creationDate: 2025-09-10 18:27
tags: []
imagenDeVistaPrevia: null
url: https://www.boe.es/eli/es/rd/2023/07/18/659/con
urlDelIframe: null
dominio: www.boe.es
---


