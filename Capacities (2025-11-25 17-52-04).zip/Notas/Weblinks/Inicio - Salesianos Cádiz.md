---
type: Weblink
title: Inicio - Salesianos Cádiz
description: Página oficial Salesianos Cádiz
createdAt: '2025-09-11T12:07:44.088Z'
creationDate: 2025-09-11 14:07
tags: []
imagenDeVistaPrevia: null
url: https://cadiz.salesianos.edu/
urlDelIframe: https://cadiz.salesianos.edu/embed/#?secret=Wn6Ne3MiBb
dominio: cadiz.salesianos.edu
---


