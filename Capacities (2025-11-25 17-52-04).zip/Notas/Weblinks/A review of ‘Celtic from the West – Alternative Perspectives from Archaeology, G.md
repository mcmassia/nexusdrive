---
type: Weblink
title: A review of ‘Celtic from the West – Alternative Perspectives from Archaeology, Genetics, Language and literature’, by Barry Cunliffe & John Koch (edit...
description: A review of ‘Celtic from the West – Alternative Perspectives from Archaeology, Genetics, Language and literature’, by Barry Cunliffe & John Koch (edit...
createdAt: '2025-09-11T06:07:21.045Z'
creationDate: 2025-09-11 08:07
tags: [Lenguas, Celta]
imagenDeVistaPrevia: null
url: https://www.academia.edu/66047127/A_review_of_Celtic_from_the_West_Alternative_Perspectives_from_Archaeology_Genetics_Language_and_literature_by_Barry_Cunliffe_and_John_Koch_editors_Oxford_Books_Oxford_2010_384_pp_40_?email_work_card=view-paper
urlDelIframe: null
dominio: www.academia.edu
---

Celtic from the West presents a compelling argument that the origins of the Celtic language family lie in the Atlantic Zone, particularly in the Iberian Peninsula, challenging the traditional views that trace Celtic to Central Europe during the Iron Age. The editors compile evidence from various fields, including archaeology, genetics, and linguistics, advocating for a re-evaluation of historical perspectives surrounding the Proto-Celtic language. This collection not only investigates the possible re-classification of Tartessian as Celtic but also raises crucial questions regarding the development of the Celtic languages and their connections with other language families.

