---
type: Weblink
title: RESOLUCIÓN DE 10 DE SEPTIEMBRE DE 2025, DE LA DIRECCIÓN GENERAL DE FORMACIÓN PROFESIONAL Y EDUCACIÓN PERMANENTE, POR LA QUE SE PUBLICA LA CONCRECIÓN CURRICULAR DE LOS MÓDULOS OPTATIVOS AUTORIZADOS, EN EL MARCO DEL PROCEDIMIENTO ESTABLECIDO PARA SU DISEÑO Y AUTORIZACIÓN EN LOS CICLOS FORMATIVOS DE GRADO MEDIO Y SUPERIOR EN LOS CENTROS DOCENTES DE ANDALUCÍA PARA EL CURSO 2025/26.
description: null
createdAt: '2025-09-11T09:07:54.184Z'
creationDate: 2025-09-11 11:07
tags: [FormaciónProfesional, Andalucía, Legislación, Educación]
imagenDeVistaPrevia: null
url: https://drive.google.com/file/d/1yRPW0ex9nOJiliIMTnm--Ij_4vH6PnRv/view?usp=sharing
urlDelIframe: null
dominio: drive.google.com
---

Currículo módulos optativos CFGM y CFGS Andalucía 2025/2026

- las programaciones de los módulos optativos autorizados deben ser realizadas por cada Centro debido al enorme número de ellos.

