---
type: Weblink
title: A case for Tartessian as Celtic Language
description: For Celtic studies in Britain and Ireland, and the wider &#39;Englishspeaking world&#39;, ancient Portugal and Spain do not often figure as part of th...
createdAt: '2025-09-11T06:01:51.532Z'
creationDate: 2025-09-11 08:01
tags: [Lenguas, Celta]
imagenDeVistaPrevia: null
url: https://www.academia.edu/92989403/A_case_for_Tartessian_as_Celtic_Language?email_work_card=view-paper
urlDelIframe: null
dominio: www.academia.edu
---

For Celtic studies in Britain and Ireland, and the wider 'Englishspeaking world', ancient Portugal and Spain do not often figure as part of the field's primary subject matter. There is a long-established idea that the Celts and the Celtic languages originated in central Europe and that they spread from there with the Hallstatt and La Tène archaeological cultures during the Iron Age (VIIIth-Ist centuries BC), movements that have usually been envisioned as progressing overland until they reached the English Channel (Collis 2003, 93-132). Therefore, the Celts of the Iberian Peninsula would belong to a separate line of development from those of Britain and Ireland. Whether one believes in a Celtic family tree with an Insular Celtic or a Gallo-Brittonic, Hispano-Celtic would thus not be a particularly close relative of Brittonic and Goidelic (Koch 1992a; De Bernardo 2006). However, more recently, archaeologists have taken an interest in the Atlantic Late Bronze Age of the XIIIth to VIIIth centuries BC (e.g. Ruiz-Gálvez 1998). At this earlier horizon, Britain, Ireland, and Armorica were in direct and intense contact by sea with the western Iberian Peninsula, as can be seen in shared types of feasting equipment and weapons, reflected, for example, in the contents of the mid Xth-century Huelva deposition (Ruiz-Gálvez 1995; Needham & Bowman 2005; Burgess & O'Connor 2008) and the iconography of the 'warrior stelae' (Celestino 2001; Harrison 2004). Against this background, Barry Cunliffe, 2001, 261-310, has proposed the origins of the Celtic languages should be sought in the maritime networks of the Atlantic Zone, which reached their peak of intensity in the Late Bronze Age and then fell off sharply at the Bronze-Iron Transition (IXth-VIIth centuries BC). After reviewing some of the earliest linguistic evidence from the Iberian Peninsula-viewing this from my accustomed perspective based in the early Insular Celtic languages and, to a lesser extent, Gaulish-I have concluded that there is also case to be made from the philological side in favour of an origin of the Celtic languages in the Atlantic west (2009).

