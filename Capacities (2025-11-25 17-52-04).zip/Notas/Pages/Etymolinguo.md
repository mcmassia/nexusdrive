---
type: Page
title: Etymolinguo
description: null
icon: null
createdAt: '2025-10-20T16:13:29.815Z'
creationDate: 2025-10-20 18:13
modificationDate: 2025-10-20 18:20
tags: []
imagenDePortada: null
---




[https://chat.deepseek.com/a/chat/s/f8e1b346-f0d6-4d5a-af27-4a0e56037657](https://chat.deepseek.com/a/chat/s/f8e1b346-f0d6-4d5a-af27-4a0e56037657)

[https://chatgpt.com/c/671f4583-e8bc-8013-9528-efe3c6cd8aed](https://chatgpt.com/c/671f4583-e8bc-8013-9528-efe3c6cd8aed)

[https://gemini.google.com/app/8719dba68fa04ebf](https://gemini.google.com/app/8719dba68fa04ebf)



[ETYMOLINGUO: VERBARIO](https://docs.google.com/spreadsheets/d/1S92yiOnEh7Wa7yeRtIXMCI5oPp7em-IAyD4b_5gRJBY/edit?gid=1340019398#gid=1340019398)

[ETYMOLINGUO VERBARIO, PLANTILLA](https://docs.google.com/document/d/1znW26r9NZdHOFLooIlbeyETuFOn8IOBKAEMrJX386_M/edit?tab=t.0#heading=h.vgy9txoqqi48)

[Radices latine e greche](https://docs.google.com/spreadsheets/d/1wjrjFMhk_I6hrxsoprexHU2wUrGyufyiS9G67fHCHwk/edit?gid=0#gid=0)

[Core Word Vocabulary for International Communication](https://docs.google.com/spreadsheets/d/1o88Q5beFwXKF6g-kQTydnx6EfAPvCh0x3ETq685CWi0/edit?gid=1349482099#gid=1349482099)

[LOJBAN ROOT WORDS & LINGUO](https://docs.google.com/spreadsheets/d/1GI9MSvlU9v1jrbl3iQHIYap1BVwCvElZpTojpt0hkdM/edit?gid=0#gid=0)



[Wiktionary](https://en.wiktionary.org/wiki/rego#Latin)


