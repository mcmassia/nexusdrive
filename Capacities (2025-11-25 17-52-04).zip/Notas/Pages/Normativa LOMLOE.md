---
type: Page
title: Normativa LOMLOE
description: null
icon: null
createdAt: '2025-09-10T15:08:31.127Z'
creationDate: 2025-09-10 17:08
modificationDate: 2025-09-10 18:37
tags: [Legislación, Educación]
imagenDePortada: null
---



# Documentación oficial

- [Ley de Educación - | Ministerio de Educación y Formación Profesional (educacionyfp.gob.es)](https://educagob.educacionyfp.gob.es/lomloe/ley.html)

- [Ley Orgánica 3/2020, de 29 de diciembre, por la que se modifica la Ley Orgánica 2/2006, de 3 de mayo, de Educación.](https://www.boe.es/buscar/act.php?id=BOE-A-2020-17264)

- [BOE-A-2022-1654 Real Decreto 95/2022, de 1 de febrero, por el que se establece la ordenación y las enseñanzas mínimas de la Educación Infantil.](https://www.boe.es/eli/es/rd/2022/02/01/95/con)

    #### Artículo 12. Evaluación.

    La evaluación será global, continua y formativa. La observación directa y sistemática constituirá la técnica principal del proceso de evaluación.

    La evaluación en esta etapa estará orientada a identificar las condiciones iniciales individuales y el ritmo y características de la evolución de cada niño o niña. A estos efectos, se tomarán como referencia los criterios de evaluación establecidos para cada ciclo en cada una de las áreas.

    El proceso de evaluación deberá contribuir a mejorar el proceso de enseñanza y de aprendizaje mediante la valoración de la pertinencia de las estrategias metodológicas y de los recursos utilizados. Con esta finalidad, todos los profesionales implicados evaluarán su propia práctica educativa.

    Los padres, las madres, los tutores y las tutoras legales deberán participar y apoyar la evolución del proceso educativo de sus hijos, hijas, tutelados o tuteladas, así como conocer las decisiones relativas a la evaluación y colaborar en las medidas que adopten los centros para facilitar su progreso educativo.

- [BOE-A-2022-3296 Real Decreto 157/2022, de 1 de marzo, por el que se establecen la ordenación y las enseñanzas mínimas de la Educación Primaria.](https://www.boe.es/buscar/doc.php?id=BOE-A-2022-3296)

    #### Artículo 26. Actas de evaluación.

    - 1. Las actas de evaluación se extenderán para cada uno de los cursos y se cerrarán al término del período lectivo ordinario. Comprenderán, al menos, la relación nominal del alumnado que compone el grupo, junto con los resultados de la evaluación de las áreas o ámbitos y las decisiones sobre promoción y permanencia.

    - 2. Los resultados de la evaluación se expresarán en los términos siguientes: «Insuficiente (IN)», para las calificaciones negativas y «Suficiente (SU)», «Bien (BI)», «Notable (NT)», o «Sobresaliente (SB)», para las calificaciones positivas.

    - 3. En el caso de los ámbitos que integren distintas áreas, el resultado de la evaluación se expresará mediante una única calificación, sin perjuicio de los procedimientos que puedan establecerse para mantener informados de su evolución en las diferentes áreas al alumno o alumna y a sus padres, madres, tutores o tutoras legales.

    - 4. Las actas de evaluación serán firmadas por el tutor o la tutora del grupo y llevarán el visto bueno de la persona titular de la dirección del centro.

- [BOE-A-2022-4975 Real Decreto 217/2022, de 29 de marzo, por el que se establece la ordenación y las enseñanzas mínimas de la Educación Secundaria Obligatoria.](https://www.boe.es/eli/es/rd/2022/03/29/217/con)

    #### Artículo 31. Actas de evaluación.

    Las actas de evaluación se extenderán para cada uno de los cursos y se cerrarán tras la finalización del período lectivo. Comprenderán la relación nominal del alumnado que compone el grupo junto con los resultados de la evaluación de las materias o ámbitos y las decisiones sobre promoción y permanencia.

    Los resultados de la evaluación se expresarán en los términos «Insuficiente (IN)», para las calificaciones negativas; «Suficiente (SU)», «Bien (BI)», «Notable (NT)», o «Sobresaliente (SB)» para las calificaciones positivas.

    En el caso de los ámbitos que integren distintas materias, el resultado de la evaluación se expresará mediante una única calificación, sin perjuicio de los procedimientos que puedan establecerse para mantener informados de su evolución al alumno o a la alumna y a sus madres, padres, tutoras o tutores legales.

    Las actas de evaluación serán firmadas por todo el profesorado del grupo y llevarán el visto bueno del director del centro.

- [BOE-A-2022-5521 Real Decreto 243/2022, de 5 de abril, por el que se establecen la ordenación y las enseñanzas mínimas del Bachillerato.](https://www.boe.es/eli/es/rd/2022/04/05/243/con)

    #### Artículo 30. Actas de evaluación.

    Las actas de evaluación se extenderán para cada uno de los cursos y se cerrarán tras la finalización del período lectivo después de la convocatoria ordinaria, y tras la convocatoria extraordinaria. Comprenderán la relación nominal del alumnado que compone el grupo junto con los resultados de la evaluación de las materias y las decisiones sobre promoción y permanencia.

    Los resultados de la evaluación reflejados en estas actas se expresarán mediante calificaciones numéricas de cero a diez sin decimales, y se considerarán negativas las calificaciones inferiores a cinco. Cuando el alumnado no se presente a las pruebas extraordinarias se consignará No Presentado (NP).

    En las actas de segundo curso figurará, además, el alumnado con materias no superadas del curso anterior y se recogerá la propuesta de expedición del título de Bachiller, junto con la nota media de la etapa, que se calculará según lo establecido en el artículo 22.4. En este curso se extenderán actas de evaluación de materias pendientes al término del período lectivo ordinario y de la convocatoria de la prueba extraordinaria.

    Para la aplicación de lo previsto en el apartado quinto de la disposición adicional primera, se hará constar además una nota media normalizada, calculada sin tomar en cuenta la calificación de la materia de Religión.

    Las administraciones educativas podrán arbitrar procedimientos para otorgar una Mención Honorífica en una materia o Matrícula de Honor al expediente de los alumnos y alumnas que hayan demostrado un rendimiento académico excelente al final de la etapa.

    Las actas de evaluación serán firmadas por todo el profesorado del grupo y llevarán el visto bueno de la persona titular de la dirección del centro.

- [BOE-A-2022-5139 Ley Orgánica 3/2022, de 31 de marzo, de ordenación e integración de la Formación Profesional.](https://www.boe.es/diario_boe/txt.php?id=BOE-A-2022-5139)

- [PDC 2023/2024 (Diversificación Curricular](https://oriedu.es/wiki/programas-de-diversificacion-curricular-lomloe-2023-2024/)

    ## Características del PDC

    - El PDC está orientado a la consecución del Título de Graduado en ESO y abarca los cursos 3º y 4º ESO. Sus materias están agrupadas en ámbitos, cada uno de los cuales está impartido por el mismo docente. El grupo de este Programa es menos numeroso y recibe clases de un menor número de profesores/as, lo que permite una mejor acción tutorial e individualización del proceso de aprendizaje.

    ### Destinatarios del PDC

    - El PDC está destinado al alumnado con dificultades relevantes de aprendizaje que haya recibido apoyo en 1º y 2º y/o que pueda verse favorecido por esta medida para la obtención del Título de ESO.

    - La propuesta de incorporación la realiza el equipo docente al final de cada curso académico. La incorporación al PDC es voluntaria, previa entrevista con el alumno/a y su familia. Además, requiere evaluación académica y psicopedagógica por parte del equipo docente y el departamento de orientación.

    ### Estructura del PDC

    #### **Ámbitos y materias**

    - Ámbito Lingüístico y Social. Incluye los aspectos básicos del currículo de las materias de Geografía e Historia, y Lengua Castellana y Literatura.

    - Ámbito Científico-Tecnológico. Incluye los aspectos básicos de las materias de Matemáticas, Biología y Geología, y Física y Química.

    - Ámbito Práctico. Incluye los aspectos básicos de la materia de Tecnología y Digitalización.

    - Materias del currículo común. Tres de las materias comunes se cursan en el grupo ordinario de referencia. La materia de Lengua Extranjera puede incluirse en el Ámbito Lingüístico y Social en lugar de cursarse como materia común.

    - Dos horas de tutoría. Una hora de tutoría es específica del programa y la otra se realiza con el grupo ordinario de referencia.

    #### **Estructura horaria de 3º ESO Diversificación**

    - Ámbito Científico-Tecnológico: 7 horas.

    - Ámbito Lingüístico y Social: 7 horas.

    - Ámbito Práctico: 4 horas.

    - Materias:

    - Lengua Extranjera: 3 horas.

        - Educación Física: 2 horas.

        - Educación Plástica, Visual y Audiovisual: 2 horas.

        - *Una de estas dos:* Religión; Atención Educativa: 1 hora.

        - Optativa: 2 horas.

        - Tutoría: 2 horas.

    #### **Estructura horaria de 4º ESO Diversificación**

    - Ámbito Científico-Tecnológico: 6 horas.

    - Ámbito Lingüístico y Social: 6 horas.

    - Ámbito Práctico: 4 horas.

    - Materias:

    - Lengua Extranjera: 4 horas.

        - Educación Física: 2 horas.

        - *Una de estas tres:* Expresión Artística; Formación y Orientación Personal y Profesional; Música: 3 horas.

        - *Una de estas dos:* Religión; Atención Educativa: 1 hora.

        - Optativa: 2 horas.

        - Tutoría: 2 horas.

    ### Diferencias entre el PDC y el PMAR

    - La medida de diversificación del currículo de la LOMCE era el Programa de Mejora del Aprendizaje y el Rendimiento (PMAR). Esta misma medida recibe el nombre de Programa de Diversificación Curricular (PDC) en la LOMLOE. Ambos programas presentan dos grandes diferencias:

    - El PMAR se desarrollaba en 2º y 3º ESO, mientras que el PDC se desarrolla en 3º y 4º ESO.

    - Los requisitos de incorporación a PMAR incluían que el alumno/a hubiera repetido al menos una vez en cualquier etapa; este requisito no existe en el PDC.

    ## PDC en el curso 2023-2024

    ### Implantación progresiva del PDC

    - **Curso 2022-2023:** El PDC (LOMLOE) ha convivido con el antiguo PMAR (LOMCE):

    - En 2º ESO, se ha mantenido PMAR-1. Los estudiantes que forman parte del Programa lo hacen en el grupo «2º ESO PMAR-1».

    - En 3º ESO, ha desaparecido PMAR-2 y se ha introducido el PDC. Los estudiantes que forman parte del Programa lo hacen en el grupo «3º ESO Diversificación».

    - **Curso 2023-2024:** Desaparece PMAR-1 en 2º ESO y se introduce el PDC en 4º ESO:

    - En 3º ESO, se mantiene el PDC, en el grupo «3º ESO Diversificación».

    - En 4º ESO, se introduce el PDC, en el grupo «4º ESO Diversificación».

    ### Incorporación al grupo de «3º ESO Diversificación»

    - En el curso 2023-2024, los estudiantes de 2º y 3º ESO podrán acceder al PDC de 3º ESO cuando así sea propuesto por su equipo docente, siempre que se encuentren en uno de los siguientes casos:

    - Haber cursado 2º ESO en el grupo de PMAR-1; supone la promoción automática a 3º ESO en el grupo de Diversificación.

    - Haber cursado 2º ESO, no estar en condiciones de promocionar y no considerarse beneficiosa la repetición de curso o haberse incorporado tardíamente a la etapa; supone la promoción, con aprendizajes no alcanzados y materias pendientes, de 2º ESO a 3º ESO en el grupo de Diversificación.

    - Haber cursado 3º ESO y no estar en condiciones de promocionar; supone la repetición de 3º ESO en el grupo de Diversificación.

    ### Incorporación al grupo de «4º ESO Diversificación»

    - En el curso 2023-2024, los estudiantes de 3º y 4º ESO podrán acceder al PDC de 4º ESO cuando así sea propuesto por su equipo docente, siempre que se encuentren en uno de los siguientes casos:

    - Haber cursado 3º ESO en el grupo de Diversificación; supone la promoción automática a 4º ESO en el grupo de Diversificación.

    - Haber cursado 4º ESO y no estar en condiciones de titular, siempre que, a fecha de 31 de diciembre de 2024, no superen los 18 años (excepcionalmente, los 19 años); supone la repetición de 4º ESO en el grupo de Diversificación.

- [BOE-A-2023-16889 Real Decreto 659/2023, de 18 de julio, por el que se desarrolla la ordenación del Sistema de Formación Profesional.](Weblinks/BOE-A-2023-16889%20Real%20Decreto%206592023,%20de%2018%20de%20julio,%20por%20el%20que%20se%20desarrolla.md)



# Normativa de referencia

- **Ley Orgánica para la Mejora de la Ley Orgánica de Educación y Programa de Diversificación Curricular:**

- [LOE (2006) con LOMLOE (2020)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-7899&tn=1&p=20201230). Legislación consolidada del BOE.

- **Currículo de ESO y Programa de Diversificación Curricular:**

- [Real Decreto 217/2022, de ordenación y enseñanzas mínimas de la ESO](https://www.boe.es/eli/es/rd/2022/03/29/217). BOE de 30 de marzo de 2022.

    - [Decreto 110/2022, de ordenación y currículo de ESO en Extremadura](http://doe.juntaex.es/pdfs/doe/2022/1640o/22040165.pdf). DOE de 25 de agosto de 2022.

    - [Corrección de errores del Decreto 110/2022, de ordenación y currículo de ESO en Extremadura](http://doe.juntaex.es/pdfs/doe/2022/2220o/22040204.pdf). DOE de 18 de noviembre de 2022

    - [Orden de 24 de marzo de 2023, de los programas de diversificación curricular en Extremadura](https://doe.juntaex.es/pdfs/doe/2023/630o/23050077.pdf). DOE de 31 de marzo de 2023.

    - [https://www.todofp.es/que-estudiar/ciclos.html](https://www.todofp.es/que-estudiar/ciclos.html)

    - [Resolución de 21 de junio de 2022, de la Secretaría de Estado de Educación, por la que se publican los currículos de las enseñanzas de religión católica correspondientes a Educación Infantil, Educación Primaria, Educación Secundaria Obligatoria y Bachillerato.](https://www.boe.es/diario_boe/txt.php?id=BOE-A-2022-10452)
    



# Elementos clave

## Referentes de evaluación

- Los [Criterios de evaluación](Definiciones/Criterios%20de%20evaluaci%C3%B3n.md) son «referentes que indican los niveles de desempeño esperados en el alumnado en las situaciones o actividades a las que se refieren las competencias específicas de cada área en un momento determinado de su proceso de aprendizaje».

- Las [Competencias específicas](Definiciones/Competencias%20espec%C3%ADficas.md) son «desempeños que el alumnado debe poder desplegar en actividades o en situaciones cuyo abordaje requiere de los saberes básicos de cada área. Las competencias específicas constituyen un elemento de conexión entre, por una parte, las competencias clave, y por otra, los saberes básicos de las áreas y los criterios de evaluación».

- Las [Situaciones de aprendizaje](Definiciones/Situaciones%20de%20aprendizaje.md) son «situaciones y actividades que implican el despliegue por parte del alumnado de actuaciones asociadas a competencias clave y competencias específicas, y que contribuyen a la adquisición y desarrollo de las mismas».

## Elementos transversales

- EIN #EducaciónInfantil

    - No existen elementos transversales genéricos y explícitos en sus principios pedagógicos.

- EP #EducaciónPrimaria

    - No existen elementos transversales genéricos y explícitos en sus principios pedagógicos.

- ESO #EducaciónSecundaria

    - la ley señala que aspectos como la comprensión lectora, la expresión oral y escrita, la comunicación audiovisual, la competencia digital, el emprendimiento, el fomento del espíritu crítico y científico, la educación emocional y en valores, la educación para la paz y no violencia y la creatividad deberán trabajarse desde todas las materias. Asimismo, se prevé que la educación para la salud, incluida la afectivo-sexual, la igualdad entre hombres y mujeres, la formación estética y el respeto mutuo y la cooperación entre iguales sean objeto de un tratamiento transversal.

- BACH #Bachillerato

    - No existen elementos transversales genéricos y explícitos en sus principios pedagógicos.

## Ámbitos CFGB #CFGB #FormaciónProfesional

- Ámbito de Ciencias Aplicadas

- Ámbito de Comunicación y Ciencias Sociales

- Están asociados a las competencias clave y tienen desarrollo curricular LOMLOE: competencias específicas, criterios de evaluación y saberes básicos.

- Sus currículos son globalizados y no existe currículo diferenciado por "materias" para los dos ámbitos de ambos cursos de CFGB; solo existe el currículo del ámbito que engloba los elementos curriculares de las "materias".

- La Legislación no prevé que los ámbitos se traten de manera disgregada en materias; sino que precisamente implica una integración de elementos curriculares para facilitar la adquisición de las competencias por los alumnos.

- De hecho, se indica explícitamente en la normativa que la evaluación será de manera global e integradora por ámbitos.

- Por eso el ámbito es una única materia a todos los efectos.

# Desarrollos CCAA

## Andalucía #Andalucía

### [ADIDE-ANDALUCIA Normativa](https://www.adideandalucia.es/index.php?view=normativa)

- #EducaciónInfantil

    - [ADIDE-ANDALUCIA EIN](https://www.adideandalucia.es/?view=disposicion&cat=37)

    - [Instruccion11-2022OrganizacionEducacionInfantil.pdf (adideandalucia.es)](https://www.adideandalucia.es/normas/instruc/Instruccion11-2022OrganizacionEducacionInfantil.pdf)

### #EducaciónPrimaria

- [ADIDE-ANDALUCIA EP](https://www.adideandalucia.es/?view=disposicion&cat=38)

- [Instruccion12-2022OrganizacionEducacionPrimaria.pdf (adideandalucia.es)](https://www.adideandalucia.es/normas/instruc/Instruccion12-2022OrganizacionEducacionPrimaria.pdf)

- [ORDEN de 30 de mayo de 2023](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023EducacionPrimaria.pdf), por la que se desarrolla el currículo correspondiente a la etapa de Educación Primaria en la Comunidad Autónoma de Andalucía, se regulan determinados aspectos de la atención a la diversidad y a las diferencias individuales, se establece la ordenación de la evaluación del proceso de aprendizaje del alumnado y se determina el proceso de tránsito entre las diferentes etapas educativas (BOJA 02-06-2023).

    - [Anexo I - Horario lectivo para la etapa de Educación Primaria](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Primaria-Anexo1.pdf)

    - [Anexo II - Desarrollos curriculares de las diferentes áreas](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Primaria-Anexo2.pdf)

    - [Anexo III - Vinculación de los Objetivos de la etapa con los descriptores operativos del Perfil competencial al término de la etapa de Educación Primaria](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Primaria-Anexo3.pdf)

    - [Anexo IV - Situaciones de Aprendizaje](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Primaria-Anexo4.pdf)

    - [Anexo V - MODELO DE PROGRAMA DE ATENCIÓN A LA DIVERSIDAD Y A LAS DIFERENCIAS INDIVIDUALES](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Primaria-Anexo5.pdf)

    - [Anexo VI - Documentos oficiales de evaluación](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Primaria-Anexo6.pdf)

- [DECRETO 101/2023](https://www.adideandalucia.es/normas/decretos/Decreto101-2023EducacionPrimaria.pdf), de 9 de mayo, por el que se establece la ordenación y el currículo de la etapa de Educación Primaria en la Comunidad Autónoma de Andalucía (BOJA 15-05-2023)

### #EducaciónSecundaria

- [ADIDE-ANDALUCIA ESO)](https://www.adideandalucia.es/?view=disposicion&cat=85)

- [Instruccion1-2022OrganizacionESO.pdf (adideandalucia.es)](https://www.adideandalucia.es/normas/instruc/Instruccion1-2022OrganizacionESO.pdf)

- [Anexo I - Horario lectivo semanal para la etapa de Educación Secundaria Obligatoria](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo1.pdf).

- [Anexo II - Materias comunes obligatorias y optativas](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo2.pdf).

- [Anexo III - Materias optativas propias de la Comunidad Andaluza](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo3.pdf).

- [Anexo IV - Ámbitos del Programa de Diversificación Curricular](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo4.pdf).

- [Anexo V - Ámbitos de Ciclos Formativos de Grado Básico](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo5.pdf).

- [Anexo VI - Vinculación de los Objetivos de la etapa con el Perfil de salida al término de la enseñanza básica](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo6.pdf).

- [Anexo VII - Situaciones de Aprendizaje](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo7.pdf).

- [Anexo VIII - Modelo de programa de atención a la diversidad y a las diferencias individuales](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo8.pdf).

- [Anexo IX - Documentos oficiales de evaluación](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo9.pdf).

- [Anexo X - CERTIFICACIÓN ACADÉMICA DE ESTUDIOS CURSADOS EN EDUCACIÓN SECUNDARIA OBLIGATORIA](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023ESO-Anexo10.pdf).

### #Bachillerato

- [ADIDE-ANDALUCIA BACH](https://www.adideandalucia.es/?view=disposicion&cat=13)

- [Instruccion13-2022OrganizacionBachillerato.pdf (adideandalucia.es)](https://www.adideandalucia.es/normas/instruc/Instruccion13-2022OrganizacionBachillerato.pdf)

- [DECRETO 103/2023](https://www.adideandalucia.es/normas/decretos/Decreto103-2023Bachillerato.pdf), de 9 de mayo, por el que se establece la ordenación y el currículo de la etapa de Bachillerato en la Comunidad Autónoma de Andalucía (BOJA 15-05-2023).

- [ORDEN de 30 de mayo de 2023](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato.pdf), por la que se desarrolla el currículo correspondiente a la etapa de Bachillerato en la Comunidad Autónoma de Andalucía, se regulan determinados aspectos de la atención a la diversidad y a las diferencias individuales y se establece la ordenación de la evaluación del proceso de aprendizaje del alumnado (BOJA 02-06-2023).

- [Anexo I - Horario lectivo](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo1.pdf).

- [Anexo II - Materias comunes y Materias específicas de modalidad](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo2.pdf).

- [Anexo III - Materias optativas propias de la Comunidad Andaluza](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo3.pdf).

- [Anexo IV - Vinculación de los Objetivos de la etapa con el perfil competencial al término de la etapa de Bachillerato](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo4.pdf).

- [Anexo V - Situaciones de Aprendizaje](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo5.pdf).

- [Anexo VI - Modelo de programa de atención a la diversidad y a las diferencias individuales](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo6.pdf).

- [Anexo VII - Documentos oficiales de evaluación](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo7.pdf).

- [Anexo VIII Certificación de estudios cursados en Bachillerato](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023Bachillerato-Anexo8.pdf).

### #FormaciónProfesional

## Aragón #Aragón

- [Orden ECD 853 2002 Curriculo y evaluación de Infantil.pdf - Google Drive](https://drive.google.com/file/d/1zw98zs5KKgsCFSEgEssqmYRfnfZWcqZ9/view)

- [Orden ECD 1112/2022 - Currículo EP Aragón](https://www.boa.aragon.es/cgi-bin/EBOA/BRSCGI?CMD=VEROBJ&MLKOB=1232424620909&type=pdf)

- [Orden del Consejero de Educación, Cultura y Deporte, por la que se aprueban el currículo y las características de la evaluación de la Educación Primaria y se autoriza su aplicación en los centros docentes de la Comunidad Autónoma de Aragón](https://educa.aragon.es/documents/20126/519073/Orden+currículo+Educación+Primaria+Aragón+y+Anexos+%28versión+definitiva%29+FIRMADA.pdf/acf79e0c-a2c3-fce1-f109-2f6990baa1de?t=1658148056286)

## Canarias #Canarias

- [Ordenación de las enseñanzas LOMLOE Canarias (ccoo.es)](https://canarias.fe.ccoo.es/0b18b74e01901c629d90fc0ce17715e8000063.pdf)

- [848 DECRETO 30/2023, de 16 de marzo, por el que se establece la ordenación y el currículo de la Educación Secundaria Obligatoria y del Bachillerato en la Comunidad Autónoma de Canarias.](http://www.gobiernodecanarias.org/boc/2023/058/001.html)

- [1859 ORDEN de 31 de mayo de 2023, por la que se regulan de evaluación y la promoción del alumnado que cursa las etapas de la Educación Infantil, la Educación Primaria, la Educación Secundaria Obligatoria y el Bachillerato, y se establecen los requisitos para la obtención de los títulos correspondientes, en la Comunidad Autónoma de Canarias.](http://www.gobiernodecanarias.org/boc/2023/110/001.html)

    - [PDF completo con anexos - documentos oficiales evaluación](http://sede.gobiernodecanarias.org/boc/boc-a-2023-110-1859.pdf)

- [Currículos de las materias y los ámbitos de la Educación Secundaria Obligatoria | Consejería de Educación, Universidades, Cultura y Deportes | Gobierno de Canarias](https://www.gobiernodecanarias.org/educacion/web/secundaria/informacion/ordenacion-curriculo/curriculos-de-la-educacion-secundaria-obligatoria-eso/)

- [Currículos LOMLOE de los Ciclos Formativos de Grado Básico | Consejería de Educación, Formación Profesional, Actividad Física y Deportes | Gobierno de Canarias](https://www.gobiernodecanarias.org/educacion/web/formacion_profesional/ensenanzas/fpgb/curriculos_fpgb/)

## Extremadura #Extremadura

- [Educarex - Curriculum de Primaria, ESO y Bachillerato](https://educarex.es/sistema-educativo/curriculum-educacion.html#ct122)

- [DECRETO 98/2022,de 20 de julio, por el que se establecen la ordenación  y el currículo de la Educación Infantil para la Comunidad Autónoma de  Extremadura](http://doe.juntaex.es/pdfs/doe/2022/1430o/22040148.pdf)

- [DECRETO 107/2022, de 28 de julio, por el que se establecen la ordenación y el currículo de la Educación Primaria para la Comunidad Autónoma de Extremadura.](http://doe.juntaex.es/pdfs/doe/2022/1510o/22040159.pdf)

- [DECRETO 110/2022, de 22 de agosto, por el que se establecen la ordenación y el currículo de la Educación Secundaria Obligatoria para la Comunidad Autónoma de Extremadura.](https://doe.juntaex.es/pdfs/doe/2022/1640o/22040165.pdf)

    - [Decreto 110/2022 formato html](https://doe.juntaex.es/otrosFormatos/html.php?xml=2022040165&anio=2022&doe=1640o)

    - ARTÍCULO 2. DEFINICIONES (ELEMENTOS CURRICULARES)

        - c) [Competencias específicas](Definiciones/Competencias%20espec%C3%ADficas.md): desempeños que el alumnado debe poder desplegar en actividades o situaciones cuyo abordaje requiere de los saberes básicos de cada materia o ámbito. Las competencias específicas constituyen un ^^elemento de conexión^^ entre, por una parte, el Perfil de salida del alumnado y, por otra, los saberes básicos de las materias o ámbitos y los criterios de evaluación.

        - f) [Criterios de evaluación](Definiciones/Criterios%20de%20evaluaci%C3%B3n.md): ^^referentes que indican los niveles de desempeño^^ esperados en el alumnado en las situaciones o actividades a las que se refieren las competencias específicas de cada materia o ámbito en un momento determinado de su proceso de aprendizaje.

    - CAPÍTULO VI - Evaluación, promoción y titulación.

        - Artículo 28. Evaluación de los procesos de enseñanza y aprendizaje.

    - ANEXO II - [SITUACIONES DE APRENDIZAJE](Definiciones/Situaciones%20de%20aprendizaje.md) - Principios y orientaciones generales para el diseño de situaciones de aprendizaje en Educación Secundaria Obligatoria.

        - Las situaciones de aprendizaje favorecen el desarrollo competencial e implican que el alumnado despliegue actuaciones vinculadas a las competencias específicas (y, por tanto, también a las competencias clave), mediante la movilización y articulación de un conjunto de saberes.

        - En las situaciones de aprendizaje deben integrarse todos los elementos necesarios para favorecer la adquisición de competencias, garantizando el derecho a la inclusión a través de la personalización y el Diseño Universal para el Aprendizaje (DUA) en aras de asegurar la presencia, participación y progreso de todo el alumnado, y de lograr aprendices más autónomos, decididos y comprometidos.

        - Desde un enfoque competencial, no tiene sentido establecer una diferenciación nítida entre las situaciones de aprendizaje y las situaciones de evaluación, ya que una misma situación puede servir para promover el desarrollo de una o varias competencias, al tiempo que supone una oportunidad para valorar el nivel de desarrollo competencial del alumnado en un determinado momento de su proceso de aprendizaje.

        - ^^Las evidencias de aprendizaje estarán ligadas a las distintas competencias específicas de las diferentes materias curriculares, tomando como referencia los criterios de evaluación^^ y los distintos contextos de desarrollo del alumnado, especialmente el escolar, el familiar y el social.

        - Las situaciones de aprendizaje deben girar en torno a evidencias secuenciadas que integren los distintos tipos de conocimientos y se aborden alternándose con diferentes niveles de profundidad, desde el reconocimiento y la identificación hasta llegar a procesos de reflexión crítica, autorregulación y creatividad.

    - NOMENCLATURA ELEMENTOS CURRICULARES

        - La numeración de los saberes sigue los criterios que se especifican a continuación:
        — La letra indica el bloque de saberes.
        — El primer dígito indica el subbloque dentro del bloque.
        — El segundo dígito indica los niveles en que se imparte.
        — El tercer dígito indica el saber concreto dentro del subbloque.
        Así, por ejemplo, A.2.3.2. correspondería al segundo saber del segundo subbloque dentro del
        bloque A, que se debe haber trabajado al finalizar 3º de la ESO.

- [DECRETO 109/2022, de 22 de agosto, por el que se establecen la ordenación y el currículo del Bachillerato para la Comunidad Autónoma de Extremadura.](https://doe.juntaex.es/pdfs/doe/2022/1640o/22040164.pdf)

- [DECRETO 14/2022, de 18 de febrero, por el que se regulan la evaluación y la promoción en la Educación Primaria, así como la evaluación, la promoción y la titulación en la Educación Secundaria Obligatoria, el Bachillerato y la Formación Profesional en la Comunidad Autónoma de Extremadura.](http://doe.juntaex.es/pdfs/doe/2022/370o/22040026.pdf)

- [ORDEN de 9 de diciembre de 2022, por la que se regula la evaluación del alumnado en la Educación Infantil, Educación Primaria, Educación Secundaria Obligatoria y Bachillerato en la Comunidad Autónoma de Extremadura.](http://doe.juntaex.es/pdfs/doe/2022/2390o/22050223.pdf)

- [ORDEN de 24 de marzo de 2023 por la que se regulan los programas de  diversificación curricular en los centros docentes que imparten Educación  Secundaria Obligatoria en la Comunidad Autónoma de Extremadura.](https://doe.juntaex.es/pdfs/doe/2023/630o/23050077.pdf)


## Murcia #Murcia

- [LEY 3/2022 (LOMLOE). DESARROLLO CURRICULAR MURCIA](https://www.carm.es/web/pagina?IDCONTENIDO=71651&IDTIPO=100&RASTRO=c1655$m)

### #EducaciónInfantil

- [Decreto n.º 196/2022, de 3 de noviembre, por el que se  establece el currículo de la etapa de Educación Infantil en la  Comunidad Autónoma de la Región de Murcia.](https://www.carm.es/web/descarga?ARCHIVO=Decreto%20196-2022%2C%203%20noviembre%2C%20curriculo%20Ed.Infantil.pdf&ALIAS=ARCH&IDCONTENIDO=180470&IDTIPO=60&RASTRO=c1655$m71651)

    - 14.4. Se establecerán, al menos, tres sesiones de evaluación a lo largo del
    curso, sin perjuicio de otras que se establezcan en la propuesta pedagógica del
    centro. La última sesión de evaluación, que tendrá carácter de evaluación final,
    valorará los resultados a partir de la evaluación continua.
    14.5. En Educación Infantil la [[Promoción del alumnado]] será automática en los distintos
    cursos que conforman la etapa, así como el acceso al primer curso de Educación
    Primaria. En ningún caso se podrá prolongar un año más la escolarización del
    alumnado en esta etapa.

### #EducaciónPrimaria

- [Decreto n.º 209/2022, de 17 de noviembre, por el que se establece la ordenación y el currículo de la Educación Primaria en la Comunidad Autónoma de la Región de Murcia.](https://www.carm.es/web/descarga?ARCHIVO=Decreto%20209-2022%20Educacion%20Primaria.pdf&ALIAS=ARCH&IDCONTENIDO=180807&IDTIPO=60&RASTRO=c1655$m71651)

### #EducaciónSecundaria

- [Decreto n.º 235/2022, de 7 de diciembre, por el que se establece la ordenación y el currículo de la Educación Secundaria Obligatoria en la Comunidad Autónoma de la Región de Murcia.Publicación número 6346 del BORM número 283 de 09/12/2022 (carm.es)](https://www.carm.es/web/descarga?ARCHIVO=Decreto%20n%C2%BA235-2022%2C%20de%207%20dic%20Ordenaci%C3%B3n%20y%20el%20curr%C3%ADculo%20de%20la%20ESO.pdf&ALIAS=ARCH&IDCONTENIDO=181177&IDTIPO=60&RASTRO=c1655$m71651)

### #Bachillerato

- [Decreto n.º 251/2022, de 22 de diciembre, por el que se establece la ordenación y el currículo de Bachillerato en la Comunidad Autónoma de la Región de Murcia.](https://www.carm.es/web/descarga?ARCHIVO=Decreto%20251-2022%20ordenaci%C3%B3n%20y%20curr%C3%ADculo%20Bachillerato.pdf&ALIAS=ARCH&IDCONTENIDO=181356&IDTIPO=60&RASTRO=c1655$m71651)

## Valencia #Valencia

- [ESO: Currículo por materias.](https://ceice.gva.es/es/web/ordenacion-academica/secundaria/curriculo)

- [Currículo - Ordenación Académica - Generalitat Valenciana (gva.es)](https://ceice.gva.es/es/web/ordenacion-academica/secundaria/curriculo)

- [Nou currículum (gva.es)](https://portal.edu.gva.es/noucurriculum/)

- [DECRETO 100/2023](https://www.adideandalucia.es/normas/decretos/Decreto100-2023EducacionInfantil.pdf), de 9 de mayo, por el que se establece la ordenación y el currículo de la etapa de Educación Infantil en la Comunidad Autónoma de Andalucía (BOJA 15-05-2023).

- [ORDEN de 30 de mayo de 2023](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023EducacionInfantil.pdf), por la que se desarrolla el currículo correspondiente a la etapa de Educación Infantil en la Comunidad Autónoma de Andalucía, se regulan determinados aspectos de la atención a la diversidad y a las diferencias individuales, se establece la ordenación de la evaluación del proceso de aprendizaje del alumnado y se determinan los procesos de tránsito entre ciclos y con Educación Primaria (BOJA 02-06-2023).

- [DECRETO 102/2023](https://www.adideandalucia.es/normas/decretos/Decreto102-2023EducacionSecundariaObligatoria.pdf), de 9 de mayo, por el que se establece la ordenación y el currículo de la etapa de Educación Secundaria Obligatoria en la Comunidad Autónoma de Andalucía (BOJA 15-05-2023).

- [ORDEN de 30 de mayo de 2023](https://www.adideandalucia.es/normas/ordenes/Orden30mayo2023EducacionSecundariaObligatoria.pdf), por la que se desarrolla el currículo correspondiente a la etapa de Educación Secundaria Obligatoria en la Comunidad Autónoma de Andalucía, se regulan determinados aspectos de la atención a la diversidad y a las diferencias individuales, se establece la ordenación de la evaluación del proceso de aprendizaje del alumnado y se determina el proceso de tránsito entre las diferentes etapas educativas (BOJA 02-06-2023).
collapsed:: true

    - [[Currículo]], [[Educación Secundaria Obligatoria]], [[Atención a la diversidad]]

    ### Artículo 2. Elementos y estructura del currículo

    collapsed:: true

    ### Artículo 3. Situaciones de aprendizaje.

    collapsed:: true

    ### Artículo 4. Autonomía de los centros docentes.

    collapsed:: true

    ### Artículo 5. Organización curricular de los tres primeros cursos de Educación Secundaria Obligatoria.

    collapsed:: true

    - collapsed:: true

        1. De acuerdo con lo establecido en el artículo 9 del Decreto 102/2023, de 9 de mayo, el alumnado debe cursar de primero a tercero las siguientes las materias:

        - a) Educación Física, Geografía e Historia, Lengua Castellana y Literatura, Primera Lengua Extranjera y Matemáticas, en cada uno de los tres cursos.

        - b) Biología y Geología en primer y tercer curso.

        - c) Física y Química en segundo y tercer curso.

        - d) Música en primer y segundo curso.

        - e) Educación Plástica, Visual y Audiovisual en primer y tercer curso.

        - f) Tecnología y Digitalización en segundo y tercer curso.

        - g) Segunda Lengua Extranjera, en primer curso.

    ### Artículo 6. Organización de cuarto curso de Educación Secundaria Obligatoria.

    collapsed:: true

    ### Artículo 7. Proyectos interdisciplinares propios de los centros.

    collapsed:: true

    ### Artículo 8. Materia Lingüística de carácter transversal.

    collapsed:: true

    ### Artículo 9. Horario.

    collapsed:: true

    ### Artículo 10. Carácter y [[Referentes de la evaluación]] .

    collapsed:: true

    ### Artículo 11. Procedimientos e [[Instrumentos de evaluación]].

    collapsed:: true

    ### Artículo 12. Evaluación inicial.

    collapsed:: true

    ### Artículo 13. Evaluación continua.

    collapsed:: true

    ### Artículo 14. Evaluación a la finalización de cada curso.

    collapsed:: true

    ### Artículo 15. Evaluación de diagnóstico.

    collapsed:: true

    ### Artículo 16. Pruebas o actividades personalizadas extraordinarias.

    collapsed:: true

    ### Artículo 17. Principios y medidas para la evaluación del alumnado con necesidad específica de apoyo educativo.

    collapsed:: true

    ### Artículo 18. [[Promoción del alumnado]] .

    collapsed:: true

    - a) La evolución positiva del alumnado en todas las actividades de evaluación propuestas.

    - b) Que tras la aplicación de medidas de atención a la diversidad y a las diferencias individuales durante el curso el alumnado haya participado activamente con implicación, atención y esfuerzo en las materias no superadas.

    ### Artículo 19. [[Titulación]] .

    collapsed:: true

    - a) La evolución positiva del alumnado en todas las actividades de evaluación propuestas.

    - b) Que tras la aplicación de medidas de atención a la diversidad y a las diferencias individuales durante el curso el alumnado haya participado activamente con implicación, atención y esfuerzo en las materias no superadas.

    ### Artículo 20. Certificación académica de los estudios cursados.

    collapsed:: true

    ### Artículo 21. [[Documentos oficiales de evaluación]] .

    collapsed:: true

    ### Artículo 22. Actas de evaluación.

    collapsed:: true

    ### Artículo 23. Expediente académico.

    collapsed:: true

    ### Artículo 24. Historial académico.

    collapsed:: true

    ### Artículo 25. Informe personal por traslado.

    collapsed:: true

    ### Artículo 26. Consejo orientador.

    collapsed:: true

1. La definición y los elementos del currículo son los establecidos en el artículo 3 del Decreto 102/2023, de 9 de mayo.

2. El currículo de Educación Secundaria Obligatoria, incorporando lo dispuesto en el Real Decreto 217/2022, de 29 de marzo, por el que se establece la ordenación y las enseñanzas mínimas de Educación Secundaria Obligatoria, se fija en los Anexos I, II, III, IV, V y VI con el siguiente desglose:

- a) En el Anexo I se establece el horario lectivo para la etapa de Educación Secundaria Obligatoria.

- b) En el Anexo II se formulan las competencias específicas, los criterios de evaluación y los saberes básicos para cada una de las materias comunes obligatorias y optativas.

- c) En el Anexo III se formulan las competencias específicas, los criterios de evaluación y los saberes básicos para cada una de las materias optativas propias de la Comunidad Andaluza.

- d) En el Anexo IV se formulan las competencias específicas, los criterios de evaluación y los saberes básicos de los ámbitos de los Programas de Diversificación Curricular.

- e) En el Anexo V se formulan las competencias específicas, los criterios de evaluación y los saberes básicos de los ámbitos de los Ciclos Formativos de Grado Básico.

- f) Con el fin de establecer las relaciones entre las competencias clave y los Objetivos de la etapa, se incluye el Anexo VI que determina la vinculación entre dichos Objetivos y Perfil de salida al término de la Enseñanza Básica.

1. Para el desarrollo y la concreción del currículo se tendrá en cuenta la secuenciación establecida en la presente Orden, si bien su carácter flexible permite que los centros docentes puedan agrupar las distintas materias en ámbitos, en función de la necesaria adecuación a su contexto específico, así como a su alumnado, teniendo en cuenta lo recogido en su Proyecto educativo.

2. El profesorado integrante de los distintos departamentos de coordinación didáctica elaborará las programaciones didácticas, según lo dispuesto en el artículo 29 del Decreto 327/2010, de 13 de julio, por el que se aprueba el Reglamento Orgánico de los Institutos de Educación Secundaria, de las materias de cada curso que tengan asignadas, a partir de lo establecido en los Anexos II, III, IV y V, mediante la concreción de las competencias específicas, de los criterios de evaluación, de la adecuación de los saberes básicos y de su vinculación con dichos criterios de evaluación, así como el establecimiento de situaciones de aprendizaje que integren estos elementos y contribuyan a la adquisición de las competencias, respetando los principios pedagógicos regulados en el artículo 6 del citado Decreto 102/2023, de 9 de mayo.

3. Las programaciones didácticas contemplarán [[Situaciones de aprendizaje]] en las que se integren los elementos curriculares de las distintas materias para garantizar que la práctica educativa atienda a la diversidad, a las características personales, a las necesidades, a los intereses, a la igualdad efectiva entre hombres y mujeres y al estilo cognitivo del alumnado.

4. Para el desarrollo de las situaciones de aprendizaje se tendrá en consideración lo recogido en el artículo 7 del Decreto 102/2023, de 9 de mayo, así como las orientaciones del Anexo VII.

5. Los centros docentes desarrollarán y concretarán, en su caso, el currículo en su Proyecto educativo y lo adaptarán a las necesidades de su alumnado y a las características específicas del entorno social y cultural en el que se encuentran, configurando así su oferta educativa.

6. Todos los centros que impartan Educación Secundaria Obligatoria deberán incluir en su Proyecto educativo las programaciones didácticas de cada una de las materias.

7. Sin perjuicio de los dispuesto en el artículo 2.4, los departamentos de coordinación didáctica concretarán las líneas de actuación en la Programación didáctica, incluyendo las distintas medidas de atención a la diversidad y a las diferencias individuales que deban llevarse a cabo de acuerdo con las necesidades del alumnado y en el marco establecido en el capítulo V del Decreto 102/2023, de 9 de mayo.

8. El profesorado concretará para cada curso la Programación didáctica, planificando, de esa forma, su actividad educativa.

9. Los centros docentes promoverán compromisos educativos con el alumnado en caso de ser mayor de edad o con los padres, madres o personas que ejerzan su tutela legal, en los que se incluyan actividades que los integrantes de la comunidad educativa se comprometan a desarrollar, para facilitar el desarrollo integral y el progreso académico del alumnado.

10. Los centros docentes organizarán, en el marco de su autonomía, recreos inclusivos y activos con el objetivo de potenciar las interacciones que se establecen entre el alumnado. En éstos, se podrán realizar juegos y actividades lúdicas de su interés, transmisores de la cultura, de los valores y que contribuyan a desarrollar hábitos de vida saludable, tales como talleres de ajedrez, de debate, de juegos tradicionales, de baile, de decoración, de lectura, de mediación, entre otros de naturaleza análoga.

11. A las materias incluidas en el apartado anterior, se añadirá en segundo curso la materia de Educación en Valores Cívicos y Éticos.

12. De acuerdo con lo establecido en el artículo 11 del Decreto 102/2023, de 9 de mayo, el alumnado podrá cursar enseñanzas de Religión en cada uno de los cursos de la etapa a elección del propio alumno o alumna si es mayor de edad o de los padres, madres, o personas que ejerzan su tutela legal. Asimismo, aquel alumnado que no haya optado por cursar dichas enseñanzas recibirá la debida atención educativa. Esta atención se planificará y programará por parte de cada centro.

13. En el caso de que el alumnado presente dificultades en la adquisición de la competencia en comunicación lingüística que le impida seguir con aprovechamiento su proceso de aprendizaje, podrá cursar, en lugar de Segunda Lengua Extranjera, una Materia Lingüística de carácter transversal.

14. En el conjunto de los tres cursos, el alumnado deberá cursar una materia optativa propia de la Comunidad Andaluza, pudiendo elegir entre las siguientes:

- a) En el primer curso: Cultura Clásica, Computación y Robótica, Oratoria y Debate o un Proyecto interdisciplinar, regulado en el artículo 7, que podrá configurarse como un trabajo monográfico o un proyecto de colaboración con un servicio a la comunidad. Cultura Clásica y Computación y Robótica, serán de oferta obligatoria para los centros. Asimismo, se podrán ofertar otras materias autorizadas por la Administración educativa.

- b) En el segundo curso: Cultura Clásica, Computación y Robótica, Proyecto de Educación Plástica y Audiovisual, Segunda Lengua Extranjera, Oratoria y Debate, o un Proyecto interdisciplinar, que podrá configurarse como un trabajo monográfico o un proyecto de colaboración con un servicio a la comunidad. Cultura Clásica, Computación y Robótica, Proyecto de Educación Plástica y Audiovisual y Segunda Lengua Extranjera serán de oferta obligatoria para los centros. Asimismo, se podrán ofertar otras materias autorizadas por la Administración educativa.

- c) En el tercer curso: Cultura Clásica, Computación y Robótica, Segunda Lengua Extranjera, Oratoria y Debate, Filosofía y Argumentación, Cultura del Flamenco, Iniciación a la Actividad Emprendedora y Empresarial o un Proyecto interdisciplinar, que podrá configurarse como un trabajo monográfico o un proyecto de colaboración con un servicio a la comunidad. Cultura Clásica, Computación y Robótica, Cultura del Flamenco y Segunda Lengua Extranjera serán de oferta obligatoria para los centros. Asimismo, se podrán ofertar otras materias autorizadas por la Administración educativa.

1. Las materias referidas en el apartado cinco se impartirán siempre que el número de alumnos y alumnas que las soliciten no sea inferior a quince. No obstante, los centros docentes podrán impartir dichas materias a un número inferior de alumnos y alumnas cuando esta circunstancia no suponga incremento de la plantilla del profesorado del centro.

2. Los centros podrán ofertar la lengua de signos española integrándola dentro de las materias o ámbitos para reforzar la inclusión educativa, en caso de que así lo determinen sus necesidades y quede reflejado en su Proyecto educativo.

3. Se consideran otras materias autorizadas por la Administración los programas de desarrollo curricular de las Aulas Confucio, las materias de integración con las Escuelas Oficiales de Idiomas o las materias propias de las Aulas de Excelencia Artística.

4. De acuerdo con lo establecido en el artículo 10.1 del Decreto 102/2023, de 9 de mayo, las materias que deberá cursar todo el alumnado de cuarto curso serán las siguientes:

- a) Educación Física.

- b) Geografía e Historia.

- c) Lengua Castellana y Literatura.

- d) Primera Lengua Extranjera.

- e) Matemáticas A o Matemáticas B, en función de la elección de cada estudiante.

1. Además, de conformidad con lo dispuesto en el artículo 10.2 del Decreto 102/2023, de 9 de mayo, el alumnado deberá cursar tres materias de entre las siguientes:

- a) Biología y Geología

- b) Digitalización

- c) Economía y Emprendimiento

- d) Expresión Artística

- e) Física y Química

- f) Formación y Orientación Personal y Profesional

- g) Latín

- h) Música

- i) Segunda Lengua Extranjera

- j) Tecnología

1. De acuerdo con lo establecido en el artículo 11 del Decreto 102/2023, de 9 de mayo, el alumnado podrá cursar enseñanzas de Religión en cada uno de los cursos de la etapa a elección del propio alumno o alumna si es mayor de edad o de los padres, madres, o personas que ejerzan su tutela legal. Asimismo, aquel alumnado que no haya optado por cursar dichas enseñanzas recibirá la debida atención educativa. Esta atención se planificará y programará por parte de cada centro.

2. El alumnado cursará una materia optativa propia de la Comunidad Andaluza de entre las siguientes: Artes Escénicas y Danza, Cultura Científica, Ampliación de Cultura Clásica, Dibujo Técnico, Filosofía y Aprendizaje Social y Emocional. Asimismo, los centros docentes en el ejercicio de su autonomía podrán ofertar como optativa propia de la Comunidad un Proyecto interdisciplinar, que podrá configurarse como un trabajo monográfico o un proyecto de colaboración con un servicio a la comunidad. Ampliación de Cultura Clásica y Dibujo Técnico serán de oferta obligatoria para los centros. Asimismo, se podrán ofertar otras materias autorizadas por la Administración educativa.

3. Los centros podrán ofertar la lengua de signos española integrándola dentro de las materias o ámbitos para reforzar la inclusión educativa, en caso de que así lo determinen sus necesidades y quede reflejado en su Proyecto educativo.

4. Se consideran otras materias autorizadas por la Administración, los programas de desarrollo curricular de las Aulas Confucio, las materias de integración con las Escuelas Oficiales de Idiomas, o las materias propias de las Aulas de Excelencia Artística.

5. El cuarto curso tendrá carácter orientador, tanto para los estudios postobligatorios como para la incorporación a la vida laboral. A fin de orientar la elección al alumnado, los centros docentes podrán establecer agrupaciones de las materias mencionadas en el apartado segundo y cuarto en distintas opciones, orientadas hacia las diferentes modalidades de Bachillerato y los diversos campos de la Formación Profesional. En todo caso, el alumnado deberá poder alcanzar, por cualquiera de las opciones que se establezcan, el nivel de adquisición de las competencias establecido para Educación Secundaria Obligatoria en el Perfil de salida del alumnado al término de la Enseñanza Básica.

6. Los centros deberán ofertar la totalidad de las materias citadas en el apartado segundo, así como las especificadas de oferta obligatoria en el apartado cuarto, pudiéndose limitar la elección del alumnado cuando haya un número inferior a quince. No obstante, los centros docentes podrán impartir dichas materias a un número inferior de alumnado cuando esta circunstancia no suponga un incremento de la plantilla del profesorado del centro.

7. Los centros docentes, como materia optativa propia de la Comunidad Andaluza, podrán configurar en su oferta educativa el desarrollo de Proyectos interdisciplinares. Todo ello, para garantizar el desarrollo integrado de todas las competencias de la etapa y la incorporación de los valores enunciados en los principios pedagógicos recogidos en el artículo 6 del Decreto 102/2023, de 9 de mayo, según se determine en el Proyecto educativo de centro.

8. Los Proyectos interdisciplinares tendrán un carácter eminentemente práctico.

9. Los departamentos de coordinación didáctica o el departamento de orientación presentarán los Proyectos interdisciplinares al Claustro para su aprobación por mayoría cualificada de dos tercios. Dicha propuesta deberá contar con el visto bueno previo del Equipo Técnico de Coordinación Pedagógica.

10. Los proyectos interdisciplinares que se presenten al Claustro deberán contener, al menos, los siguientes elementos:

- a) Denominación y justificación del Proyecto, así como el curso para el que se propone ofertar. Asimismo, se detallarán las competencias específicas, los criterios de evaluación, saberes básicos y su vinculación con el Perfil competencial o el Perfil de salida en cada caso.

- b) Justificación de su inclusión en la oferta educativa del centro docente y breve descripción del Proyecto ofertado.

- c) Certificación de la persona que ejerza la secretaría del centro relativa a la fecha de aprobación de la propuesta por parte del Claustro de profesorado.

- d) Profesorado que impartirá el Proyecto y recursos de los que se dispone para ello.

- e) Acreditación de que la incorporación del Proyecto a la oferta educativa es sostenible y asumible con los recursos humanos y materiales de que dispone el centro docente y que, por tanto, no implica aumento de plantilla del mismo.

1. Entre el 1 y el 22 de junio del curso anterior al de la implantación del Proyecto, los centros docentes comunicarán al Servicio de Inspección de la Delegación Territorial con competencias en materia de educación sus Proyectos Interdisciplinares aprobados.

2. Según lo establecido en el artículo 9.9 del Decreto 102/2023, de 9 de mayo, la Materia Lingüística de carácter transversal se impartirá para el alumnado que presente dificultades en la adquisición de la competencia en comunicación lingüística.

3. Se podrá acceder a la Materia Lingüística de carácter transversal al inicio de curso en función de la información del curso anterior o durante el primer trimestre, a propuesta de la persona que ejerza la tutoría tras la correspondiente evaluación inicial.

4. La programación ha de partir de los elementos curriculares de la materia de Lengua Castellana y Literatura, integrando las competencias específicas, así como los criterios de evaluación del mismo curso o de cursos anteriores en función de los resultados de la evaluación inicial del alumnado que conforma el grupo. Los saberes básicos han de permitir el desarrollo de las destrezas comunicativas: escuchar, hablar, conversar, leer y escribir.

5. La metodología desarrollará el enfoque comunicativo de la lengua, partirá de los intereses y la motivación del alumnado, estará orientada al desarrollo de productos finales, interesantes y motivadores para el alumnado, tales como obras de teatro, cómics, campañas publicitarias, materiales y aplicaciones web, exposiciones orales, debates, creación de textos escritos continuos, discontinuos y digitales, desarrollo intencional de la lectura comprensiva, entre otros.

6. La Materia Língüistica de carácter transversal será evaluable y calificable como las restantes materias. Los resultados de la evaluación se expresarán en los términos establecidos en el artículo 13.

7. La incorporación y matriculación del alumnado a la Materia Lingüística de carácter transversal se realizará una vez oído el propio alumno o alumna, y contando con la conformidad de sus padres, madres o personas que ejerzan su tutela legal.

8. El horario lectivo semanal de cada uno de los cursos de Educación Secundaria Obligatoria se organizará en treinta sesiones lectivas con la distribución por materias que se establece en el Anexo I.

9. El horario lectivo de cada uno de los cursos de Educación Secundaria Obligatoria se organizará en sesiones de 60 minutos, respetando siempre el horario mínimo de cada materia determinado en el Anexo I.

10. Los centros docentes configurarán el horario lectivo semanal para las diferentes materias de Educación Secundaria Obligatoria en función de las necesidades de aprendizaje de su alumnado. En esa configuración del horario lectivo, los centros deberán garantizar la incorporación de un tiempo diario, no inferior a 30 minutos, en todos los niveles de la etapa, para el desarrollo planificado de la lectura, en los términos recogidos en su Proyecto educativo.

11. El horario escolar correspondiente a las enseñanzas mínimas de los ámbitos será el resultante de la suma de las materias que se integren en estos, a excepción de los ámbitos del Programa de diversificación curricular, que serán los determinados en el Anexo I.

12. Los centros autorizados con Aulas de Excelencia Artística ajustarán su ordenación curricular a lo dispuesto en el Anexo I.

13. **La evaluación del proceso de aprendizaje del alumnado será continua, competencial, formativa, integradora, diferenciada y objetiva según las distintas materias del currículo** y será un instrumento para la mejora tanto de los procesos de enseñanza como de los procesos de aprendizaje. Tomará como referentes los criterios de evaluación de las diferentes materias curriculares, a través de los cuales se medirá el grado de consecución de las competencias específicas.

14. La evaluación será integradora por tener en consideración la totalidad de los elementos que constituyen el currículo. En la evaluación del proceso de aprendizaje del alumnado deberá tenerse en cuenta el grado de consecución de las competencias específicas a través de la superación de los criterios de evaluación que tienen asociados.

15. El carácter integrador de la evaluación no impedirá al profesorado realizar la evaluación de cada materia de manera diferenciada en función de los criterios de evaluación que, relacionados de manera directa con las competencias específicas, indicarán el grado de desarrollo de las mismas.

16. La evaluación será continua por estar inmersa en el proceso de enseñanza y aprendizaje y por tener en cuenta el progreso del alumnado, con el fin de detectar las dificultades en el momento en que se produzcan, averiguar sus causas y, en consecuencia, de acuerdo con lo dispuesto en el Capítulo V del Decreto 102/2023, de 9 de mayo, adoptar las medidas necesarias dirigidas a garantizar la adquisición de las competencias clave, que le permita continuar adecuadamente su proceso de aprendizaje.

17. El carácter formativo de la evaluación propiciará la mejora constante del proceso de enseñanza y aprendizaje. La evaluación formativa proporcionará la información que permita mejorar tanto los procesos como los resultados de la intervención educativa.

18. El alumnado tiene derecho a ser evaluado conforme a criterios de plena objetividad, a que su dedicación, esfuerzo y rendimiento sean valorados y reconocidos de manera objetiva. Asimismo, el alumnado tiene derecho a conocer los resultados de sus evaluaciones para que la información que se obtenga a través de estas tenga valor formativo y lo comprometa en la mejora de su educación.

19. Para garantizar la objetividad y la transparencia, al comienzo de cada curso, los profesores y profesoras informarán al alumnado acerca de los criterios de evaluación de cada una de las materias, incluidas las materias pendientes de cursos anteriores, así como de los procedimientos y criterios de evaluación y calificación.

20. Asimismo, para la evaluación del alumnado se tendrán en consideración los criterios y procedimientos de evaluación, calificación, promoción y titulación incluidos en el Proyecto educativo del centro.

21. Los Proyectos educativos de los centros docentes establecerán el sistema de participación del alumnado, y de los padres, madres o personas que ejerzan su tutela legal en el desarrollo del proceso de evaluación. Asimismo, los centros docentes establecerán en su Proyecto educativo el procedimiento por el cual, los padres, madres o personas que ejerzan la tutela legal del alumnado, o el propio alumnado si es mayor de edad, podrán solicitar las aclaraciones concernientes al proceso de aprendizaje del mismo a través de la persona que ejerza la tutoría y obtener información sobre los procedimientos de revisión de las calificaciones.

22. Los centros docentes establecerán en sus Proyectos educativos los procesos mediante los cuales se harán públicos los criterios y procedimientos de evaluación, promoción y titulación, que se ajustarán a la normativa vigente, así como los instrumentos que se aplicarán para la evaluación de los aprendizajes de cada materia.

23. El profesorado llevará a cabo la evaluación, preferentemente, a través de la observación continuada de la evolución del proceso de aprendizaje en relación con los criterios de evaluación y el grado de desarrollo de las competencias específicas de cada materia.

24. Los criterios de evaluación han de ser medibles, por lo que se han de establecer mecanismos objetivos de observación de las acciones que describen.

25. Los mecanismos que garanticen la objetividad de la evaluación deberán ser concretados en las programaciones didácticas y ajustados de acuerdo con la evaluación inicial del alumnado y de su contexto.

26. Para la evaluación del alumnado se utilizarán diferentes instrumentos tales como cuestionarios, formularios, presentaciones, exposiciones orales, edición de documentos, pruebas, escalas de observación, [[Rúbricas]] o portfolios, entre otros, coherentes con los criterios de evaluación y con las características específicas del alumnado, garantizando así que la evaluación responde al principio de atención a la diversidad y a las diferencias individuales. Se fomentarán los procesos de coevaluación, evaluación entre iguales, así como la autoevaluación del alumnado, potenciando la capacidad del mismo para juzgar sus logros respecto a una tarea determinada.

27. Los criterios de evaluación contribuyen, en la misma medida, al grado de desarrollo de la Competencia específica, por lo que tendrán el mismo valor a la hora de determinar su grado de desarrollo.

28. Los criterios de promoción y titulación, recogidos en el Proyecto educativo, tendrán que ir referidos al grado de desarrollo de los descriptores operativos del Perfil competencial y del Perfil de salida, en su caso, así como a la superación de las competencias específicas de las diferentes materias.

29. Los docentes evaluarán tanto el proceso de aprendizaje del alumnado como su propia práctica docente, para lo que concretarán los oportunos procedimientos en las programaciones didácticas.

30. La evaluación inicial del alumnado ha de ser competencial y ha de tener como referente las competencias específicas de las materias que servirán de punto de partida para la toma de decisiones. Para ello, se tendrá en cuenta principalmente la observación diaria, así como otras herramientas. La evaluación inicial del alumnado en ningún caso consistirá exclusivamente en una prueba objetiva.

31. Los resultados de esta evaluación no figurarán en los documentos oficiales de evaluación.

32. Durante los primeros días del curso, con el fin de conocer la evolución educativa del alumnado y, en su caso, las medidas educativas adoptadas, la persona que ejerza la tutoría y el equipo docente de cada grupo analizarán los informes del curso anterior, a fin de conocer aspectos relevantes de los procesos educativos previos. Asimismo, el equipo docente realizará una evaluación inicial, para valorar la situación inicial de sus alumnos y alumnas en cuanto al nivel de desarrollo de las competencias específicas de las materias de la etapa que en cada caso corresponda.

33. Antes del 15 de octubre se convocará una sesión de coordinación docente con objeto de analizar y compartir las conclusiones de esta evaluación inicial, que tendrá carácter orientador y será el punto de referencia para la toma de decisiones relativas a la elaboración de las programaciones didácticas y al desarrollo del currículo que se adecuará a las características y al grado de desarrollo de las competencias específicas del alumnado.

34. El equipo docente, con el asesoramiento del departamento de orientación, realizará la propuesta y adoptará las medidas educativas de atención a la diversidad y a las diferencias individuales para el alumnado que las precise.

35. Se entiende por [[Evaluación continua]] aquella que se realiza durante todo el proceso de aprendizaje, permitiendo conocer el progreso del alumnado en el antes, durante y final del proceso educativo, realizando ajustes y cambios en la planificación del proceso de enseñanza y aprendizaje, si se considera necesario.

36. Son sesiones de evaluación continua las reuniones del equipo docente de cada grupo, coordinadas por la persona que ejerza la tutoría y, en ausencia de esta, por la persona que designe la dirección del centro, con la finalidad de intercambiar información sobre el progreso educativo del alumnado y adoptar decisiones de manera consensuada y colegiada, orientadas a la mejora de los procesos de enseñanza y aprendizaje y de la propia práctica docente. Estas sesiones se realizarán al finalizar el primer y el segundo trimestre del curso escolar.

37. La valoración de los resultados derivados de estas decisiones y acuerdos constituirá el punto de partida de la siguiente sesión de evaluación continua o de evaluación ordinaria, según proceda.

38. En las sesiones de evaluación continua se acordará la información que, sobre el proceso personal de aprendizaje seguido, se transmitirá al alumnado y a las familias, de acuerdo con lo recogido en el Proyecto educativo del centro y en la normativa que resulte de aplicación. Esta información deberá indicar las posibles causas que inciden en el proceso de aprendizaje y en el progreso educativo del alumnado, así como, en su caso, las recomendaciones u orientaciones para su mejora.

39. Los resultados de estas sesiones se recogerán en la correspondiente acta y se expresarán en los términos cualitativos: Insuficiente (IN), para las calificaciones negativas, Suficiente (SU), Bien (BI), Notable (NT) o Sobresaliente (SB), para las calificaciones positivas.

40. Asimismo, para orientar a las familias se entregará a los padres, madres o personas que ejerzan la tutela legal del alumnado un boletín de calificaciones que tendrá carácter informativo y contendrá tanto calificaciones cualitativas como cuantitativas, expresadas en los términos Insuficiente (IN): 1, 2, 3 o 4. Suficiente (SU): 5. Bien (BI): 6. Notable (NT): 7 u 8. Sobresaliente (SB): 9 o 10.

41. La persona que ejerza la tutoría de cada grupo levantará acta del desarrollo de las sesiones en la que se harán constar las decisiones y los acuerdos adoptados, así como las medidas de atención a la diversidad y a las diferencias individuales aplicadas.

42. Al término de cada curso de la etapa, se valorará el progreso del alumnado en las diferentes materias por parte del equipo docente en una única sesión de evaluación ordinaria.

43. Son sesiones de evaluación ordinaria las reuniones del equipo docente de cada grupo coordinadas por la persona que ejerza la tutoría y, en ausencia de esta, por la persona que designe la dirección del centro, donde se decidirá sobre la evaluación final del alumnado. En esta sesión se adoptarán decisiones de manera consensuada y colegiada, orientadas a la mejora de los procesos de enseñanza y aprendizaje y de la propia práctica docente. En caso de que no exista consenso, las decisiones se tomarán por mayoría cualificada de dos tercios de los integrantes del equipo docente. Para el desarrollo de estas sesiones, el equipo docente podrá recabar el asesoramiento del departamento de orientación del centro. Esta sesión tendrá lugar una vez finalizado el período lectivo y no será anterior al día 22 de junio.

44. En las sesiones de evaluación ordinaria, el profesor o profesora responsable de cada materia decidirá la calificación de la misma. Esta calificación ha de ser establecida tomando como referencia la superación de las competencias específicas de la materia. Para ello, se tendrán como referentes los criterios de evaluación, a través de los cuales se valorará el grado de consecución de las competencias específicas.

45. Según lo establecido en el artículo 31.3 del Real Decreto 217/2022, de 29 de marzo, en el caso de los ámbitos que integren distintas materias, el resultado de la evaluación se expresará mediante una única calificación, sin perjuicio de los procedimientos que puedan establecerse para mantener informados de su evolución en las diferentes materias al alumnado y a sus padres, madres, o personas que ejerzan su tutela legal.

46. En la sesión de evaluación ordinaria, se acordará la información que, sobre el proceso personal de aprendizaje seguido, se transmitirá al alumnado y a las familias, de acuerdo con lo recogido en el Proyecto educativo del centro y en la normativa que resulte de aplicación. Esta información deberá indicar las posibles causas que inciden en el proceso de aprendizaje y en el progreso educativo del alumnado, así como, en su caso, las recomendaciones u orientaciones para su mejora.

47. Al finalizar el curso escolar, si el alumnado tiene alguna materia no superada, el profesorado responsable de la misma elaborará un informe en el que se detallarán, al menos, las competencias específicas y los criterios de evaluación no superados. Este informe será entregado al padre, madre, o persona que ejerza su tutela legal al finalizar el curso, y además, se depositará en la jefatura de estudios, sirviendo de referente para el programa de refuerzo del aprendizaje del curso posterior o del mismo, en caso de no promoción.

48. Como resultado de las sesiones de evaluación ordinaria se entregará a los padres, madres o personas que ejerzan la tutela legal del alumnado un boletín de calificaciones con carácter informativo en los términos establecidos en el artículo 13.6.

49. La persona que ejerza la tutoría de cada grupo levantará acta del desarrollo de las sesiones en la que se harán constar además de las calificaciones, expresadas en los términos establecidos en el artículo 13.5, las decisiones y los acuerdos adoptados, así como las medidas de atención a la diversidad y a las diferencias individuales aplicadas a cada alumno o alumna.

50. Los resultados de las materias pendientes de cursos anteriores se consignarán, igualmente, en las actas de evaluación, en el expediente y en el historial académico del alumnado.

51. La [[Nota media]] por curso y al final de la etapa se hallará calculando la media aritmética de las calificaciones de todas las materias cursadas redondeada a la centésima más próxima y, en caso de equidistancia, a la superior. Para el cálculo de la nota media normalizada en las convocatorias en las que deban entrar en concurrencia los expedientes académicos, se excluirá la materia de Religión, así como las de atención educativa, tal y como se establece en la disposición adicional primera del Real Decreto 217/2022, de 29 de marzo. Estas notas serán trasladadas a la certificación académica de los estudios cursados y al historial académico, para ser utilizadas en los procedimientos de concurrencia competitiva que procedan.

52. Al finalizar la etapa, a juicio del equipo docente, cuando el alumnado demuestre que ha alcanzado un desarrollo académico excelente, se le otorgará Mención Honorífica por materia. Esta circunstancia deberá quedar reflejada en el historial académico del alumnado. Los centros docentes establecerán en su Proyecto educativo el procedimiento de concesión de la Mención Honorífica.

53. De conformidad con lo establecido en el artículo 17.1 del Decreto 102/2023, de 9 de mayo, en el segundo curso de Educación Secundaria Obligatoria todos los centros realizarán una Evaluación de diagnóstico de las competencias adquiridas por el alumnado. Esta evaluación no tendrá efectos académicos y tendrá carácter informativo, formativo y orientador para los centros, para el profesorado, para el alumnado y sus familias o personas que ejerzan su tutela legal y para el conjunto de la comunidad educativa.

54. El Claustro de profesorado realizará un análisis tanto del proceso llevado a cabo como del nivel competencial del alumnado. Dicho análisis será elevado al Consejo escolar para su conocimiento.

55. El alumnado que una vez finalizado el proceso de evaluación de cuarto curso de Educación Secundaria Obligatoria no haya obtenido el título y haya superado los límites de edad establecidos en el artículo 15.5 del Decreto 102/2023, de 9 de mayo, podrá obtenerlo en los dos cursos siguientes a través de la realización de pruebas o actividades personalizadas extraordinarias de las materias o ámbitos que no haya superado. Los centros docentes establecerán en el Proyecto educativo el procedimiento para el desarrollo de las mismas.

56. Las pruebas estarán basadas en planes de recuperación que elaborarán los correspondientes departamentos de coordinación didáctica. Estos planes contemplarán los elementos curriculares de cada materia, tomando en especial consideración sus criterios de evaluación, así como las actividades y las pruebas objetivas propuestas para la superación de la misma. Se determinará el calendario de actuaciones a tener en cuenta por el alumnado.

57. Las personas interesadas que cumplan los requisitos deberán solicitar en el centro donde han cursado cuarto curso su participación en dicho procedimiento, cumplimentando para ello el modelo que se establezca a tales efectos. La inscripción deberá realizarse durante los diez últimos días naturales del mes de junio de cada año.

58. Los centros informarán de oficio y de manera individualizada a los posibles interesados. Las pruebas, organizadas por los departamentos de coordinación didáctica, en coordinación con la jefatura de estudios, se realizarán en los cinco primeros días de septiembre.

59. Una vez resueltas las solicitudes, las personas admitidas podrán retirar de la secretaría de los centros el plan de recuperación.

60. Toda la información relativa a este procedimiento se expondrá en los tablones de anuncios y páginas Web de los centros respectivos con antelación suficiente.

61. De la sesión de evaluación se levantará la correspondiente acta. A esta sesión acudirá el profesorado responsable de la evaluación de las materias pendientes y la persona titular de la jefatura de estudios.

62. El resultado de las pruebas deberá ser conocido por las personas interesadas durante la primera quincena de septiembre.

63. Las personas que desarrollen las funciones de secretaría de los centros registrarán las calificaciones obtenidas en los documentos oficiales de evaluación que procedan, lo que será visado por la persona que ostente la dirección del centro.

64. La evaluación del alumnado con necesidad específica de apoyo educativo que curse las enseñanzas correspondientes a Educación Secundaria Obligatoria se regirá por el principio de normalización e inclusión, y asegurará su no discriminación, así como la igualdad efectiva en el acceso y la permanencia en el Sistema Educativo, para lo cual se tendrán en cuenta las medidas de atención a la diversidad y a las diferencias individuales contempladas en esta Orden y en el resto de la normativa que resulte de aplicación.

65. En función de lo establecido en el artículo 22 del Decreto 102/2023, de 9 de mayo, se establecerán las medidas más adecuadas, tanto de acceso como de adaptación de las condiciones de realización de las evaluaciones, para que las mismas se apliquen al alumnado con necesidad específica de apoyo educativo conforme a lo recogido en su correspondiente Informe de evaluación psicopedagógica. Entre estas medidas se destaca la adaptación del formato de las pruebas de evaluación y la ampliación del tiempo para la ejecución de las mismas o la utilización de diferentes procedimientos de evaluación que tengan en cuenta la variedad de formas de registrar las competencias adquiridas. Estas adaptaciones en ningún caso se tendrán en cuenta para minorar las calificaciones obtenidas.

66. La decisión sobre la evaluación, la promoción y la titulación del alumnado con necesidad específica de apoyo educativo será competencia del equipo docente, asesorado por el departamento de orientación y teniendo en cuenta la tutoría compartida, en su caso, a la que se refiere la normativa reguladora de la organización y el funcionamiento de los centros docentes. Asimismo, se atenderá a lo recogido en el artículo 14.2.

67. La evaluación del alumnado con adaptaciones curriculares significativas en alguna materia se realizará tomando como referente los elementos curriculares establecidos en dichas adaptaciones definidas en el artículo 50. En estos casos, en los documentos oficiales de evaluación, se especificará que la calificación en las materias adaptadas hace referencia a los criterios de evaluación recogidos en dicha adaptación y no a los específicos del curso en el que esté escolarizado el alumnado.

68. En la evaluación del alumnado que se incorpore tardíamente al Sistema Educativo y que, por presentar graves carencias en la comunicación lingüística en lengua española, reciba una atención específica en este ámbito, se tendrá en cuenta los informes que, a tales efectos, elabore el profesorado responsable de dicha atención.

69. El alumnado escolarizado en el curso inmediatamente inferior al que le correspondería por edad, al que se refiere el artículo 21.4 del Decreto 102/2023, de 9 de mayo, se podrá incorporar al grupo correspondiente a su edad cuando a juicio de la persona que ejerza la tutoría, con el acuerdo del equipo docente y asesorado por el departamento de orientación, haya superado el desfase curricular que presentaba. En caso de desacuerdo del equipo docente, la decisión se tomará por mayoría simple de votos.

70. Según lo establecido en el artículo 14 del Decreto 102/2023, de 9 de mayo, promocionarán quienes hayan superado todas las materias cursadas o tengan evaluación negativa en una o dos materias, o cuando el equipo docente considere que las materias que, en su caso, pudieran no haber superado, no les impidan seguir con éxito el curso siguiente, se estime que tienen expectativas favorables de recuperación y que dicha promoción beneficiará su evolución académica.

71. Para orientar la toma de decisiones de los equipos docentes con relación al grado de adquisición de las competencias y la promoción, en el caso de que el alumnado tenga tres o más materias suspensas, se tendrán en consideración los siguientes criterios de manera conjunta:

72. Las decisiones sobre la promoción del alumnado de un curso a otro dentro de la etapa serán adoptadas de forma colegiada por el equipo docente, con el asesoramiento, en su caso, del departamento de orientación. En caso de que no exista consenso, las decisiones se tomarán por mayoría cualificada de dos tercios de los integrantes del equipo docente.

73. Quienes promocionen sin haber superado todas las materias seguirán un programa de refuerzo del aprendizaje que se podrá elaborar de manera individual para cada una de las materias no superadas, o se podrá integrar en un único programa, si el equipo docente lo considera necesario y así se recoge en el Proyecto educativo del centro. El equipo docente revisará periódicamente la aplicación personalizada de las medidas propuestas en los mismos, al menos, al finalizar cada trimestre escolar y en todo caso, al finalizar el curso. En caso de que se determine un único programa de refuerzo del aprendizaje para varias materias, estas han de ser detalladas en el mismo.

74. Estos programas deberán contener los elementos curriculares necesarios para que puedan ser evaluables. La superación o no de los programas será tenida en cuenta a los efectos de promoción y titulación.

75. Será responsable del seguimiento y evaluación de este programa el profesorado de la materia que le dé continuidad en el curso siguiente. Si no la hubiese, será responsabilidad de la persona titular del departamento o persona en quien delegue, preferentemente, un miembro del equipo docente que pertenezca al departamento de coordinación didáctica propio de la materia. En caso de que se decida que el alumnado tenga un único programa de refuerzo del aprendizaje, su seguimiento será responsabilidad de la persona que ejerza la tutoría o de un miembro del departamento de orientación cuando el alumnado se encuentre en un programa de diversificación curricular, de acuerdo con lo que se disponga en el Proyecto educativo del centro.

76. El alumnado con materias pendientes del curso anterior deberá matricularse de dichas materias, realizar los programas de refuerzo del aprendizaje a las que se refiere el apartado 4 y superar la evaluación correspondiente. Una vez superada dicha evaluación, los resultados obtenidos se extenderán en la correspondiente acta de evaluación, en el expediente y en el historial académico del alumno o alumna.

77. De acuerdo con lo previsto en el artículo 14.5 del Decreto 102/2023, de 9 de mayo, la permanencia en el mismo curso se considerará una medida de carácter excepcional y se tomará tras haber agotado las medidas ordinarias de refuerzo para solventar las dificultades de aprendizaje del alumnado. En todo caso, el alumnado podrá permanecer en el mismo curso una sola vez y dos veces como máximo a lo largo de la enseñanza obligatoria.

78. De conformidad con lo previsto en el artículo 14.7 del citado Decreto, de forma excepcional se podrá permanecer un año más en el cuarto curso, aunque se haya agotado el máximo de permanencia en la Educación Básica, siempre que el equipo docente considere que esta medida favorece la adquisición de las competencias clave establecidas para la etapa. En este caso se podrá prolongar un año el límite de edad al que se refiere el artículo 2.2 del Decreto 102/2023, de 9 de mayo.

79. De acuerdo con lo recogido en el artículo 20.4 del Real Decreto 217/2022, de 29 de marzo, el equipo docente, asesorado por el departamento de orientación, oídos el padre, la madre o personas que ejerzan la tutela legal del alumnado, podrá adoptar la decisión de que la escolarización del alumnado con necesidades educativas especiales pueda prolongarse un año más, siempre que ello favorezca el desarrollo de las competencias establecidas y la consecución de los Objetivos de la etapa.

80. Tal y como establece el artículo 21.6 del Decreto 102/2023, de 9 de mayo, la escolarización del alumnado con altas capacidades intelectuales se flexibilizará de conformidad con la normativa vigente, de forma que pueda anticiparse un curso académico el inicio de la escolarización de la etapa o reducirse la duración de la misma, cuando se prevea que dicha medida es la más adecuada para su desarrollo personal y social.

81. De conformidad con lo establecido en el artículo 15.1 del Decreto 102/2023, de 9 de mayo, obtendrá el título de Graduado en Educación Secundaria Obligatoria el alumnado que al terminar la etapa de Educación Secundaria Obligatoria haya adquirido, a juicio del equipo docente, las competencias clave establecidas en el [[Perfil de salida]] y alcanzado los Objetivos de la etapa.

82. Las decisiones sobre la obtención del título serán adoptadas de forma colegiada por el equipo docente, con el asesoramiento, en su caso, del departamento de orientación. En caso de que no exista consenso, las decisiones se tomarán por mayoría cualificada de dos tercios de los integrantes del equipo docente. Para orientar la toma de decisiones de los equipos docentes con relación al grado de adquisición de las competencias clave establecidas en el Perfil de salida y al logro de los Objetivos de la etapa, se tendrán en consideración los siguientes criterios de manera conjunta:

83. El título de Graduado en Educación Secundaria Obligatoria será único y se expedirá sin calificación.

84. Quienes, una vez finalizado el proceso de evaluación de cuarto curso de Educación Secundaria Obligatoria no hayan obtenido el título y hayan superado los límites de edad establecidos en el artículo 2.2 del Decreto 102/2023, de 9 de mayo, teniendo en cuenta, asimismo, la prolongación excepcional de la permanencia en la etapa que se prevé en los artículos 14.7 del citado Decreto y 18.10 de la presente Orden, podrán hacerlo en los dos cursos siguientes, tal y como se dispone en el artículo 16 sobre las pruebas o actividades personalizadas extraordinarias.

85. Todo el alumnado recibirá al concluir su escolarización en la etapa de Educación Secundaria Obligatoria una certificación académica en la que constará el número de años cursados y el nivel de adquisición de las competencias clave definidas en el Perfil de salida, tal y como se indica en el artículo 15.4 del Decreto 102/2023, de 9 de mayo.

86. Dichas certificaciones serán emitidas por el centro docente en el que el alumnado estuviera matriculado en el último curso escolar y se ajustará al modelo que se incluye como Anexo X.

87. Los documentos oficiales de evaluación son: las actas de evaluación, el expediente académico, el historial académico y, en su caso, el informe personal por traslado, de conformidad con lo recogido en el artículo 18 del Decreto 102/2023, de 9 de mayo.

88. El historial académico y, en su caso, el informe personal por traslado se consideran documentos básicos para garantizar la movilidad del alumnado por todo el territorio nacional.

89. En los documentos oficiales de evaluación y en lo referente a la obtención, tratamiento, seguridad y confidencialidad de los datos personales del alumnado y a la cesión de los mismos de unos centros docentes a otros se estará a lo dispuesto en la legislación vigente en materia de protección de datos de carácter personal y, en todo caso, a lo establecido en la disposición adicional vigesimotercera de la Ley Orgánica 2/2006, de 3 de mayo, de Educación.

90. La custodia y archivo de los documentos oficiales de evaluación corresponde a la secretaría del centro docente. Los documentos oficiales de evaluación serán visados por la persona que ejerza la dirección del centro y en ellos se consignarán las firmas de las personas que correspondan en cada caso, junto a las que constará el nombre y los apellidos de la persona firmante, así como el cargo o atribución docente, todo ello teniendo en cuenta lo dispuesto sobre gestión documental en el Decreto 622/2019, de 27 de diciembre, de administración electrónica, simplificación de procedimientos y racionalización organizativa de la Junta de Andalucía. Estos documentos oficiales serán supervisados por la Inspección educativa.

91. Las actas de evaluación, reguladas en el artículo 31 del Real Decreto 217/2022, de 29 de marzo, se ajustarán a los modelos que se incluyen como Anexo IX.a, se extenderán para cada uno de los cursos y se cerrarán tras la finalización del período lectivo ordinario.

92. Las actas de evaluación comprenderán la relación nominal del alumnado que compone cada grupo junto con los resultados de la evaluación de las materias o ámbitos del curso y las decisiones adoptadas sobre promoción, permanencia y titulación.

93. Los resultados de la evaluación de cada materia se expresarán como Insuficiente (IN) para las calificaciones negativas, Suficiente (SU), Bien (BI), Notable (NT) o Sobresaliente (SB), para las calificaciones positivas, tal y como se recoge en el artículo  31 del Real Decreto 217/2022, de 29 de marzo.

94. En el caso de los ámbitos que integren distintas materias el resultado de la evaluación se expresará mediante una única calificación, sin perjuicio de los procedimientos que puedan establecerse para mantener informados de su evolución en las diferentes materias al alumnado y a sus padres, madres o personas que ejerzan su tutela legal.

95. Cuando el alumnado recupere una materia no superada de los cursos anteriores, la calificación obtenida se hará constar en el acta de evaluación del curso en que supere dicha materia.

96. Las actas de evaluación serán firmadas por todo el profesorado del grupo, llevarán el visto bueno de la persona que ostente la dirección y serán archivadas y custodiadas en la secretaría del centro.

97. El expediente académico, regulado en el artículo 32 del Real Decreto 217/2022, de 29 de marzo, se ajustará al modelo que se incluye como Anexo IX.b y es el documento oficial que refleja la información relativa al proceso de evaluación, promoción y titulación.

98. El expediente académico incluirá los datos de identificación del centro docente y del alumnado, los resultados de la evaluación de las materias, las decisiones adoptadas sobre promoción y titulación, las medidas de atención a la diversidad y a las diferencias individuales que se hayan aplicado y las fechas en que se hayan producido los diferentes hitos. Constará, en su caso, la fecha de entrega de la certificación de haber concluido la escolarización obligatoria.

99. En el caso de que existan materias que hayan sido cursadas de forma integrada en un ámbito, en el expediente figurará, junto con la denominación de dicho ámbito, la indicación expresa de las materias integradas en el mismo.

100. El historial académico del alumnado, regulado en el artículo 33 del Real Decreto 217/2022, de 29 de marzo, se ajustará al modelo que se incluye como Anexo IX.c, y tendrá valor acreditativo de los estudios realizados. Como mínimo recogerá los datos identificativos del alumnado, materias cursadas en cada uno de los años de escolarización, las medidas de atención a la diversidad y a las diferencias individuales aplicadas, los resultados de la evaluación, las decisiones sobre promoción, permanencia y titulación, la información relativa a los cambios de centro y las fechas en que se han producido los diferentes hitos.

101. Con objeto de garantizar la movilidad del alumnado, cuando varias materias hayan sido cursadas integradas en un ámbito, se hará constar, en el historial, la calificación obtenida en cada una de ellas. Esta calificación será la misma que figure en el expediente para el ámbito correspondiente.

102. Al finalizar la etapa, y en cualquier caso al finalizar su escolarización en la enseñanza en régimen ordinario, el historial académico de Educación Secundaria Obligatoria se entregará al alumnado o, en caso de que fuese menor de edad, a sus padres, madres, o personas que ejerzan su tutela legal. Esta circunstancia se hará constar en el expediente académico.

103. El informe personal por traslado, regulado en el artículo 34 del Real Decreto 217/2022, de 29 de marzo, se ajustará al modelo que se incluye como Anexo IX.d y es el documento oficial que recogerá la información que resulte necesaria para garantizar la continuidad del proceso de aprendizaje del alumnado cuando se traslade a otro centro docente sin haber finalizado la etapa.

104. Será cumplimentado por la persona que ejerza la tutoría del alumnado en el centro de origen a partir de la información facilitada por el equipo docente.

105. En el caso de que el alumnado se traslade a otro centro antes de finalizar la etapa, el centro de origen deberá remitir al de destino y a petición de este el informe personal por traslado, junto a una copia del historial académico. Una vez recibidos debidamente cumplimentados dichos documentos, la matriculación en el centro docente de destino adquirirá carácter definitivo y se procederá a abrir el correspondiente expediente académico.

106. El Informe personal por traslado contendrá los resultados de las evaluaciones que se hubieran realizado, la aplicación, en su caso, de medidas de atención a la diversidad y a las diferencias individuales y todas aquellas observaciones que se consideren oportunas acerca del progreso general del alumno o alumna.

107. Al finalizar cada curso se entregará a los padres, madres o personas que ejerzan la tutela legal del alumnado, un consejo orientador. Dicho consejo incluirá un informe sobre el grado de adquisición de las competencias correspondientes, así como una propuesta de la opción más adecuada para continuar la formación del alumnado, que podrá incluir la propuesta de incorporación a un Programa de Diversificación Curricular o a un Ciclo Formativo de Grado Básico, en los cursos que proceda, así como las medidas de atención a la diversidad o a las diferencias individuales recomendadas para el curso siguiente, conforme al modelo establecido en el Anexo IX.e.

108. Cuando el equipo docente estime conveniente proponer a padres, madres, o personas que ejerzan la tutela legal y al propio alumno o alumna su incorporación a un Ciclo Formativo de Grado Básico al finalizar el tercer curso, o excepcionalmente segundo curso, dicha propuesta se formulará a través de un nuevo consejo orientador que se emitirá con esta única finalidad.

109. La propuesta de incorporación al Programa de Diversificación Curricular ha de ser motivada en el correspondiente informe de idoneidad citado en el artículo 24.7 del Real Decreto 217/2022, de 29 de marzo, que será incorporado al consejo orientador.

110. Asimismo, al finalizar la etapa o, en su caso, al concluir la escolarización obligatoria, el alumnado recibirá un consejo orientador que incluirá una propuesta sobre la opción u opciones académicas, formativas o profesionales, que se consideran más convenientes. Este consejo orientador tendrá por objeto que todo el alumnado encuentre una opción adecuada para su futuro formativo, de manera que pueda garantizarse el desarrollo de su aprendizaje permanente.

111. El consejo orientador será redactado por la persona que ostente la tutoría del grupo con el asesoramiento del departamento de orientación.

112. La evaluación del proceso de aprendizaje del alumnado de Educación Secundaria Obligatoria será ^^continua, formativa e integradora.^^ Con carácter general, la evaluación del proceso de aprendizaje del alumnado que se llevará a cabo en cada uno de los cursos de la etapa será continua, a través de la observación y el seguimiento sistemáticos, para valorar, desde su particular situación inicial y atendiendo a la diversidad de capacidades, aptitudes, ritmos y habilidades de aprendizaje, su evolución, así como la adopción en cualquier momento del
curso de las medidas de refuerzo pertinentes; tendrá un carácter formativo, regulador y orientador del proceso educativo al proporcionar información al profesorado, al alumnado y a las familias, y será un instrumento para la mejora tanto de los procesos de enseñanza como de los procesos de aprendizaje.

# Documentación Qe

- [ANÁLISIS LOMLOE Qe - Documentos de Google](https://docs.google.com/document/d/1LhdGRpOqY85u0QPcb9k6x3Ah7wSqdzPSfP0DjKLUWbo/edit#heading=h.2gazcsgmxkub)

- [MATERIAS LOMLOE - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1ZhQ5kWIDIYvppiaEHfH0DIAVZIzIUcX2OLWRIphWsuU/edit#gid=711936293)

- [ID_ASIGGRAL - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1OuH7uK_2vgT_WvuEgrC5WZC07mmOdUlB1Wi_Wvokyos/edit#gid=0)

- [ID Entidades Finalistas asignación id - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1P3VhxXvWeNgArdzjoYHQo6XHhK5caCzxMu3ZTYCeY1M/edit#gid=0)

- [Listado cursos unificados - NUEVO - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/10fq4GqF-BOB0wyiWj3ZlpGfWsCY9LlCGT1AN2cMHqrU/edit#gid=0)

- [Marco curricular LOMLOE - INFANTIL - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1tuSTzx6_VX9hS8urDvbA_bXB7RwKaQhLKJy9UG3h3r4/edit#gid=0)

- [Marco curricular LOMLOE - PRIMARIA - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1YbBSQI_Pv_kZTiqFrzeLolHBQIXcpTNseHm3JPppLiE/edit#gid=395042692)

- [Marco curricular LOMLOE - ESO - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1sUounut2RtQZ2RuVn_2Cbm8kLvXQQJNTl8XjqaJHew8/edit#gid=0)

- [Marco curricular LOMLOE - BACHILLERATO - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1Xt4GxcZEa7bnq-Zux9DUPmwWAmJmdtrXBpyn_DCj2Ks/edit#gid=1689246208)

- [PASARELA - Qe - Programadores - Google Drive](https://drive.google.com/drive/u/1/folders/1AYb4klPuqTAF-FzaCqQfwSmXDZY1Y4uv)

- [HOJA DE CONTROL - PASARELA - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1x99gVBbyVWHtGkdpiF-TCtimZNghMJh3f2rPepb5JeY/edit?pli=1#gid=140175395)

- [CICLOS 1º CFGB 2022](https://docs.google.com/spreadsheets/d/12nrCu7hhx1-Lcj2oR9Mo1X4SAnrtIx1M/edit#gid=940566477)

- [CICLOS 2º CFGB 2023](https://docs.google.com/spreadsheets/d/1wNoYj-35HiCXbVqKi7CsNynAKYhdOlRBW_7NAcDgf9s/edit#gid=0)

- [LOMLOE relación de asignaturas pendientes pasarela 2023-2024 - Hojas de cálculo de Google](https://docs.google.com/spreadsheets/d/1zHN38ixFX3fNo3rPlGfC_eS1SJZDOlLS2mcG_Xuqvuk/edit#gid=1543042293)

- [OPTATIVAS LOMLOE ZS 23_24](https://docs.google.com/document/d/1Dd8F3Tmtkr9aLifrWKOe_gZo3Y0Xu43rsQquZVhpUwA/edit)

- [OPTATIVAS LOMLOE ZC 23_24](https://docs.google.com/document/d/1WGqKBO3Ayezps7ckblnOPyM_iPdlDsiVc3JXJL4DwUQ/edit)

- [Control pasarela LOMLOE 2023](https://docs.google.com/spreadsheets/d/1FhQerY8Sh9AiaKenJuoQsLW4vjsfNY5qEai6TA4Pwb4/edit#gid=0)

- [Asignaturas faltan programación - 2023/09/11](https://docs.google.com/spreadsheets/d/1i5YCGpHL8-_6yZjrQbrjQfH34mcaRf0tB6u4OpE8hks/edit#gid=0)

- [Notas - Grado de adquisición de competencias LOMLOE - Documentos de Google](https://docs.google.com/document/d/1d7TwCXc7jttMeSwGLblA_Ihwq0G2XMvKIJ56A1if0zE/edit)

