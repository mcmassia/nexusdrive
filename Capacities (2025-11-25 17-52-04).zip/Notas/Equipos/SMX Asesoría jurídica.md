---
type: Equipo
title: SMX Asesoría jurídica
tags: []
personas: [Isa Constantino]
asociado: null
---


