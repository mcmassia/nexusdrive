---
type: Equipo
title: Equipo Técnico Qe
tags: [Qe, SMX]
personas: [Alberto Massia Gómez, Antonio Javier García Parra, Enrique Pradas Moreno]
asociado: null
---


