---
type: Equipo
title: Directores SMX SUR
tags: []
personas: [Sebastián Bajo Castro]
asociado: null
---


