---
type: Equipo
title: Equipo Pilotos
tags: [Qe, SMX]
personas: [Alberto Massia Gómez, Antonio Javier García Parra, Antonio LLorente, Mayca Crespo Graciano, Jorge Cubas Moreno, Rafael Plasencia, Mª Mar Romanos, José Antonio Jordá, José Antón Pérez, Fran Sepulcre, Sergio Almagro, Jesús Jorge Sánchez]
asociado: null
---


