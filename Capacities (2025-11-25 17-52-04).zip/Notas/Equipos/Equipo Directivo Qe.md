---
type: Equipo
title: Equipo Directivo Qe
tags: [SMX]
personas: [Alberto Massia Gómez, Luismi Notario, Antonio Javier García Parra, Enrique Pradas Moreno]
asociado: null
---


