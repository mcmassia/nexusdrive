---
type: Equipo
title: Coordinadores Qe SMX Sur
tags: []
personas: [Antonio LLorente, Juan Guillermo Cera López, Montse Rodríguez Martínez, "Amelia\_García Jiménez."]
asociado: null
---


