---
type: Reunion
title: Reunión Pedagógica / FP Stos. Mártires
description: null
tags: [Activo]
personasInvolucradas: '[Cristóbal Domínguez Castro](Personas/Crist%C3%B3bal%20Dom%C3%ADnguez%20Castro.md) [Laura Seoane Rodríguez](Personas/Laura%20Seoane%20Rodr%C3%ADguez.md)'
tipo: Reunión con cliente
fecha: 2025-11-20 10:00 - 11:00
enlace: '[https://meet.google.com/usv-ftjr-gnh](https://meet.google.com/usv-ftjr-gnh)'
documentos: null
organizacion: [Santos Mártires]
---

# Elementos discutidos

- Toma contacto Laura Seoane como coord. pedagógica de la Fundación.

- Situación currículos módulos optativos CFGM y CFGS.

    - Participan algunos jefes de estudio de Centros con Ciclos:

        - Trinidad Sansueña, Marcial

        - San Rafael, Mª ?

        - ?, Pilar

    - Algunos de sus Centros han dado de alta manualmente las programaciones de módulos optativos GM/GS

    - Resuelvo directamente problemas de importación de Proyectos.

    - [ ] [Cristóbal Domínguez Castro](Personas/Crist%C3%B3bal%20Dom%C3%ADnguez%20Castro.md) recopila los módulos optativos, con sus RA y criterios, por Centro y me los remite. 

    - [ ] Analizamos los currículos y los metemos como programaciones en SC

    - [ ] Informo a Cristóbal




# Dudas planteadas


# Otras cuestiones

