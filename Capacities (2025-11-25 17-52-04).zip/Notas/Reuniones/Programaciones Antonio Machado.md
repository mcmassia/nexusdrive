---
type: Reunion
title: Programaciones Antonio Machado
description: null
tags: [AntonioMachado, Aragón]
personasInvolucradas: '[Antonio Machado](Organizaciones/Antonio%20Machado.md)  [Alejandro Peralta Español](Personas/Alejandro%20Peralta%20Espa%C3%B1ol.md)'
tipo: Reunión con cliente
fecha: 2025-10-02 10:45 - 11:30
enlace: '[https://meet.google.com/cfe-ptwy-edk?hs=224](https://meet.google.com/cfe-ptwy-edk?hs=224)'
documentos: null
organizacion: []
---

# Elementos discutidos

- Plantean problemas conceptuales debido a mentalidad instrumental (ponderación por instrumentos) de calificación.

- Para meterlos en el sistema competencial de evaluación por referentes, les planteo varias posibilidades para ir caminando:

    - Marcar como referentes las CE y editar el texto, de manera que vean claramente a qué tipología de instrumentos se asocian.

    - Si hay compañeros con problemas al respecto, crear una nueva CE ficticia a modo de comodín.

    - Crear actividades asociando las CE correspondientes.

    - No usar CATEGORÍAS/SUBCATEGORÍAS

- Nos planteamos una vídeo futura para resolver dudas y ver las sesiones formativas presenciales:

    - Programaciones con el claustro.

    - Orientación.

# Dudas planteadas


# Otras cuestiones

Me comenta [Mª Luisa Miñambres](Personas/M%C2%AA%20Luisa%20Mi%C3%B1ambres.md):

Lo que busca principalmente es poder crear una programación vacía, para no tener que relacionar las actividades con referentes. Y dentro de las preocupaciones que tiene es la forma de ponderar correctamente las evaluaciones y el poder saber a la hora de crear y evaluar actividades, cómo se muestra en las actas de evaluación. (Esto más o menos se lo he explicado).

Es un chico listo. No le cuesta entender las cosas. Pero es verdad que es un centro que no ha utilizado nunca la ley de cara a evaluar, si no que se ha hecho a la "antigua" y tiene muchos profesores de la vieja escuela, con lo que busca una forma fácil para arrancar, que no les suponga mucho esfuerzo a esos profesores. Por lo demás, el entiende que hay que hacer las cosas bien y que no parece difícil como se muestra en el programa.

Está haciendo videos de cómo se crean actividades y demás para los demás profes del cole.

