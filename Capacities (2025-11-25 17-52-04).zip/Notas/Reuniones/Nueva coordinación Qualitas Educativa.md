---
type: Reunion
title: Nueva coordinación Qualitas Educativa
description: null
tags: []
personasInvolucradas: null
tipo: Formación
fecha: 2025-11-19 16:30 - 18:30
enlace: null
documentos: null
organizacion: [Salesianos Jerez Lora]
---

# Elementos discutidos

- Objetivos: Conocer y comprender los procedimientos básicos de gestión de la plataforma educativa Qualitas Educativa.

- Contenidos:

- Metodología:

- Evaluación:

# Dudas planteadas


# Otras cuestiones

