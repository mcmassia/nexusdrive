---
type: Reunion
title: Calificaciones FP- Qe Aragón
description: null
tags: [SMX, FormaciónProfesional]
personasInvolucradas: '[Antonio Javier García Parra](Personas/Antonio%20Javier%20Garc%C3%ADa%20Parra.md) [Eduardo Marco Ruiz](Personas/Eduardo%20Marco%20Ruiz.md)'
tipo: Reunión análisis/dudas
fecha: 2025-10-02 12:00 - 13:30
enlace: '[https://meet.google.com/srn-kybz-jfg](https://meet.google.com/srn-kybz-jfg)'
documentos: null
organizacion: []
---

# Elementos discutidos

- Problema para dejar de pensar en ponderar los elementos de calificación.

- Eduardo plantea varios métodos para tratar de permitir la ponderación de manera controlada.

    - Ponderación de criterios en Diseño curricular en base a una ponderación superior (no posible directamente en Qe) de los RA.

    - Vemos que el sistema calcula correctamente y obtiene los mismos resultados que si se ponderasen en Qe los dos niveles: RA y Crit.

# Dudas planteadas


# Otras cuestiones

- Correo de Eduardo inicial

    Buenos días Alberto y Javier. 

    Como os comenté tenía (tengo) una excel con un par de ejemplos de cómo "parece" que debería ser la forma de calificar con la nueva ley de FP. 

    Ahora he hecho una prueba en Qe y casi, casi me cuadra al 100 %. Creo que se me escapa algún detalle o me he equivocado en algún cálculo en la excel, pero casi está. 

    Me gustaría que nos viésemos y así os puedo comentar.

