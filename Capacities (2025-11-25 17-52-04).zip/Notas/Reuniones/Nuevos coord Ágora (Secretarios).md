---
type: Reunion
title: Nuevos coord. Ágora (Secretarios)
description: null
tags: [Maristas]
personasInvolucradas: '[Juan García Gallego](Personas/Juan%20Garc%C3%ADa%20Gallego.md)'
tipo: Formación
fecha: 2025-10-15 12:00 - 14:00
enlace: '[https://teams.microsoft.com/meet/3238773474825?p=OZ7NcICNuvZAEhTs9o](https://teams.microsoft.com/meet/3238773474825?p=OZ7NcICNuvZAEhTs9o)'
documentos: '[https://docs.google.com/document/d/14rXZEsokSfDwnOaysq80DRRwkRbM4UUM0Q4kMSXDPvQ/edit?usp=sharing](https://docs.google.com/document/d/14rXZEsokSfDwnOaysq80DRRwkRbM4UUM0Q4kMSXDPvQ/edit?usp=sharing)'
organizacion: []
---

# Elementos discutidos

- Permisos

- Estructura de Centro

- Gestión horarios

- Matriculación

- Escuela familia

# Dudas planteadas


# Otras cuestiones

- [x] Dar acceso a los secretarios a la unidad y doc correspondientes

Les envío el siguiente mensaje:

Muy buenas, esperando que os encontréis bien, os recuerdo que ayer deberíais haber recibido un mensaje de invitación a nuestra unidad compartida donde acceder a la documentación de ayuda y soporte del sistema.

El acceso directo a la misma es [este enlace](https://drive.google.com/drive/folders/0AAJeQLYiASxDUk9PVA).

También os recuerdo [el documento](https://docs.google.com/document/d/14rXZEsokSfDwnOaysq80DRRwkRbM4UUM0Q4kMSXDPvQ/edit?usp=drive_link) que sirvió ayer de soporte para la sesión formativa; lo podéis encontrar en la carpeta FORMACIÓN de la unidad compartida.

Como tarea, os pido que podáis rellenar los datos de cada uno de vosotros como coordinadores de vuestro Centro en [este documento](https://docs.google.com/spreadsheets/d/1Tb3eWpVpFHvEETd-OrVjTUehZdv2x9VVM5aWaJyHUY4/edit?usp=sharing), también presente en la unidad.

Muchas gracias y seguimos avanzando.

Un abrazo.

