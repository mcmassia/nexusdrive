---
type: Reunion
title: Implantación Registro Jornada Santos Mártires
description: Organización y coordinación de la implantación del Registro de Jornada en los centros Santos Mártires, abarcando altas, activaciones, asignaciones y gestión de horarios y actividades del personal.
tags: [FDSM, Activo]
personasInvolucradas: '[Cristóbal Domínguez Castro](Personas/Crist%C3%B3bal%20Dom%C3%ADnguez%20Castro.md) [Enrique Pradas Moreno](Personas/Enrique%20Pradas%20Moreno.md) [Alberto Massia Gómez](Personas/Alberto%20Massia%20G%C3%B3mez.md) [Rafael Onieva Barea](Personas/Rafael%20Onieva%20Barea.md) [José Mª Olmo Gañán](Personas/Jos%C3%A9%20M%C2%AA%20Olmo%20Ga%C3%B1%C3%A1n.md) [Alfredo Molero](Personas/Alfredo%20Molero.md)'
tipo: Reunión con cliente
fecha: 2025-10-03 10:00 - 12:00
enlace: '[https://meet.google.com/afo-zohg-nys?hs=224](https://meet.google.com/afo-zohg-nys?hs=224)'
documentos: null
organizacion: []
---

# Elementos discutidos

- Dinámica de activación.

- Elementos de reflexión y consejos de configuración

- 

# Dudas planteadas

- Hay que dar de alta los centros.

    - nombre centro - cif, trabajadores y cuentas cotización.

    - kike pasa estructura de datos básicos para poder importar a qe.

    - SC corresponde a la Sede de la Fundación

    - Analizar cómo computan los trabajadores en varios Centros.

        - Computa cada persona únicamente?

        - Computa cada registro en cada Centro?

- Activación módulo; ya activado 3 de octubre de 2025 a los Centros existentes.

- Marcar los trabajadores  que registran jornada centro a centro

- Asignación perfil Responsable jornada a directores ya asignado 3 de octubre de 2025.

- Garantizar horarios completos de cada trabajador.

- Gestionar:

    - Actividades jornada.

    - Eventos jornada.

    - Adaptaciones jornada.

    - Sustituciones

- Registro jornada app/web:

    - Personal docente - app Qe.

    - PAS - app Qe o app GestorLab

- 

# Otras cuestiones

- [ ] Buscar fecha formación inicial

