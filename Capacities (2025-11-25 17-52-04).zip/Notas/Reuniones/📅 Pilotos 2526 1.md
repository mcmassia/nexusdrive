---
type: Reunion
title: 📅 Pilotos 25/26 1
description: null
tags: []
personasInvolucradas: '[Equipo Pilotos](Equipos/Equipo%20Pilotos.md)'
tipo: Reunión de equipo
fecha: 2025-09-10 10:00 - 12:30
enlace: '[https://meet.google.com/cpi-ucvr-uan?hs=224](https://meet.google.com/cpi-ucvr-uan?hs=224)'
documentos: '[https://docs.google.com/document/d/14urbaUKUaPKOP5is1qyff7FeteHQ-Mu_hlOLXBBj-ik/edit?usp=sharing](https://docs.google.com/document/d/14urbaUKUaPKOP5is1qyff7FeteHQ-Mu_hlOLXBBj-ik/edit?usp=sharing)'
organizacion: []
---

# Elementos discutidos

- [Publicación Documentos EF](Proyectos/Publicaci%C3%B3n%20Documentos%20EF.md)

- Dudas [Etiquetas Qe](Proyectos/Etiquetas%20Qe.md)

# Dudas planteadas


# Otras cuestiones

