---
type: Reunion
title: Escalas y consolidación 29/10/2025
description: null
tags: []
personasInvolucradas: '[Jorge Cubas Moreno](Personas/Jorge%20Cubas%20Moreno.md)'
tipo: Reunión con cliente
fecha: 2025-10-29 11:00 - 12:00
enlace: '[https://meet.google.com/qdf-qkrv-fzi?hs=224](https://meet.google.com/qdf-qkrv-fzi?hs=224)'
documentos: null
organizacion: []
---

# Elementos discutidos

- Ayuda para consolidar escala de Centro con redondeo según escala para ESO.

- Incidencia al mover actividades de una evaluación a otra que pierden las calificaciones; ya visto con Luismi y analizado en el [Equipo Técnico Qe](Equipos/Equipo%20T%C3%A9cnico%20Qe.md)

- Creación de programas de atención y asignación de responsables.

# Dudas planteadas


# Otras cuestiones

