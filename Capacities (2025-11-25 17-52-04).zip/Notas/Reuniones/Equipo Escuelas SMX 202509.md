---
type: Reunion
title: Equipo Escuelas SMX 2025/09
description: null
tags: [Escuelas]
personasInvolucradas: null
tipo: Reunión de equipo
fecha: 2025-09-17 11:30 - 2025-09-18 15:30
enlace: null
documentos: null
organizacion: []
---

# Elementos discutidos


# Dudas planteadas


# Otras cuestiones

Red WIfi Casa Don Bosco: #Credencial

- WIFI TEMPORAL / 1d5Ft?RRD257%@

