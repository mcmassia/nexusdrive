---
type: Reunion
title: 'FORMACIÓN QE RESPONSABLES SECRETARÍA '
description: null
tags: []
personasInvolucradas: null
tipo: null
fecha: 2025-10-15 12:00 - 14:00
enlace: null
documentos: null
organizacion: []
---

event:: FORMACIÓN QE RESPONSABLES SECRETARÍA 
Description:   *   Estructura de Centro
  *   Gestión horarios
  *   Matriculación
  *   Escuela familia



________________________________________________________________________________
Microsoft Teams ¿Necesita ayuda?<https://aka.ms/JoinTeamsMeeting?omkt=es-ES>
Unirse a la reunión ahora<https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZTljZjgyMmQtNDU3OC00MTZjLWI0Y2ItYzMxYTNiYzA3NTI2%40thread.v2/0?context=%7b%22Tid%22%3a%2261d9fc70-113c-4514-9c0a-9b7c661e00f2%22%2c%22Oid%22%3a%22ff6da538-94eb-432f-8b14-b691c8136f79%22%7d>
Id. de reunión: 323 877 347 482 5
Código de acceso: eL9FH7US
________________________________
Para organizadores: Opciones de la reunión<https://teams.microsoft.com/meetingOptions/?organizerId=ff6da538-94eb-432f-8b14-b691c8136f79&tenantId=61d9fc70-113c-4514-9c0a-9b7c661e00f2&threadId=19_meeting_ZTljZjgyMmQtNDU3OC00MTZjLWI0Y2ItYzMxYTNiYzA3NTI2@thread.v2&messageId=0&language=es-ES>
________________________________________________________________________________

Attendees:
- Virginia Negrillo Carrascosa (virginianc@maristasmediterranea.com)
- Borja Blanco Vives (borjabv@maristasmediterranea.com)
- Delegado de Educacion (educacion@maristasmediterranea.com)
- SIS-Alberto Massia Gómez (alberto.massia@salesianos.edu)
- Carlos Lopez Serrano (carlosls@maristasmediterranea.com)
Location: Reunión de Microsoft Teams


### Notas

# Elementos discutidos


# Dudas planteadas


# Otras cuestiones

