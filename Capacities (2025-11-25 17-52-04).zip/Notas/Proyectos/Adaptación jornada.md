---
type: Proyecto
title: Adaptación jornada
description: null
tags: []
estado: Mejoras
marcoDeTiempo: null
colaboradores: '[Victoria Muñoz](Personas/Victoria%20Mu%C3%B1oz.md)'
---


