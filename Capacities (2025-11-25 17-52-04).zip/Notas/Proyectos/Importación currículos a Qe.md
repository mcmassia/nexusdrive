---
type: Proyecto
title: Importación currículos a Qe
description: null
tags: []
estado: En progreso
marcoDeTiempo: 2025-10-08 - 2025-10-09
colaboradores: '[Alberto Massia Gómez](Personas/Alberto%20Massia%20G%C3%B3mez.md) [Enrique Pradas Moreno](Personas/Enrique%20Pradas%20Moreno.md) [Martín Solís](Personas/Mart%C3%ADn%20Sol%C3%ADs.md) [Antonio Javier García Parra](Personas/Antonio%20Javier%20Garc%C3%ADa%20Parra.md)'
---

App: [Importador currículos a Qualitas Educativa](https://ai.studio/apps/drive/1OTak1IUTt31HM0as3uHuuCiysc3HfuLs).



[Hoja de control de importación/paso currículos FP](https://docs.google.com/spreadsheets/d/1Zeq22Uph1WolNbunqfKkqi-7tf1rZkaewbZefJqtL9I/edit?usp=sharing)


