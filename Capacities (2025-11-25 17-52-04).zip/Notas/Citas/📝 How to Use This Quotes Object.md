---
type: Cita
title: 📝 How to Use This Quotes Object
icon: null
tags: []
---

Welcome to your **Quotes** object!This object is perfect for collecting and organizing memorable quotes from books, films, talks, articles, conversations, or from anything that inspires you.

## 🔍 What Is a Quotes Object?

In Capacities, each quote is treated as an individual **object**.This gives you the ability to:

- Keep each quote **linked** to its original source (like books, films, or people).

- Add context, reflections, or tags to make it meaningful and easy to find later.

- Build a personal library of insights, inspiration, or references—all connected to your broader knowledge base.

---

## ✨ Suggested Ways to Use This Object:

### 1. **Capture the Quote**

- Save the exact wording of the quote.

- Attribute it to its **source**—such as a book, film, author, speaker, or article.

💡 Tip
If you write down a quote in your Book objects, highlight it, click '+' and choose quote. Then it's automatically linked back to its source.

### 2. **Add Context & Interpretation**

- Note why the quote resonates with you.

- Add thoughts, reflections, or where you discovered it.

- Include relevant themes or topics the quote relates to.

### 3. **Link to Other Objects**

- Connect quotes to the books, films, talks, or people they come from.

    - Don't worry about missing a connection; Capacities will find any unlinked mentions for you, so you can come back and make connections later.

- Reference related projects, ideas, or topics where the quote is relevant.

### 4. **Organize with Tags**

- Tag quotes by themes (e.g., #creativity, #leadership, #philosophy).

- Use tags to filter and review quotes by mood, topic, or purpose.

---

## 💡 Top Tips:

- [ ] Use **backlinks** to see how quotes are connected to your reading, writing, or projects.

- [ ] Revisit your favorite quotes regularly for reflection, writing prompts, or sharing.

---

By treating each quote as its own object, you create a curated, searchable archive of what has inspired you.

Feel free to personalize this object type to match how you collect and reflect on quotes!

