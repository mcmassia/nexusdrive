---
type: Definicion
title: Criterios de evaluación
tags: [Legislación, Educación]
---

«referentes que indican los niveles de desempeño esperados en el alumnado en las situaciones o actividades a las que se refieren las competencias específicas de cada área en un momento determinado de su proceso de aprendizaje».

