---
type: Definicion
title: Competencias específicas
tags: [Legislación, Educación]
---


