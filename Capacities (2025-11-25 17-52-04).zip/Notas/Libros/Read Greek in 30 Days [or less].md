---
type: Libro
title: Read Greek in 30 Days [or less]
description: In 10 short lessons author W. Larry Richards brings a fresh approach to learning Greek. This volume includes new techniques and exercises, as well as 13 appendices to further enhance your understanding of Greek.
tags: [Activo]
imagenDePortada: image
autor: W. Larry Richards
medio: E-Book
sinapsis: Book Highlights - Eight minimums—minimums that take the place of an almost unending number of tables. Covers basic English grammer before teaching Greek grammer. The techniques used get the reader quickly involved with the text and do not burden the learner with complex grammatical explanations. This is definitely New Testament Greek "made simple." No gimmicks—a fresh approach that works.
calificacion: null
recomendadoPor: null
enlacesWeb: ['Read Greek in 30 Days [or less]']
---

![ReadNTGreek30days](PDFs/Media/ReadNTGreek30days.pdf)
[ReadNTGreek30days](PDFs/ReadNTGreek30days.md)


# Notas

- INTRODUCTION

    The Approach. The method of this book is built around what I have labeled the “Eight Minimums.” These “Eight Minimums” make up the core of material upon which the bulk of NT Greek grammar is built. They give you the heart of Koine Greek grammar in an incredibly abbreviated, but workable, form. Each minimum is highlighted in red.

    The only way the method used in this book will work is to thoroughly master the eight “Minimums.

    Once the alphabet is mastered, these eight Minimums can actually be learned in eight concentrated hours. The eight “Minimums” are given in Appendix L along with a brief introductory section pointing out the value of each Minimum.

    Vocabulary. In the vocabulary section of each lesson, the word list is divided into parts. The purpose for doing this is to give a shorter list which can be learned in one study session. The parts correspond with the exercises, so that the words in Part A may be used for the exercises in Part I. The vocabulary is made easier and even enjoyable both by pointing out all of the words you already know and by showing you a multitude of English derivatives that help you remember the new definition.

- LESSON 1. THE GREEK ALPHABET

    Greek documents cover 34 centuries, a longer period of time than that of any other Indo–European language.

    New Testament Greek, known as Koine Greek, is the Greek that was used from the time of Alexander the Great (4th century BC) through the end of the great Roman Empire (5th century AD)—a period of Greek that is also known as the Greek of the Hellenistic and Roman periods.

    It is, therefore, the Greek of the Old Testament translation from Hebrew (Septuagint, 3rd century BC), of Philo (an Alexandrian Jewish apologist contemporary with Jesus), Josephus, the New Testament, the Apostolic Fathers, and the Greek–speaking Anti–Nicene Church Fathers.

    - Diphthongs are two vowels pronounced as one vowel.

    - Iota subscripts are important for translation purposes, but not for pronunciation.

    - Accent marks should only be used to help pronounce a word—they have no value in interpretation or proclamation.

    - Only the “rough” breathing mark (') is important since it is the letter “h.”

    ![image](Images/Media/image.png)
    [image](Images/image.md)
