---
type: Libro
title: 'Celtic from the West 2: Rethinking the Bronze Age and the Arrival of Indo-European in Atlantic Europe'
description: null
tags: [Lenguas, Celta]
imagenDePortada: null
autor: '[John T. Koch](Personas/John%20T%20Koch.md) [Barry Cunliffe](Personas/Barry%20Cunliffe.md)'
medio: Libro
sinapsis: Es un volumen académico dedicado a reconsiderar los orígenes de los celtas y la llegada de lenguas indoeuropeas a la fachada atlántica de Europa durante la Edad del Bronce.
calificacion: null
recomendadoPor: null
enlacesWeb: []
---




[Libro en pdf](https://drive.google.com/file/d/17Ayau-Ek2Nou0RtgZN-6Mc25bX1fbx8A/view?usp=drive_link)

[Documento soporte](https://docs.google.com/document/d/1h8KtFiMqyad9F-jXQ-G31LHe5B97MmaB0Ioueq8p0iE/edit?usp=sharing)




**"Celtic from the West 2: Rethinking the Bronze Age and the Arrival of Indo-European in Atlantic Europe"** y editado por John T. Koch y Barry Cunliffe, es un volumen académico dedicado a reconsiderar los orígenes de los celtas y la llegada de lenguas indoeuropeas a la fachada atlántica de Europa durante la Edad del Bronce.

**Puntos clave del contenido inicial:**

- **Objeto del libro:** Presenta estudios de arqueólogos y lingüistas sobre el surgimiento del pueblo celta, centrándose en la interacción entre la arqueología y la lingüística para explicar la dispersión del celta antiguo y otros indoeuropeos atlánticos.

- **Índice temático:** Incluye análisis sobre la llegada del conjunto campaniforme, conexiones culturales entre la península ibérica y las islas británicas, y reevaluaciones sobre los modelos tradicionales del origen celta.

- **Crítica al paradigma tradicional:** Se cuestiona la tesis clásica que sitúa el origen celta en la Edad del Hierro en Europa central (zona del Danubio), argumentando que no explica la presencia celta en la Península Ibérica y que recientes hallazgos arqueológicos y lingüísticos exigen mirar hacia la Edad del Bronce.

- **Nuevo enfoque:** Propone que los orígenes del celta y los contactos atlánticos pueden rastrearse hasta la Edad del Bronce, y que la expansión celta debió estar vinculada tanto a movimientos culturales como a élites y redes comerciales marítimas.

- **Debates interdisciplinarios:** El libro recopila el diálogo entre las hipótesis tradicionales (como la de invasión desde centroeuropa) y modelos alternativos (expansiones desde el oeste y sur atlántico), sumando incluso la teoría de una continuidad paleolítica para ciertos idiomas indoeuropeos.

En resumen, el libro defiende la necesidad de un nuevo marco interpretativo para la expansión celta antigua, integrando datos arqueológicos, lingüísticos y genéticos, y subraya la importancia de la península ibérica y las conexiones atlánticas en este proceso.​



- Resumen de capítulos

    **Prologue: “Ha C1a ≠ Proto-Celtic” (John T. Koch)**

    - Presenta la crítica al paradigma tradicional que identifica el origen celta con la Edad del Hierro (Hallstatt C1a, ca. 800–750 a.C.), argumentando que no puede explicar la presencia celta en la fachada atlántica de Europa. Destaca hallazgos recientes sobre la expansión de tecnologías y lenguas desde el Atlántico.

    **Capítulo 1: The Indo-Europeanization of Atlantic Europe (J.P. Mallory)**

    - Analiza cómo las lenguas indoeuropeas llegaron a Europa atlántica, apoyando la idea de que la dispersión se asocia a la Edad del Bronce y que su fuente principal está al norte de los Pirineos. Compara diferentes teorías sobre el origen y dispersión de las lenguas indoeuropeas y celtas.

    **Capítulo 2: The Arrival of the Beaker Set in Britain and Ireland (A.P. Fitzpatrick)**

    - Investiga la llegada del conjunto campaniforme y el inicio de la metalurgia en las islas británicas, usando pruebas de datación, análisis isotópico y contexto arqueológico. Sostiene que este cambio fue impulsado por élites migrantes móviles, con un impacto diferencial en Irlanda y Gran Bretaña.

    **Capítulo 3: Beakers into Bronze: Tracing connections between Western Iberia and the British Isles 2800–800 BC (Catriona Gibson)**

    - Explora las conexiones de larga distancia entre Iberia y las islas británicas en dos periodos: la Edad del Cobre (Campaniforme) y la Edad del Bronce Atlántico. Destaca el papel de los metales, las élites y prácticas rituales en la creación de redes atlánticas y posibles “lenguas internacionales” de especialistas.

    **Capítulo 4: Out of the Flow and Ebb of the European Bronze Age: Heroes, Tartessos, and Celtic (John T. Koch)**

    - Postula que los orígenes del proto-celta están en la Edad del Bronce Atlántica, con redes marítimas y contactos entre las regiones atlánticas y mediterráneas. Explica la fragmentación posterior entre el hispano-celta y el celta insular y cómo Tartessos y sus inscripciones aportan pruebas de la presencia celta temprana.

    **Capítulo 5: Westward Ho? Sword-Bearers and All the Rest of it... (Dirk Brandherm)**

    - Revisa las explicaciones arqueológicas de la celtización de la fachada atlántica, comparando el material de armas y élite entre Urnfield y el Bronce final. Analiza el papel de los “guerreros” y estelas tartésicas en la difusión de cultura y lengua celta.

    **Capítulo 6: Dead-Sea Connections: A Bronze Age and Iron Age Ritual Site on the Isle of Thanet (McKinley, Schuster & Millard)**

    - Estudia un sitio ritual excepcional en Kent, vinculado a prácticas de enterramiento, movilidad transmarítima y rituales liminales desde la Edad del Bronce hasta la Edad del Hierro. Ilustra la complejidad de los contactos y la interacción de culturas y lenguas en la costa atlántica.

    **Capítulo 7: Models of Language Spread and Language Development in Prehistoric Europe (Dagmar S. Wodtko)**

    - Expone varios modelos sobre la dispersión y evolución lingüística prehistórica. Argumenta que no siempre es necesaria una invasión bélica para expandir una lengua y que los cambios pueden suceder por modelos sociolingüísticos complejos en comunidades pequeñas.

    **Capítulo 8: Early Celtic in the West: The Indo-European Context (Colin Renfrew)**

    - Defiende el modelo de dispersión de lenguas por agricultores desde el Neolítico (farming/language dispersal), argumentando que el celta se hablaba en el Atlántico desde al menos el siglo VII a.C., apoyado por la evidencia tartésica. Contrasta este modelo con el Kurgan y la continuidad paleolítica.

    **Epilogue: The Celts—Where Next (Barry Cunliffe)**

    - Reflexiona sobre los distintos enfoques del libro y concluye que hay consenso en que el celta se hablaba en la zona atlántica desde el segundo milenio a.C. Subraya el valor de combinar evidencia lingüística, arqueológica y genética para avanzar en la comprensión del origen celta.



- **Prólogo**

    El prólogo plantea una revisión crítica del paradigma tradicional que sitúa el origen de los celtas en Europa central durante la primera Edad del Hierro. Koch propone que este modelo —que equipara el horizonte arqueológico de Hallstatt C inicial con el desarrollo del proto-céltico— es inadecuado para explicar la distribución geográfica y cronológica real de las lenguas celtas documentadas en la Antigüedad temprana.

    #### 1. Tesis central

    Koch argumenta que el modelo **Ha Cia = PC** (Hallstatt C inicial = Proto-Céltico) no puede sostenerse, dado que los registros lingüísticos y culturales de las zonas atlánticas —desde el Algarve hasta las islas británicas— muestran rasgos indoeuropeos, específicamente celtas, mucho antes de 800–750 a.C., fecha atribuida a dicho horizonte. Por tanto, el origen celta debe rastrearse en la **Edad del Bronce atlántica (c. 2200–900 a.C.)**, donde ya se observan redes culturales complejas que conectan Iberia, Bretaña y las Islas Británicas.[1]

    #### 2. Crítica al paradigma tradicional

    El paradigma clásico, basado desde el siglo XIX en los hallazgos en Hallstatt y La Tène, asume que la cultura material hallstática representa a los primeros celtas. Koch señala varios fallos:

    - Excluye regiones periféricas (como la península ibérica) donde hay evidencias de lenguas celtas pre-romanas (p.ej. celtíbero y tartesio).

    - No explica la presencia de tradiciones y lenguas indoeuropeas atlánticas previas a la Edad del Hierro.

    - Se mantiene por inercia académica más que por evidencia empírica.

    #### 3. Nuevas pruebas arqueológicas y lingüísticas

    Según Koch, los **nuevos análisis tipológicos y cronológicos** de metalistería (como las espadas de Gündlingen) demuestran un flujo inverso: los modelos tecnológicos y culturales se expanden **desde el Atlántico hacia Europa central**, no al revés. Además, el **desciframiento del tartesio**, considerado lengua indoeuropea y con afinidades celtas, refuerza la hipótesis de una Celtización temprana en el suroeste peninsular alrededor del siglo VII a.C..

    Desde esta perspectiva, el Ha Cia = PC debe reemplazarse por un modelo **“Celtic from the West”**, donde el núcleo proto-céltico emerge a través de contactos marítimos y comerciales atlánticos en la Edad del Bronce Media y Tardía.

    #### 4. Implicaciones historiográficas y lingüísticas

    Koch señala que el vínculo entre arqueología y lingüística histórica ha estado desequilibrado: los lingüistas heredaron de los arqueólogos la noción de invasión, mientras que la arqueología actual ya ha superado esa idea para comprender los cambios culturales como procesos de interacción y difusión. Esta tensión disciplinar explica la persistencia del modelo invasivo en filología céltica hasta fines del siglo XX.

    Asimismo, contrasta el concepto tradicional de “Celtas” (basado en fuentes greco-romanas que sitúan a los *Keltoi* en el Danubio) con la distribución lingüística más amplia y antigua, que incluiría poblaciones atlánticas antes del primer milenio a.C.

    #### 5. Críticas y apoyos contemporáneos

    Diversos autores respaldan las ideas de Koch sobre una **proto-celticidad atlántica**:

    - Cunliffe (2018) propone una “red atlántica” comercial y cultural como origen del mundo celta.

    - Almagro-Gorbea (2008) documenta evidencias epigráficas tartésicas en Medellín con dataciones firmes en el siglo VII a.C., que apoyan la presencia temprana de lenguas indoeuropeas occidentales.

    - Gerloff (2004) interpreta la metalurgia atlántica como vehículo principal de expansión cultural y lingüística céltica.

    Sin embargo, hay voces críticas:

    - Mallory (2013) mantiene que la llegada del indoeuropeo al Atlántico ocurrió desde el norte europeo, no desde el sur, y sitúa la diversificación céltica en la Edad del Bronce Final, no anterior.

    - Renfrew defiende el modelo neo-evolucionista de difusión agrícola del indoeuropeo, que ubica el nacimiento céltico aún más atrás, en el Neolítico, pero coincide en la crítica al modelo de Hallstatt.

    #### 6. Síntesis interpretativa

    En resumen, el prólogo de Koch pretende reemplazar un paradigma eurocéntrico orientado al continente interior por una visión **“atlántica”**, donde el idioma y la identidad celta surgen por contacto, continuidad y hibridación cultural desde el Bronce Medio (c. 1500 a.C.). Este cambio de enfoque redefine la cronología del celticismo e invita a repensar la relación entre lengua, cultura y territorio.

    ---

    **Referencias:**Koch, J. T. (2013). *Celtic from the West 2*, Prologue, pp. 1–7.[1]
    Megaw, R. & Megaw, V. (2006). *Celtic Art: From Its Beginnings to the Book of Kells*. Thames & Hudson.
    Milcent, P.-Y. (2012). “Chronologie et typologie de l’âge du Fer premier.” *Revue Archéologique de l’Est*, 61, 33–62.
    Koch, J. T. (2009). *Tartessian: Celtic in the South-west at the Dawn of History*.
    Almagro-Gorbea, M. (2008). “La necrópolis de Medellín y la epigrafía tartésica.” *Trabajos de Prehistoria*, 65(2).
    Greene, D. & Piggott, S. (1983). *Celtic Origin and the Spread of the Celts.*
    Cunliffe, B. (2018). *The Ancient Celts* (2nd ed.), Oxford University Press.
    Ruiz-Gálvez, M. (2008). *La Edad del Bronce Atlántico: comercio y sociedad*. CSIC.
    Mallory, J. P. (2013). “The Indo-Europeanization of Atlantic Europe.” En Koch & Cunliffe (Eds.), *Celtic from the West 2*, pp. 17–40.
    Renfrew, C. (1987). *Archaeology and Language: The Puzzle of Indo-European Origins*. Cambridge University Press.

- **Capítulo 1:** ***The Indo-Europeanization of Atlantic Europe***

    *Autor: J. P. Mallory*

    ### Tesis principal

    Mallory analiza el proceso y la cronología de la llegada del indoeuropeo y, específicamente, del celta a las regiones atlánticas de Europa. Su enfoque combina lingüística histórica, arqueología y evidencia genética, y revisa críticamente las hipótesis más influyentes sobre el origen y dispersión de las lenguas indoeuropeas en el extremo occidental del continente.

    ### Resumen de argumentos centrales

    1. **Modelos de dispersión indoeuropea:** Mallory revisa dos grandes corrientes. Primero, la tradicional “Kurgan Hypothesis” (Gimbutas, Anthony), que sitúa la dispersión indoeuropea desde las estepas norponticas durante la Edad del Bronce. Segundo, el modelo de Renfrew, vinculado a la expansión neolítica agrícola desde Anatolia. Mallory opta por la primera, subrayando que la evidencia lingüística sugiere una llegada relativamente tardía del indoeuropeo al Atlántico (durante la Edad del Bronce, no antes).[1]

    2. **Criterios lingüísticos:** Utiliza la “lingüística paleontológica” (reconstrucción de vocabulario y conceptos culturales en proto-indoeuropeo) para intentar fechar la expansión. Argumenta que los términos reconstruidos no reflejan conocimiento avanzado de la metalurgia del bronce, lo que refuerza la idea de la dispersión durante el Bronce y no en épocas anteriores.[1]

    3. **Distribución de lenguas y pueblos arqueológicos atlánticos:** Mallory discute la evidencia de lusitano, celtíbero y tartesio como lenguas indoeuropeas "periféricas" y plantea dudas sobre el encuadre del lusitano dentro de lo celta (apoyando su visión con Prosper, Wodtko, Luján y Untermann). El análisis sugiere que puede haber habido más de una ola de indoeuropeización peninsular, y que el proceso fue gradual y complejo.[1]

    4. **Importancia del fenómeno Beaker:** Destaca el papel de la red Campaniforme como posible vehículo de expansión del indoeuropeo y del celta en el tercer milenio a.C., aunque matiza que la dirección y profundidad del impacto lingüístico siguen siendo debatidas.

    ### Soporte y críticas de fuentes externas

    #### Soportes:

    - **Cunliffe (2018)** apoya la idea de una "red atlántica" en la Edad del Bronce que conecta Iberia y las islas británicas, aunque sugiere que los intercambios culturales podrían implicar también circulación lingüística.

    - **Koch (2013; 2009)** aporta el desciframiento de tartesio como evidencia de la presencia temprana de lenguas indoeuropeas occidentales en el suroeste peninsular, lo que refuerza la tesis de múltiples focos y cronologías para la celtización.

    - **Almagro-Gorbea (2008)** corrobora la antigüedad de inscripciones tartésicas y los posibles lazos proto-célticos.

    #### Críticas:

    - **Renfrew (1987)** discute la dependencia de la “lingüística paleontológica” y defiende una cronología de indoeuropeización mucho más antigua, asociada con la expansión agrícola del Neolítico.

    - **Ballester (2012) y Otte (2012)** han propuesto modelos de continuidad paleolítica, según los cuales las lenguas indoeuropeas podrían llevar miles de años en Europa occidental.

    - **Gerloff (2004)** y **Ruiz-Gálvez (2008)** afirman que los contactos Atlántico–Centroeuropeos son más bidireccionales de lo que el modelo Kurgan tradicional permite, sugiriendo una mayor autonomía de los focos atlánticos.

    - **Prosper (2008), Wodtko (2010), Luján (2006)** cuestionan la celticidad del lusitano y señalan que la complejidad lingüística pre-romana en la Península Ibérica no se puede reducir a divisiones simples, a menudo subestimadas en los modelos generalistas.

    ### Interpretación crítica de Mallory

    Mallory concluye que la llegada del indoeuropeo al Atlántico debe vincularse al Bronce y que la evidencia lingüística y arqueológica sigue apoyando un enfoque “nórdico” (Norte de los Pirineos) para el origen y la dispersión principal, si bien reconoce la validez de las críticas y la existencia de vacíos que impiden una síntesis definitiva. A diferencia de Renfrew y Koch, no ve en el sur peninsular un foco autónomo primordial del indoeuropeo.

    ### Síntesis y líneas de debate

    - El capítulo pone en valor la necesidad de estudios interdisciplinarios y avisa de las limitaciones metodológicas de la “lingüística paleontológica”.

    - Subraya la relevancia de distinguir entre la llegada del indoeuropeo y la formación de áreas celtohablantes, proceso que pudo prolongarse, diversificarse y tener diferentes epicentros en la fachada atlántica.

    - Señala que, aunque el modelo dominante aún mira al norte, las evidencias emergentes obligan a revisión, especialmente por el papel de la Península Ibérica en la lengua y cultura atlántica prehistórica.

    ---

    **Referencias**Mallory, J. P. (2013). "The Indo-Europeanization of Atlantic Europe." En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 17–40.[1]
    Cunliffe, B. (2018). *The Ancient Celts*. Oxford University Press.
    Koch, J. T. (2009). *Tartessian: Celtic in the South-west at the Dawn of History*.
    Renfrew, C. (1987). *Archaeology and Language: The Puzzle of Indo-European Origins*. Cambridge University Press.Ballester, X. (2012). "Lingüística indoeuropea y paradigmas alternativos".Ruiz-Gálvez, M. (2008). *La Edad del Bronce Atlántico: comercio y sociedad*. CSIC.Prosper, B. (2008). "La celticidad del lusitano: crítica y revisión".Almagro-Gorbea, M. (2008). "La necrópolis de Medellín y la epigrafía tartésica".



- **Capítulo 2:** ***The Arrival of the Beaker Set in Britain and Ireland***

    **Autor: A.P. Fitzpatrick**

    ---

    #### Tesis principal

    El capítulo examina en profundidad cómo y cuándo llegó el “Bell Beaker Package” (conjunto de artefactos y prácticas del Campaniforme) al territorio de Gran Bretaña e Irlanda, y analiza su relación con el inicio de la metalurgia, la movilidad de poblaciones y los cambios culturales en la Prehistoria atlántica. Fitzpatrick propone que la introducción del complejo Campaniforme no fue resultado de una migración masiva, sino de movimientos de pequeños grupos móviles y de élites tecnológicas.

    ---

    #### Puntos clave y argumentos:

    **1. Fechación y rutas de llegada**

    - El Campaniforme aparece en Gran Bretaña e Irlanda en los siglos XXV y XXIV a.C., más tarde que en Iberia, pero rápidamente asociado aquí al inicio de la metalurgia.

    - La evidencia isotópica de enterramientos muestra que individuos con ajuares beaker fueron enterrados en zonas lejanas a su lugar de origen, lo que indica movilidad a larga distancia.

    - Para Irlanda, los Beakers no llegan por transmisión secundaria desde Gran Bretaña: la entrada es directa, probablemente vía rutas marítimas occidentales más que por el Rin.

    **2. Innovación tecnológica y social**

    - En Gran Bretaña y especialmente Irlanda, el Campaniforme coincide con los primeros trabajos de minería y fundición de cobre (sitio clave: Ross Island, cerca de Killarney).

    - El acceso a la metalurgia posiciona a los grupos beaker como élite social, lo que facilita la rápida aceptación y expansión del “Beaker Set”.

    - El análisis químico de los metales confirma la circulación de cobre tanto en Irlanda como en Gran Bretaña en este periodo, sugiriendo una red económica atlántica.

    **3. Organización ritual y funeraria**

    - Se introducen prácticas funerarias como el enterramiento individual con ajuares específicos (vasos campaniformes, armas, adornos metálicos).

    - Ejemplo célebre: los “Boscombe Bowmen” y el “Amesbury Archer”, enterramientos vinculados a la movilidad y transferencia de saberes tecnológicos (dataciones y análisis isotópicos muestran orígenes lejanos dentro de Europa).

    **4. Implicaciones para la lengua y cultura**

    - Fitzpatrick matiza que la dispersión del Campaniforme pudo estar asociada a la difusión de lenguas por las élites, aunque subraya que la evidencia es más sólida para la transferencia de tecnología y valores sociales que para la transmisión lingüística generalizada.

    - Sugiere una “lingua franca” atlántica restringida, pero ve menos probable una gran uniformidad cultural o idiomática en la etapa inicial beaker.

    - La consolidación de redes en el Bronce Atlántico posterior fortalecería los vínculos, favoreciendo la semejanza cultural y quizás lingüística, como sostiene la tesis general del libro.

    ---

    #### Soporte de fuentes externas

    - **Cunliffe (2010; 2018)**: Apoya la idea de redes marítimas atlánticas en la Edad del Bronce, que explican la rapidez y alcance de la difusión Campaniforme y sugieren comunidades especializadas que actúan como agentes de transferencia tecnológica y quizás idiomática.

    - **O'Brien (2004)**: Respalda el papel pionero de Ross Island en la minería de cobre, confirmando una revolución tecnológica a partir del contacto beaker.

    - **Edwards & Sheridan (2007)**: Estudio isotópico de los “Amesbury Archer” refrenda la movilidad individual y el carácter exógeno del fenómeno, no una simple aculturación local.

    ---

    #### Críticas y perspectivas alternativas

    - **Needham (2005, 2009)**: Plantea que el paquete Campaniforme puede funcionar más como símbolo de estatus que como evidencia directa de migración o cambio idiomático.

    - **Vander Linden (2007, 2015)**: Sugiere que el Campaniforme implica fenómenos de contacto y fusión cultural más que ruptura o sustitución de población.

    - **Gibson (2012, capítulo siguiente)**: Considera que la integración del beaker en la Península Ibérica es más superficial (“veneer”), mientras que en las Islas Británicas y el centro de Europa genera una mayor transformación cultural y social.

    ---

    #### Síntesis interpretativa

    Fitzpatrick concluye que el Campaniforme no solo representa una revolución tecnológica y social, sino un proceso “atlántico” de formación de élites y valores, con movilidad real y figurada, que resulta clave en la configuración posterior del Bronce Atlántico. Las evidencias apoyan la visión de redes internacionales y transmisión de saberes, aunque la uniformidad lingüística o cultural inicial fue limitada y la consolidación llegó después. El capítulo refuerza el enfoque revisionista del libro: la Prehistoria atlántica es dinámica y compleja, y no reductible a modelos migratorios clásicos.

    ---

    **Referencias:**Fitzpatrick, A.P. (2013). “The Arrival of the Beaker Set in Britain and Ireland”. En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 41–70.Cunliffe, B. (2010, 2018). *The Ancient Celts*; *Europe Between the Oceans*.O'Brien, W. (2004). *Ross Island. Mining, Metal and Society in Early Ireland*.Edwards, W. & Sheridan, J. (2007). “Isotope evidence for mobility”.Needham, S. (2005, 2009). “Transformations and continuities in Beaker period Britain”.Vander Linden, M. (2007, 2015). “La cultura del vaso campaniforme: un fenómeno social complejo”.Gibson, C. (2012). “Beakers into Bronze”. En Koch & Cunliffe.



- **Capítulo 3:** ***Beakers into Bronze: Tracing connections between Western Iberia and the British Isles 2800–800 BC***

    **Autora: Catriona Gibson**

    ---

    #### Tesis principal

    El capítulo analiza las conexiones a larga distancia entre la Península Ibérica occidental y las Islas Británicas desde el Calcolítico Campaniforme (Beaker/Campo de Fosos) hasta el final de la Edad del Bronce, centrándose en el intercambio de objetos, materiales y prácticas rituales. Gibson argumenta que la relación entre estas regiones evidencia redes atlánticas sólidas que transmitieron tecnología y símbolos, pero que los “paquetes Beaker” a menudo funcionaron como un “veneer” (capa superficial) de prestigio sobre tradiciones locales persistentes.

    ---

    #### Puntos clave y argumentos

    **1. Paquete Beaker y su integración diferencial**

    - El conjunto Campaniforme incluye cerámica, armas (dagas, puntas Palmela), adornos y prácticas funerarias transmitidas desde el suroeste europeo hacia las Islas Británicas.

    - Mientras que en Gran Bretaña el “paquete Beaker” se integra profundamente a través de enterramientos individuales y el inicio de la metalurgia, en Irlanda y especialmente en Iberia, su adopción es más superficial, coexistiendo con grandes tumbas colectivas y tradiciones locales.

    **2. Intercambio de metales y artefactos**

    - Se documenta un flujo constante de cobre atlántico entre las minas de Ross Island (Irlanda), Galicia y Portugal, lo que demuestra redes comerciales marítimas desde el tercer milenio a.C.

    - Ánforas, adornos de oro y ciertas tipologías de espadas muestran paralelos directos entre contextos funerarios de Iberia y los de las Islas Británicas, especialmente en el Bronce Medio y Final.

    **3. Deposición ritual y simbolismo compartido**

    - Gibson estudia la deposición intencional de espadas, adornos y cauldrons en ríos, lagos y zonas liminales, prácticas equivalentes en las dos regiones atlánticas durante el Bronce Tardío.

    - Esto sugiere no solo contacto, sino la existencia de símbolos y sistemas de significado compartidos, más allá del intercambio material.

    **4. Especialización y “lingua franca” atlántica**

    - Enfatiza la posible existencia de grupos de élite especialistas en metalurgia, con movilidad internacional y una lengua común restringida entre ellos, aunque el idioma de la mayoría de la población pudo variar.

    - El argumento de una “lingua franca” atlántica gana fuerza en el Bronce Final, cuando aumentan los patrones rituales compartidos y se acercan cronológicamente los contextos de lenguas célticas históricas (tartesio, celtíbero, lusitano).

    ---

    #### Soportes y críticas de fuentes externas

    **Soportes:**

    - **Cunliffe (2010, 2018):** Confirma la existencia de una “red de intercambio marítimo atlántico”, recalca la especialización de grupos costeros y la movilidad elite-centric.

    - **O’Brien (2004):** Respalda la centralidad de Ross Island en la minería antigua, vinculando Iberia y las Islas Británicas.

    - **Ruiz-Gálvez (2008):** Argumenta la continuidad de relaciones transpirenáicas y atlánticas durante todo el Bronce.

    **Críticas:**

    - **Needham (2009):** Sugiere que el “veneer” Beaker realmente solo generó innovaciones duraderas en ciertas zonas, y que el Bronce Inicial Ibérico es fundamentalmente autóctono.

    - **Vander Linden (2015):** Advierte que equiparar intercambio de objetos con transferencia cultural o idiomática puede llevar a conclusiones erróneas; distingue entre redes de intercambio y verdadera aculturación.

    - **García Sanjuán (2006):** Señala que el fenómeno Campaniforme es más complejo en el suroeste peninsular, con fuerte resistencia de estructuras locales.

    ---

    #### Síntesis interpretativa

    Catriona Gibson concluye que las conexiones entre Iberia y las Islas Británicas durante el periodo Beaker y el Bronce Final fueron profundas, pero desiguales. El fenómeno Beaker, aunque visible en ambos lados del Atlántico, fue socialmente más transformador en Gran Bretaña, mientras en Iberia operó como símbolo internacional y tecnología de elite, sin remodelar el sustrato cultural local. Solo en la Edad del Bronce Tardío, con los rituales de deposición y el inicio de la metalurgia avanzada, surgieron patrones más homogéneos que anticipan la consolidación de zonas célticas atlánticas.

    ---

    **Referencias:**Gibson, C. (2013). "Beakers into Bronze: Tracing connections between Western Iberia and the British Isles 2800–800 BC". En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 71–100.Cunliffe, B. (2010, 2018). *Europe Between the Oceans*; *The Ancient Celts*.O'Brien, W. (2004). *Ross Island. Mining, Metal and Society in Early Ireland*.Ruiz-Gálvez, M. (2008). *La Edad del Bronce Atlántico*.Needham, S. (2009). “Transformations and continuities in Beaker period Britain”.Vander Linden, M. (2015). “Campaniforme y conexiones culturales.”García Sanjuán, L. (2006). “Problemas actuales del Campaniforme en el suroeste peninsular.”



- **Capítulo 4: Out of the Flow and Ebb of the European Bronze Age: Heroes,** [Tartessos](Pages/Tartessos.md)**, and Celtic**

    1. Tesis Central
    El capítulo defiende que los orígenes del celta deben rastrearse mucho antes de lo sugerido por el modelo tradicional, situándolos en la Edad del Bronce Atlántica (mediados del II milenio a.C.) en vez de en la Edad del Hierro (c. 800–750 a.C., Hallstatt C1a). Koch argumenta que la formación de una comunidad protocelta se asocia a la intensificación de contactos marítimos y comerciales entre las regiones atlánticas de Europa y el Mediterráneo occidental, especialmente a través del Estrecho de Gibraltar.

    2. Crítica al paradigma tradicional
    El modelo clásico de origen celta, que equipara Hallstatt C1a con el proto-celta (
    Ha C1a = PC
    ), no puede explicar la presencia de lenguas celtas en la ibérica occidental ni la diversidad celta temprana. Esta visión sólo focalizaba en la Europa central, ignorando conexiones atlánticas anteriores. Koch revisa cómo los argumentos lingüísticos y arqueológicos han sostenido esta visión y enumera sus limitaciones, especialmente ante descubrimientos como los textos de Tartessos y la nueva datación de hallazgos materiales.

    3. Redes Atlánticas y formación de una koiné protocelta
    La Edad del Bronce Atlántica (c. 1275–800 a.C.) se caracteriza por élites móviles, redes de intercambio de metales y prácticas culturales compartidas entre las Islas Británicas, la Galia atlántica e Iberia occidental. Koch sostiene que en este periodo se forma una koiné protocelta: un área sociocultural relacionada tanto por lengua como por prácticas materiales vinculadas a la élite. Esta fase implica la adopción de innovaciones –como la estandarización del bronce de alto contenido en estaño, tipos de espadas, y rituales aristocráticos– que cohesionan el atlántico occidental.

    4. Tartessos: evidencia de celticidad temprana
    Un eje central del capítulo es la interpretación de las inscripciones de Tartessos (sudoeste peninsular) como prueba de presencia celta en Iberia desde el s. VIII–VII a.C. Estas inscripciones, escritas en alfabeto paleohispánico, muestran rasgos celtas arcaicos tanto léxicos como morfológicos, avalados por varios expertos en paleolingüística. Koch argumenta que la aparición de textos tartésicos plenamente desarrollados alrededor del 650–625 a.C. prueba que el celta era hablado en el extremo occidental mucho antes de las invasiones de portadores de espadas de tipo Gündlingen (Hallstatt C1a), ya que este tipo de armas nunca llegó a la península.

        - [Tartessos](Pages/Tartessos.md) en este capítulo

            1. **Tartessos como Evidencia Lingüística de la Presencia Celta Temprana**
            Tartésico es el término moderno para la lengua de las inscripciones paleohispánicas halladas en el suroeste de la Península Ibérica (sur de Portugal y oeste de Andalucía). El corpus se fecha entre los siglos VIII-V a.C., con el inicio más probable en el VIII.

                Numerosos paleolingüistas han señalado, desde hace décadas, que el tartésico muestra una afinidad celta, con nombres personales, formas léxicas y morfología verbal propias del celta arcaico (Cap. 4, p. 101--102; autores recurrentes: Almagro-Gorbea, Ballester, Correa, Guerra, Jordán, Lorrio, Mederos, Torres, Untermann, Villar).

                El sistema de escritura es una adaptación local de un alfabeto de raíz semítica—la llamada escritura sureña, compartida también por el ibérico meridional.

                El uso de scriptio continua y la repetición de secuencias determinan la delimitación de palabras; las segmentaciones están condicionadas tanto por reglas fonológicas como por repeticiones corpus.

                El tartésico emplea para los nombres y verbos procedimientos fonológicos y morfológicos de clara impronta indoeuropea, según la transcripción estándar de Correa, Untermann y Guerra.

                Un dato crucial es la presencia de inscripciones tartésicas estilísticamente maduras ya en el periodo 650–625 a.C. (por ejemplo, la estela de Medellín), lo que sugiere una tradición extensa (Cap. 4, Fig. 4.13).

                El debate sobre la autenticidad de la celticidad del tartésico puede ser refutado solo cuestionando la transcripción y segmentación estándar, que ya es común para las escrituras paleohispánicas.

            2. Cronología y Arqueología del Fenómeno Tartésico
            El corpus epigráfico tartésico se extiende desde finales del s. VIII a.C., alcanzando su fase más desarrollada en la segunda mitad del VII a.C. con inscripciones de redacción generalizada—no exclusiva de élites (Cap. 4, p. 103; Almagro-Gorbea 2008).

                El contexto arqueológico presenta una sociedad con marcada estratificación social, especialización metalúrgica y contactos marítimos activos con el Mediterráneo oriental (fenicios) y el Atlántico.

                En la llamada "fase 2" de la alfabetización tartésica, se observa la proliferación de inscripciones fuera de contextos funerarios elitistas.

                Tartessos muestra continuidad y desarrollo local, sin migraciones masivas documentadas desde Centroeuropa; no hay evidencia de armas tipo Gündlingen (Hallstatt C1a), lo que descarta modelos invasivos tradicionales para la llegada de los celtas al suroeste ibérico.

                El fenómeno tartésico se solapa parcialmente con el horizonte de las llamadas estelas de guerrero (grabados de armas/equipamiento militar en piedra), varias de las cuales contienen inscripciones tartésicas (Cap. 4, p. 127 y Fig. 4.14), estableciendo conexión directa entre élites atlánticas de la Edad del Bronce Final y la lengua tartésica.

            3. Implicaciones para la Historia de la Lengua y el Contacto Cultural
            El tartésico documenta una lengua indoeuropea occidental con transformaciones fonéticas propias del proto-celta, como la pérdida de *p inicial (dato de gran valor paleolingüístico en el debate sobre la localización del celta antiguo).

                Las inscripciones y los contextos muestran un área de convergencia material y cultural entre el Atlántico, la zona galaico-portuguesa y Andalucía occidental, articulada por redes de prestigio y prácticas estatutarias adoptadas por las élites.

                El "schisma" cultural y lingüístico se atribuye a la transición tecnológica y social acentuada por la orientalización (contactos fenicios) a partir del 900 a.C., que fragmenta la koiné atlántica y separa ramas celtas insular/continental (Britania, Galia) de la hispánica.

            4. Cartografía, Materialidad y Ejemplos Epigráficos
            El documento aporta mapas y figuras (p. 126–128) que localizan la dispersión de inscripciones, estelas y rutas de contacto marítimo, incluyendo ejemplos de estelas tartésicas (J.57.1, Medellín; J.18.1, Mealha Nova).

                Figuras y tablas detallan la cronología relativa a la transición Bronce-Hierro y la interacción entre centros tartésicos, Galia atlántica e Islas Británicas.

                Estas evidencias fortalecen la idea de Tartessos como eje de innovación y nodo lingüístico celta.

            5. Relevancia en el Debate Científico
            El caso tartésico desafía frontalmente el paradigma clásico de la "celticidad centroeuropea" (Hallstatt C1a = Proto-celta), probando que el celta se documenta en el suroeste europeo un siglo antes de cualquier evidencia centroeuropea en la región.

                La interpretación de Tartessos como celta no es exclusiva de Koch, sino consenso entre muchos expertos en paleohispánico; el debate actual se da más en torno a matices morfosintácticos y variantes de segmentación de inscripciones que sobre la filiación general.

                Tartessos, por tanto, es piedra angular para cualquier nuevo modelo de difusión del celta y, por arrastre, para la prehistoria lingüística e identitaria de la Península Ibérica.

            6. Epigrafía tartésica: contexto y evidencias
            Corpus y cronología
            El tartésico es la lengua documentada en las inscripciones paleohispánicas del suroeste peninsular (sur de Portugal y oeste de Andalucía), datadas entre los siglos VIII y V a.C., con los primeros testimonios alrededor del 650–625 a.C. (ej: Estela de Medellín, Fig. 4.13).

                El sistema de escritura es adaptación de un alfabeto semítico occidental (alephat fenicio), conocido como “sureño”, compartido con otras lenguas paleohispánicas como el ibérico meridional.

                Las inscripciones muestran madurez estilística y sofisticación epigráfica desde fases tempranas, lo que evidencia una tradición extensa de alfabetización en la región—ya en "Fase 2" la escritura se había extendido socialmente, no solo limitada a élites (Almagro-Gorbea 2008).

                Características lingüísticas
                La mayor parte de la comunidad paleolingüística reconoce afinidades entre tartésico y celta antiguo, tanto léxicas como morfosintácticas. Ejemplos evidentes incluyen nombres personales y formas verbales arcaicas con paralelismos insulares y continentales (véanse fórmulas verbales en -nti, onomástica, desaparición de *p inicial indoeuropea).

                La segmentación de palabras mediante scriptio continua está mucho más restringida de lo que a veces se argumenta: repeticiones y reglas fonológicas de la escritura imponen límites claros al reconocimiento de vocabulario (Koch 2011).

                La transcripción y segmentación estándar es la de Correa, Untermann, y Guerra, reconocida y usada también para otras escrituras paleohispánicas.

                Relación con el registro material
                Varias estelas de “guerrero” del suroeste exhiben simultáneamente iconografía de armas y símbolo de estatus aristocrático junto con inscripción tartésica (Cap. 4, Fig. 4.14-4.15), mostrando vinculación directa entre élites y alfabetización.

                La proliferación epigráfica se asocia a un contexto social jerárquico, con monumentalización de la memoria familiar y élite a la vez que pervivencia de tradiciones rituales del Bronce Final.

            7. Contactos fenicio-atlánticos: dinámica y trascendencia cultural
            Orientalización y red marítima
            A partir del siglo IX/VIII a.C., la presencia fenicia en el sur peninsular supone un cambio fundamental: intercambio de objetos de lujo, influjo de nuevas tecnologías (trabajo del hierro, prácticas funerarias), y apertura de rutas marítimas directas en torno al Estrecho de Gibraltar (Cap. 4, Fig. 4.9).

                La orientalización anima una transición acelerada hacia la Edad del Hierro en el Suroeste, que contribuye a la fragmentación de la antigua koiné atlántica y precipita el desarrollo autónomo de la esfera tartésica y su epigrafía.

                Escritura y contactos culturales
                El alfabeto tartésico (sureño) es adaptación directa de modelos presentes en las primeras factorías fenicias establecidas en la costa.

                La transferencia tecnológica y simbólica (escritura, iconografía, prácticas funerarias) se integra en una red de contactos donde Tartessos actúa como nodo intermedio entre el Mediterráneo oriental y el Atlántico noroccidental, favoreciendo la adopción de técnicas, ideas y formas culturales de prestigio.

                Implicancias lingüísticas y del poder
                Los contactos intensos con sociedades no indoeuropeas (fenicios, comunidades íberas) refuerzan la singularidad del desarrollo tartésico, donde la lengua celta/autóctona se documenta a la vez que se asimilan innovaciones externas.

            8. Teoría de redes élites y transmisión sociocultural
            Redes, prestigio y koiné atlántica
            La Edad del Bronce Atlántica (c. 1275–800 a.C.) asiste a la conformación de una red de élites móviles, con vínculos comerciales y culturales entre Islas Británicas, Galia atlántica e Iberia occidental—base de una koiné socio-cultural y lingüística protocelta.

                El intercambio de innovaciones tecnológicas (armamento, metalurgia, prácticas funerarias aristocráticas) y la adopción preferencial de objetos de prestigio unifican referentes materiales y simbólicos a lo largo del Atlántico.

                Ruptura y consolidación
                El proceso de orientalización y transición al hierro (Siglo IX-VIII a.C.) provoca un “schisma”, es decir, una separación cultural y lingüística: el tartésico/hispano-celta evoluciona en el sudoeste, mientras el grupo britano-gálico desarrolla su propia continuidad en el norte.

                Tras la ruptura, la consolidación de los antiguos lazos queda demostrada por la transmisión de formas materiales (espadas, estelas de guerrero) y lengua común en los registros paleohispánicos.

            9. Red élite-inscripción
            Las inscripciones tartésicas surgen fundamentalmente en contextos asociados a tumbas, estelas de armas y monumentos de la élite; evidencian una alfabetización orientada a la exhibición de la memoria y legitimidad del linaje en torno a la pertenencia a redes internacionales de prestigio.

    5. Separación lingüística y schisma cultural
    Por el 900 a.C., la intensificación de contactos entre Iberia y el Mediterráneo provoca un proceso de orientación y una transición temprana al hierro. Eso fragmenta la antigua koiné atlántica: Hispano-celta y el grupo de la Galia/Britania/Irlanda –que dará lugar al celta insular y continental– divergen. El flujo material y la llegada de tipos como espadas Ewart Park y emblemas de estatus derivados del Atlántico a la Europa central refuerzan la consolidación del grupo noratlántico después de la separación.

    6. Implicaciones para la arqueología y la lingüística
    El capítulo concluye que la difusión de la lengua celta no depende necesariamente de migraciones bélicas; puede responder a la hegemonía de élites y a sistemas de prestigio e innovación tecnológica. El modelo explica por qué la lengua, cultura material y escrituras celtas aparecen articuladas en distintas regiones atlánticas considerablemente antes que la documentación clásica del fenómeno celta en la Europa central.

    7. Resumen final
    En suma, Koch propone una visión dinámica y descentralizada: la celticidad surge de una red atlántica con focos clave en Islas Británicas, Galia atlántica e Iberia, articulada por élites y rutas marítimas desde el Bronce Medio hasta principios de la Edad del Hierro. Tartessos aparece como testimonio clave de este proceso, refutando el mito tradicional de una única cuna prototípica centroeuropea para el mundo celta.

    ## Soportes y críticas de fuentes externas

    **Soportes:**

    - **Almagro-Gorbea (2008):** Datación firme de inscripciones tartésicas en Medellín refuerza el anclaje cronológico de Koch.

    - **Ruiz-Gálvez (2008, 2009):** Sostiene la importancia del Bronce Atlántico en la configuración de redes culturales y lingüísticas prehistóricas.

    - **Cunliffe (2018):** Argumenta la centralidad de las redes marítimas atlánticas como motor de innovación y uniformidad cultural.

    **Críticas:**

    - **Brandherm (cap. 5):** Matiza que la transmisión de material de elite entre la zona atlántica y centroeuropea no implica necesariamente la celtización de las élites del centro europeo.

    - **Milcent (2012):** Reconoce la circulación de modelos heroicos y metalistería, pero ve procesos más lentos y fragmentados en la adopción cultural.

    - **Renfrew (cap. 8):** Prefiere una dispersión indoeuropea mucho más antigua y cuestiona la profundidad real de la “ruptura atlántica” descrita por Koch.

    ---

    ## Síntesis interpretativa

    Koch plantea que la Edad del Bronce Atlántica no fue una periferia sino un núcleo decisivo en la formación celta: Tartessos monopoliza la innovación, promueve la alfabetización y desencadena el proceso de diferenciación interna entre los celtas atlánticos. El fenómeno se apoya en conexiones materiales y simbólicas robustas, pero la consolidación idiomática y cultural solo se concluye tras la caída de Tartessos y la transición orientalizante.

    ---

    **Referencias:**

    Koch, J.T. (2013). "Out of the Flow and Ebb of the European Bronze Age: Heroes, Tartessos, and Celtic". En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 101–146.

    Almagro-Gorbea, M. (2008). "La necrópolis de Medellín y la epigrafía tartésica".

    Cunliffe, B. (2018). *The Ancient Celts*.

    Ruiz-Gálvez, M. (2008, 2009). *La Edad del Bronce Atlántico*.

    Milcent, P-Y. (2012). “Chronologie et typologie de l’âge du Fer premier”.

    Brandherm, D. (2013). Capítulo 5.

    Renfrew, C. (2013). Capítulo 8.



- **Capítulo 5:** ***Westward Ho? Sword-Bearers and All the Rest of it...***

    **Autor: Dirk Brandherm**

    ---

    #### Tesis principal

    Brandherm revisa el papel de la circulación de espadas y material de elite entre Europa central (Urnfield, Hallstatt) y la fachada atlántica durante el Bronce Final y los inicios de la Edad del Hierro, evaluando si estos “portadores de espadas” representan imposición lingüística/cultural (celtización) por migraciones o si expresan mecanismos de interacción y prestigio entre elites. Su análisis matiza la idea de que la celtización atlántica se deba exclusivamente a invasiones desde el este y ofrece modelos alternativos de transferencia cultural y lingüística.

    ---

    #### Puntos clave y argumentos

    **1. Revisión historiográfica**

    - Recoge el desarrollo histórico del modelo clásico: la expansión de celticidad como consecuencia de migraciones armadas desde la Europa de los campos de urnas y Hallstatt hacia el oeste atlántico.

    - Relata cómo, a mediados del siglo XX, este modelo cede paso a interpretaciones menos invasivas, desplazando el centro de atención hacia contactos elite a elite y la adopción de “marcadores de estatus” extranjeros.

    **2. Flujos de objetos y su interpretación**

    - Documenta la llegada temprana de material Urnfield (cerámica acanalada, espadas tipo Rixheim, cascos crestados) a la Península Ibérica por vía marítima directa o a través de Armórica.

    - Aboga por distinguir dos flujos: un primer movimiento este-oeste (Bronce D-Hallstatt A, c. 1200–1000 a.C.), con material importado a Iberia, y un segundo flujo atlántico-oeste-este (inicio de Hallstatt C, c. 800 a.C.), donde espadas y artefactos derivados de Ewart Park circulan hacia el continente, excluyendo a Iberia.

    **3. Iconografía y estatus**

    - Analiza las estelas de guerrero del suroeste peninsular: la iconografía armada y la presencia conjunta de inscripciones tartésicas permiten relacionar directamente la elite material con la evidencia lingüística considerada proto-céltica.

    - Plantea la hipótesis de que los símbolos de elite (armas y ajuares) sirvieron de vehículos de prestigio e identidad más que de imposición cultural directa.

    **4. Limitaciones de la evidencia**

    - Brandherm advierte que la falta de datos lingüísticos sólidos para la mayoría del mundo celta hasta el Hierro Tardío hace muy difícil o imposible decidir cuál de los flujos (este-oeste u oeste-este) condujo la celtización efectiva.

    - Para Iberia, la progresiva orientalización (fenicia) habría frenado o interrumpido los procesos celtas detectados en otras zonas atlánticas.

    ---

    #### Soportes y críticas externas

    **Soportes:**

    - **Gerloff (2004):** Apoya la circulación atlántica de objetos de elite como factor clave en la transmisión de “celticidad” aristocrática.

    - **Ruiz-Gálvez (2008, 2009):** Reivindica los contactos y la originalidad atlántica en la forja del Bronce Final.

    - **Koch (2013, cap. 4):** Conecta iconografía material y estatus lingüístico/cultural a través de Tartessos y la Península.

    **Críticas:**

    - **Milcent (2012):** Exhibe prudencia: aunque reconoce migraciones limitadas y transferencias, insiste en la fragmentación y ritmos lentos del cambio cultural continental.

    - **Cunliffe (2018):** Resalta el papel de las redes, matizando el peso de movimientos migratorios masivos y sugiriendo circulación selectiva y controlada de símbolos.

    - **Needham (2009):** La circulación de objetos de elite no equivale necesariamente a aculturación idiomática ni a asimilación profunda.

    ---

    #### Síntesis interpretativa

    Brandherm concluye que las migraciones “masivas” no son plausibles como explicación para la celtización atlántica. La evidencia arqueológica es compatible con modelos de transferencia selectiva y prestigio entre elites, con flujos diferenciales en distintas épocas y regiones. La celtización parece el resultado de procesos múltiples y de interacción, más que de sustitución demográfica violenta.

    ---

    **Referencias:**
    Brandherm, D. (2013). "Westward Ho? Sword-Bearers and All the Rest of it..." En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 147–156.Gerloff, S. (2004). “Atlantic Bronze Age and Highland Zone.”Ruiz-Gálvez, M. (2008, 2009). *La Edad del Bronce Atlántico*.Koch, J.T. (2013, cap. 4).Milcent, P-Y. (2012).Cunliffe, B. (2018).Needham, S. (2009).



- **Capítulo 6:** ***Dead-Sea Connections: A Bronze Age and Iron Age Ritual Site on the Isle of Thanet***

    **Autores: Jacqueline I. McKinley, Jorn Schuster y Andrew Millard**

    ---

    #### Tesis principal

    El capítulo se centra en el excepcional yacimiento de Cliffs End Farm, en la Isla de Thanet (Kent, sureste de Inglaterra), donde se exhumaron evidencias arqueológicas de rituales funerarios y mortuorios desde finales de la Edad del Bronce hasta la Edad del Hierro. Los autores estudian la compleja secuencia de enterramientos, el exotismo de los restos humanos (incluyendo individuos llegados de zonas lejanas) y los patrones de depositación ritual, proponiendo que el sitio fue un nodo liminal y cosmopolita en las redes atlánticas y continentales de la Prehistoria avanzada.

    ---

    #### Puntos clave y argumentos

    **1. Secuencia arqueológica y caracterización del sitio**

    - El yacimiento contiene un registro continuo de actividad mortuoria desde el Bronce Final hasta el Hierro Medio (~900–100 a.C.).

    - Las excavaciones muestran fosas con restos articulados y desarticulados, depositados a menudo en contextos rituales inusuales (posturas manipuladas, objetos simbólicos, evidencia de violencia/trauma).

    **2. Origen de los individuos y movilidad**

    - Los análisis isotópicos de los dientes y huesos demuestran que una parte significativa de los enterrados no era local: hay mujeres procedentes del área del Mediterráneo oriental y hombres del norte/noroeste europeo.

    - Esta diversidad corrobora la existencia de redes de movilidad y ‘importación’ de individuos en contextos funerarios comunitarios de la zona de Kent.

    **3. Prácticas rituales: manipulación humanitaria y animal**

    - Se documentan casos de manipulación postmortem de cuerpos y partes articuladas, además de deposición ritual de animales (ovejas), objetos metálicos y elementos simbólicos (conos de plomo, balanzas).

    - La presencia de trauma violento, objetos en las manos y orientaciones corporales específicas refuerza la lectura de prácticas ritualizadas y liminales.

    **4. Interpretación social y cultural**

    - Los autores proponen que Cliffs End era un espacio liminar, tanto física como simbólicamente, posiblemente vinculado a mitologías de “entrada al otro mundo” u “islas de los muertos” en la cosmovisión atlántica e indoeuropea (cf. Procopio, Pytheas).

    - El sitio habría funcionado como nexo entre comunidades marítimas y continentales, recibiendo individuos de sectores tan distantes como Marruecos y los Balcanes.

    ---

    #### Soportes y críticas de fuentes externas

    **Soportes:**

    - **Needham (2009):** Reconoce el papel de Kent como zona de contacto entre redes marinas y terrestres en el Bronce Final/Hierro.

    - **Cunliffe (2018):** Considera que la movilidad de individuos y objetos, junto con prácticas funerarias complejas, refuerza el dinamismo de las redes atlánticas.

    - **Sims-Williams (2006):** Estudio toponímico y etnográfico que vincula nombres y mitos de “islas de los muertos” en la tradición celta y mediterránea.

    **Críticas:**

    - **Hill (2006):** Matiza la interpretación ritual de la manipulación corporal, advirtiendo que algunos patrones pueden obedecer a razones pragmáticas (control de epidemias, delimitación comunitaria).

    - **Champion (2015):** Sugiere cautela en atribuir cosmopolitismo cultural a la base de datos isotópica; podrían haber existido movimientos estacionales o matrimoniales, no necesariamente “importación ritual”.

    ---

    #### Síntesis interpretativa

    Cliffs End Farm emerge en el capítulo como un microcosmos de las redes cosmopolitas y ritos complejos de la Prehistoria atlántica e indoeuropea: espacio liminal, de movilidad e interacción cultural, con prácticas funerarias y mortuorias que trascienden la mera inhumación y adquieren dimensiones simbólicas. El sitio insinúa la existencia de “islas de los muertos” y profundiza la visión de la Prehistoria como mosaico internacionalizado mucho antes de la romanización.

    ---

    **Referencias:**McKinley, J.I., Schuster, J., & Millard, A. (2013). "Dead-Sea Connections: A Bronze Age and Iron Age Ritual Site on the Isle of Thanet". En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 157–184.Needham, S. (2009).Cunliffe, B. (2018).Sims-Williams, P. (2006). *Ancient Celtic Place-Names in Europe and Asia Minor*.Hill, J.D. (2006). “Theory and Practice in Iron Age Archaeology”.Champion, T. (2015). “Mobility and Ritual in Later Prehistoric Communities”.



- **Capítulo 7:** ***Models of Language Spread and Language Development in Prehistoric Europe***

    **Autora: Dagmar S. Wodtko**

    ---

    #### Tesis principal

    Dagmar S. Wodtko explora los principales modelos teóricos sobre la expansión y evolución de lenguas en la Prehistoria europea, especialmente para el celta y otras ramas indoeuropeas. Argumenta que el cambio lingüístico en sociedades preestatales requirió mecanismos distintos a los de épocas históricas, como invasiones o sustitución masiva, y reivindica la importancia de procesos sutiles, de contacto prolongado, bilingüismo y adaptación social.

    ---

    #### Puntos clave y argumentos

    **1. Revisión de modelos de dispersión lingüística**

    - Analiza el “modelo migratorio” (expansión por desplazamiento de poblaciones) tradicional en arqueología lingüística, cuyo ejemplo clásico es la romanización por conquista y repoblación.

    - Compara con el “modelo de difusión” (contagio cultural, prestigio de élites, contacto comercial) que se asocia a la expansión de lenguas en comunidades agrícolas o ligadas a redes mercantiles.

    - Presenta el caso especial del “koiné”, una lengua común que emerge por conveniencia social o política, como ocurrió con el griego helenístico más por necesidad práctica que por imposición.

    **2. Dificultad de extrapolar modelos históricos**

    - Wodtko enfatiza que los mecanismos del cambio idiomático varían radicalmente en sociedades sin estado, con baja centralidad política y fuerte segmentación local.

    - La transmisión de lenguas suele requerir un periodo prolongado de bilingüismo y mediación social; no es automático por la llegada de nuevos grupos.

    **3. Aplicaciones paleoindoeuropeas**

    - Explora la “farming/language dispersal model” de Renfrew, que asocia la expansión de indoeuropeo y céltico con la agricultura y la difusión demográfica, pero advierte que este modelo no es universal.

    - Contrasta con la visión de expansión por élites tecnológicas (metalurgia, redes beaker y bronce atlántico) como motor de transferencia lingüística restringida, más que generalizada.

    - Sugiere que la emergencia de una “koiné atlántica” en la Edad del Bronce pudo ocurrir para grupos especialistas —mercaderes, metalurgos, guerreros— pero que en la mayoría de la sociedad prevalecían lenguas locales hasta su paulatina desaparición.

    **4. Sociolingüística prehistórica**

    - Propone modelos sociolingüísticos donde el cambio de idioma responde a la multiplicidad de contactos entre comunidades segmentadas y la creación de espacios donde conviven varias lenguas (“islas de bilingüismo”).

    - Defiende que la transferencia completa de una lengua familiar (como el celta en la fachada atlántica) requirió siglos y contacto continuo, y rara vez fue producto de una sola ola migratoria.

    ---

    #### Soportes y críticas externas

    **Soportes:**

    - **Renfrew (2003, 2013):** Apoya modelos no invasivos de expansión idiomática, especialmente la hipótesis agropastoral para el indoeuropeo.

    - **Cunliffe (2010, 2018):** Defiende el papel de las redes atlánticas como motor de la “koiné” y el cambio idiomático por interacción de especialistas.

    - **Hamp (1998):** Resalta la complejidad y polimorfismo en la familia indoeuropea, desaconsejando modelos demasiado directos y lineales.

    **Críticas:**

    - **Anthony (2007):** Matiza la importancia de migraciones y movilidad frontal en la difusión indoeuropea, especialmente en Eurasia.

    - **Mallory (2013):** Sostiene que el cambio idiomático en la fachada atlántica no se explica solo por contacto mercantil y propone una síntesis de ambos modelos (movilidad y bilingüismo).

    - **Blake (2008):** Advierte que la sobreemphasis en modelos de contacto puede subestimar el impacto de sustituciones masivas en mosaicos preestatales particularmente frágiles.

    ---

    #### Síntesis interpretativa

    Wodtko concluye que la expansión del celta y otras lenguas indoeuropeas en la Prehistoria europea fue consecuencia de un proceso prolongado y multinivel: ni migraciones masivas ni meros contactos de comercio explican por sí solas el fenómeno. Plantea la necesidad de modelos integradores donde el cambio idiomático florece mediante interacción, prestigio y adaptación social a lo largo de generaciones.

    ---

    **Referencias:**Wodtko, D.S. (2013). "Models of Language Spread and Language Development in Prehistoric Europe". En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 185–208.Renfrew, C. (2003, 2013).Cunliffe, B. (2010, 2018).Hamp, E.P. (1998).Anthony, D. (2007).Mallory, J.P. (2013).Blake, B. (2008).



- **Capítulo 8:** ***Early Celtic in the West: The Indo-European Context***

    **Autor: Colin Renfrew**

    ---

    #### Tesis principal

    Renfrew presenta y defiende el “farming/language dispersal model”, según el cual las lenguas indoeuropeas (y específicamente el celta) se expandieron principalmente asociadas al avance de la agricultura neolítica por Europa. Propone que el celta y otras lenguas indoeuropeas pudieron estar presentes en la fachada atlántica ya desde el Neolítico o, como mínimo, desde el Bronce, mucho antes del paradigma tradicional que ubica el origen celta en la Edad del Hierro centroeuropea.

    ---

    #### Puntos clave y argumentos

    **1. Modelo de dispersión agrícola**

    - Postula que la expansión de la agricultura arrastra la dispersión de familias lingüísticas, incluido el indoeuropeo, que en este modelo habría alcanzado la fachada atlántica en torno al IV–III milenio a.C.

    - Contrasta este modelo con la “Kurgan Hypothesis”, que sitúa la expansión indoeuropea en la Edad del Bronce desde las estepas.

    - Recalca que la evidencia tartésica (inscripciones) corrobora la presencia de celta en el Suroeste peninsular ya en el siglo VII a.C., predicción directa del modelo agrícola y problemática para la hipótesis Kurgan.[1]

    **2. Árbol genético y cronologías**

    - Renfrew acude a análisis glotto-cronológicos y estudios lexicostadísticos (e.g. Gray & Atkinson 2003) que sitúan la ruptura de familias indoeuropeas varios miles de años antes de las primeras fuentes escritas.

    - Sugiere que los hallazgos tartésicos y celtíberos permiten adelantarse al paradigma tradicional de celticidad en Europa occidental.[1]

    **3. Evaluación crítica de otras teorías**

    - Renfrew critica el paradigma “Ha Cia = PC” (Hallstatt C inicial = Proto-Céltico) y defiende que la precocidad celta hace necesario revisar la celticidad de yacimientos como Heuneburg (Hallstatt D) y La Tène.

    - Considera que la hipótesis campaniforme (Beaker) puede funcionar como soporte para la difusión del proto-celta si asociamos el surgimiento de redes marítimas y comerciales a la dispersión idiomática atlántica en el III milenio a.C.

    **4. Alternativas radicales: modelo paleolítico**

    - Escucha el “Palaeolithic Continuity Paradigm” (Otte, Ballester), que sitúa la llegada del indoeuropeo, y quizás el celta, en el Paleolítico Superior, aunque reconoce que este modelo todavía no cuenta con apoyo suficiente ni de la filología ni la arqueología mainstream.

    ---

    #### Soportes y críticas externas

    **Soportes:**

    - **Gray & Atkinson (2003):** Confirman mediante modelos estadísticos la profundización temporal del árbol indoeuropeo.

    - **Ballester (2012):** Apoya la penetración temprana de indoeuropeo en la fachada atlántica, aunque con afinidades propias.

    **Críticas:**

    - **Mallory (1989, 2013), Anthony (2007):** Prefieren modelos centrados en cronologías del Bronce y rechazan el alcance real del dispersión agrícola para el indoeuropeo occidental.

    - **Koch (2013, prólogo y cap. 4):** Aunque reconoce la solidez de la “dispersión agrícola”, insiste en el papel relevante de la Edad del Bronce/Mediterráneo en la configuración céltica, y en que la celticidad de Tartessos no implica una cronología necesariamente neolítica.

    ---

    #### Síntesis interpretativa

    La intervención de Renfrew redefine la cronología del celta en Europa occidental y propone que el paradigma tradicional debe abrirse a modelos de diseminación socioeconómica y temprana. La evidencia tartésica y el uso de métodos estadísticos refuerzan su posición: la celticidad del Atlántico europeo es mucho más temprana y compleja, y probablemente no requiere invasiones ni rupturas violentas como las vistas en la historiografía tradicional.

    ---

    **Referencias:**Renfrew, C. (2013). "Early Celtic in the West: The Indo-European Context". En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 209–218.Gray, R.D. & Atkinson, Q.D. (2003). “Language-tree divergence times…”.Ballester, X. (2012).Mallory, J.P. (2013).Anthony, D.W. (2007).Otte, M. (2012).Koch, J.T. (2013).



- **Epílogo:** ***The Celts—Where Next***

    **Autor: Barry Cunliffe**

    ---

    #### Tesis principal

    Cunliffe sintetiza los debates multidisciplinarios sobre el origen y expansión del celta en Europa atlántica, reconociendo el notable avance en la reconsideración cronológica y espacial de su formación. Destaca que, a pesar de las divergencias entre los modelos de Mallory (Bronce Atlántico en el norte), Renfrew (dispersión agrícola temprana), y Koch (innovación y ruptura desde Tartessos y redes marítimas), existe consenso implícito: el celta estaba en uso en la zona atlántica para mediados del segundo milenio a.C.

    ---

    #### Puntos clave y argumentos

    **1. Consensos y diferencias**

    - Existe acuerdo entre los especialistas: el celta se hablaba en la fachada atlántica en la Edad del Bronce medio/tardío, desplazando la ortodoxia que lo ubicaba únicamente en la Edad del Hierro centroeuropea.

    - Las discrepancias principales radican en la “profundidad” temporal aceptable para el proto-celta y proto-indoeuropeo (cronología baja vs. alta).

    **2. Problemática interdisciplinaria**

    - Cunliffe identifica que arqueólogos y lingüistas difieren en la definición de “Proto-Celta”: los lingüistas buscan criterios formales (gramática distintiva, innovaciones fonéticas), mientras que los arqueólogos priorizan continuidad cultural y aislamiento poblacional.

    - Señala la importancia de distinguir entre el surgimiento de una “comunidad proto-céltica” (pre-condición social y cultural) y la aparición formal de rasgos idiomáticos célticos.

    **3. Futuro del debate céltico**

    - Propone un enfoque más flexible: es probable que las comunidades con lengua céltica existiesen antes de los cambios lingüísticos definitivos que permiten “reconocerlos” como celtas.

    - Recomienda concentrarse en los procesos de consolidación social, innovación técnica y contacto cultural para entender la evolución del celta — no solo la transformación gramatical o la expansión abrupta.

    **4. Relevancia actual**

    - Cunliffe argumenta que avanzar en una síntesis verdaderamente interdisciplinar será clave para desbloquear la cronología, naturaleza y dimensiones reales de la celticidad atlántica.

    - La revisión de la evidencia tartésica, los modelos de movilidad elite, y el estudio de fenómenos de bilingüismo y “koiné atlántica” ofrecen caminos concretos para futuras investigaciones.

    ---

    #### Síntesis final

    El epílogo reafirma el giro paradigmático logrado por la obra: se supera la visión clásica de una celticidad tardía y centroeuropea y se abre camino a la noción de un celta temprano, diverso y atlántico (con epicentro en la Edad del Bronce). El reto siguiente es unir las perspectivas lingüísticas y arqueológicas para modelar de manera precisa la génesis y expansión célticas en el occidente europeo.

    ---

    **Referencias:**Cunliffe, B. (2013). "The Celts—Where Next". En Koch & Cunliffe (eds.), *Celtic from the West 2*, pp. 219–224.Mallory, J.P. (2013).Renfrew, C. (2013).Koch, J.T. (2013).



- **Síntesis final**

    ### 1. Comparativa profunda de los principales modelos sobre el origen y expansión del celta

    | Modelo                                                  | Proponente(s)                | Postulado central                                                                                                                                                                                                                             | Evidencias clave                                                                                                                             | Limitaciones y críticas                                                                                                                                                                  |
    | :------------------------------------------------------ | :--------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
    | **Bronce Atlántico Norte**                              | J.P. Mallory, S. Needham     | El celta se difunde desde Europa norte/atlántica durante la Edad del Bronce (Campaniforme, Ewart Park, redes marítimas), a través de contactos y movimiento de élites tecnológicas.                                                           | Metalurgia, isotopía en enterramientos, artefactos campaniformes, presencia de celtíbero y lusitano en la península ibérica.                 | Insuficiente para explicar genealógicamente la precocidad tartésica; no explica bien las diferencias dialectales entre el celta peninsular y británico/irlandés.                         |
    | **Dispersión agrícola temprana**                        | Colin Renfrew                | El celta y el indoeuropeo se expanden con la agricultura desde el Neolítico. Lenguas indoeuropeas llegan al Atlántico mucho antes de la Edad del Bronce, anticipando la aparición tartésica.                                                  | Modelos glotto-cronológicos, diccionario tartésico, estadística lingüística (Gray-Atkinson), analogía con otros casos de expansión agrícola. | Tiende a homogeneizar el avance lingüístico; debilidad en la correlación empírica entre agricultura y el surgimiento del celta como lengua formalmente diferenciada.                     |
    | **Innovación y ruptura por redes marítimas atlánticas** | John T. Koch, Barry Cunliffe | La celticidad se forja en la Edad del Bronce a partir de redes marítimas, contacto con Tartessos y la internacionalización de la costa suroeste peninsular; la divergencia interna se produce por la caída de Tartessos y la orientalización. | Epigrafía tartésica, estelas de guerrero, arqueometría metalúrgica, similitudes mitológicas atlánticas.                                      | Modelo más convincente para la diferenciación, pero depende de la interpretación de la evidencia tartésica y puede sobredimensionar la influencia peninsular sobre las islas británicas. |

    **Conclusión comparativa:**Todos los modelos coinciden en reconocer una presencia celta en la fachada atlántica en la Edad del Bronce, pero difieren en “cómo” y “cuándo”. Lo novedoso tras "Celtic from the West 2" es que la celticidad deja de ser un fenómeno tardío continental y se integra como parte fundamental de la historia atlántica europea. El reto pendiente es fusionar la evidencia arqueológica (material, isotópica, ritual) con modelos lingüísticos no lineales y modelos socioeconómicos de interacción e innovación.

    ---

    ### 2. Cierre temático sobre el futuro de la investigación céltica (según el epílogo de Cunliffe y los autores)

    **A. Interdisciplinaridad como objetivo central**

    - **Síntesis**: Cunliffe subraya la necesidad de una convergencia real entre arqueología, lingüística histórica, genética y sociolingüística. Sin integración, cada campo solo llega a explicaciones parciales.

    - **Implicaciones**: En la próxima década, la investigación céltica buscará:

        - Mejorar modelos de bilingüismo y koiné especializada (élites vs. comunidades rurales).

        - Perfeccionar la datación de inscripciones, artefactos y evidencias de movilidad.

        - Sistematizar la comparación gramatical y léxica entre tartésico, celtíbero y lenguas británicas/irlandesas.[1]

    **B. Revisión de la cronología y las fronteras idiomáticas**

    - El debate del “proto-celta” abarca ahora desde el Neolítico hasta el Bronce Final, y su delimitación precisa requerirá nuevos estudios de ADN antiguo, isotopía y paleobotánica.

    - Se espera dilucidar la relación entre celticidad material (artefactos, rituales) e idiomática (rasgos gramaticales, inscripciones), particularmente en zonas de contacto como el oeste ibérico y las islas.

    **C. El papel de Tartessos y redes atlánticas**

    - Tartessos destaca como motor de innovación y contacto en la Prehistoria peninsular, pero deberán precisarse los mecanismos que llevaron a la bifurcación entre celta peninsular y galo-británico-irlandés.

    - La secuencia post-Tartessos, con la orientalización y la consolidación de las zonas insulares, se perfila como campo de investigación emergente.

    **D. Nuevas metodologías y retos futuros**

    - El desarrollo de bases de datos interconectadas (epigrafía, arqueometría, ADN) y el uso de inteligencia artificial en la comparación léxico-gramatical supondrán avances importantes.

    - La reflexión sobre procesos de cambio idiomático (modelo migratorio vs. modelo de contacto y bilingüismo) se verá enriquecida por el análisis de casos históricos y prehistóricos paralelos en otras regiones.

    ---

    ### Síntesis final

    El futuro de la investigación céltica, según "Celtic from the West 2", implica dejar atrás los modelos monolíticos y crear narrativas complejas, híbridas e interdisciplinarias. La celticidad atlántica ya es reconocida como un producto de interacción, movilidad y ruptura, y su explicación debe construirse sobre la convergencia de todas las evidencias disponibles.

    ---

    **Referencias clave:**Cunliffe, B. (2013). "The Celts—Where Next".Koch, J.T. (2013, prólogo y cap. 4).Mallory, J.P. (2013).Renfrew, C. (2013).Gray & Atkinson (2003).Needham, S. (2009).Ballester, X. (2012).

    ### Tabla comparativa de modelos sobre el origen y expansión del celta en Europa atlántica

    | Modelo                                         | Proponente(s)               | Postulado central                                                                                                      | Evidencias clave                                                               | Limitaciones/críticas                                                     | Proyección futura                                                          |
    | :--------------------------------------------- | :-------------------------- | :--------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------- | :------------------------------------------------------------------------ | :------------------------------------------------------------------------- |
    | **Bronce Atlántico / Norte**                   | J.P. Mallory, S. Needham    | Difusión celta (II-I milenio a.C.) por redes marítimas, élites tecnológicas y movilidad atlántica                      | Metalurgia, isotopía funeraria, artefactos campaniformes, celtíbero y lusitano | No explica plenamente divergencias dialécticas ni la precocidad tartésica | Integrar ADN antiguo, mejorar paralelos rituales y secuencias de movilidad |
    | **Dispersión agrícola temprana**               | C. Renfrew, Gray & Atkinson | Celta e indoeuropeo llegan al Atlántico con la expansión agrícola neolítica (V–III milenio a.C.)                       | Glotto-cronología, tartésico temprano, estadística lingüística                 | Débil correlación agricultura = lengua, sobrehomogeneización              | Ajuste finísimo de cronologías y análisis qpAdm/ADN paleolítico            |
    | **Innovación y ruptura atlántica (Tartessos)** | J.T. Koch, B. Cunliffe      | Proto-celta emerge en redes marítimas desde Tartessos y la internacionalización atlántica; ruptura por orientalización | Epigrafía tartésica, estelas de guerrero, metalurgia, mitología                | Sobredimensiona papel peninsular, depende de interpretación tartésica     | Bilingüismo, koiné prehistórico, contacto mercantil y elite                |

    ---

    ### Nuevas lecturas y fuentes recomendadas para profundizar

    **Libros y monografías:**

    - Cunliffe, B. (2010, 2018). *Europe Between the Oceans* (2010), *The Ancient Celts* (2018).

    - Koch, J.T. (2019). *Tartessian: Celtic from the Southwest at the Dawn of History*.

    - Ruiz-Gálvez, M. (2008). *La Edad del Bronce Atlántico: comercio y sociedad*.

    - Gerloff, S. (2004). *Atlantic Bronze Age and Highland Zone*.

    - O’Brien, W. (2015). *Prehistoric Copper Mining in Europe: Sites, Practices and Social Contexts*.

    - Sims-Williams, P. (2006). *Ancient Celtic Place-Names in Europe and Asia Minor*.

    - Almagro-Gorbea, M. (2008). “La necrópolis de Medellín y la epigrafía tartésica”. *Trabajos de Prehistoria*, 65(2).

    **Artículos científicos y ensayos:**

    - Gray, R.D. & Atkinson, Q.D. (2003). “Language-tree divergence times support the Anatolian theory of Indo-European origin.” *Nature*, 426: 435–439.

    - Ballester, X. (2012). “Lingüística indoeuropea y paradigmas alternativos”. *Revista de Filología*.

    - Milcent, P.-Y. (2012). “Chronologie et typologie de l’âge du Fer premier”. *Revue Archéologique de l’Est*.

    **Otras fuentes y perspectivas recientes:**

    - Studies en ADN antiguo de la fachada atlántica: Olalde et al. (2018, 2019). *Science*.

    - Enfoques antropológicos sobre bilingüismo y koiné: Matasović, R. (2009). *Etymological Dictionary of Proto-Celtic*.

    - Investigaciones sobre redes marítimas prehistóricas: García Sanjuán, L. (2006). “Problemas actuales del Campaniforme en el suroeste peninsular”. *Trabajos de Prehistoria*.

    **Para seguir debate y divulgación:**

    - Podcast “The British History Podcast” (episodios sobre la Edad del Bronce y el mundo celta).

    - Channel “Archaeosoup” en YouTube (series sobre Tartessos, Beaker, metalurgia atlántica).

    - Portal digital Academia.edu (buscando “Atlantic Bronze Age”, “Beaker networks” o “Tartessian epigraphy”).

    ---

    ### Síntesis final combinada

    La nueva narrativa céltica atlántica emerge de la integración multidisciplinar, donde modelos de migración, innovación tecnológica, contacto cultural y bilingüismo interactúan durante milenios. Profundizar en el debate requiere actualizarse con datos epigráficos, genética de poblaciones antiguas, sociolingüística prehistórica y la comparación sistemática entre artefactos y rituales a ambos lados del Atlántico europeo. Esta convergencia está marcando la investigación céltica global en la actualidad y abrirá nuevas vías para entender la génesis de las lenguas y culturas atlánticas en Europa.


